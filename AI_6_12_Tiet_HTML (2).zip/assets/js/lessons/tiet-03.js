window.AI6_LESSON={
  "id": 3,
  "title": "Bài 3. Dạy AI nhận biết đồ vật bằng Teachable Machine",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 32,
  "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 5,
    "title": "AI: How Computer Vision Works",
    "start": 85,
    "end": 110,
    "poster": "frame_5_95.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/5LHEqBfj39mMaxu0jlpFBQ/e8c81cbd51865522b439643e03a24d53/videoplayback.mp4",
    "question": "Quan sát điểm ảnh và cách biểu diễn hình. Muốn phân biệt bút với cốc, cần những ví dụ nào?",
    "local": "code-5.mp4"
  },
  "outcome": "Bộ ảnh Bút/Cốc và bảng ghi hai lần thử mới.",
  "slides": [
    {
      "type": "cover",
      "id": "03-01",
      "title": "Bài 3. Dạy AI nhận biết đồ vật bằng Teachable Machine",
      "note": {
        "activity": "Khởi động",
        "purpose": "Dự đoán nguyên nhân một mẫu mới khó nhận dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp; phải thử thực tế mới biết dự đoán của mô hình.",
        "assessment": "Ghi nhận các em đã nêu yếu tố dữ liệu. Hỗ trợ bằng bốn từ ánh sáng, góc chụp, nền, độ nét.",
        "answers": [
          "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp. Phải thử thực tế mới biết dự đoán của mô hình."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp. Phải thử thực tế mới biết dự đoán của mô hình.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "cups",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "03-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Dự đoán nguyên nhân một mẫu mới khó nhận dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp; phải thử thực tế mới biết dự đoán của mô hình.",
        "assessment": "Ghi nhận các em đã nêu yếu tố dữ liệu. Hỗ trợ bằng bốn từ ánh sáng, góc chụp, nền, độ nét.",
        "answers": [
          "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp. Phải thử thực tế mới biết dự đoán của mô hình."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chuẩn bị ảnh Bút/Cốc đúng nhãn.\n2. Nói dễ hiểu: Tạo dự án, thêm ảnh và dạy AI.\n3. Điều cần nhớ: Thử ảnh mới, ghi kết quả và điều kiện ảnh.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp. Phải thử thực tế mới biết dự đoán của mô hình.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chuẩn bị ảnh Bút/Cốc đúng nhãn.",
        "Tạo dự án, thêm ảnh và dạy AI.",
        "Thử ảnh mới, ghi kết quả và điều kiện ảnh."
      ],
      "phase": "Khởi động",
      "scene": "cups",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Chuẩn bị ảnh Bút/Cốc đúng nhãn.",
        "Tạo dự án, thêm ảnh và dạy AI.",
        "Thử ảnh mới, ghi kết quả và điều kiện ảnh."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chuẩn bị ảnh Bút/Cốc đúng nhãn.",
          "tone": "key",
          "note": "Thầy/Cô: Chuẩn bị ảnh Bút/Cốc đúng nhãn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tạo dự án, thêm ảnh và dạy AI.",
          "tone": "explain",
          "note": "Thầy/Cô: Tạo dự án, thêm ảnh và dạy AI."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Thử ảnh mới, ghi kết quả và điều kiện ảnh.",
          "tone": "action",
          "note": "Thầy/Cô: Thử ảnh mới, ghi kết quả và điều kiện ảnh."
        }
      ]
    },
    {
      "type": "divider",
      "id": "03-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Dự đoán nguyên nhân một mẫu mới khó nhận dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp; phải thử thực tế mới biết dự đoán của mô hình.",
        "assessment": "Ghi nhận các em đã nêu yếu tố dữ liệu. Hỗ trợ bằng bốn từ ánh sáng, góc chụp, nền, độ nét.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "cups",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "03-04",
      "title": "Cùng chiếc cốc, khác bức ảnh",
      "note": {
        "activity": "Khởi động",
        "purpose": "Dự đoán nguyên nhân một mẫu mới khó nhận dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp; phải thử thực tế mới biết dự đoán của mô hình.",
        "assessment": "Ghi nhận các em đã nêu yếu tố dữ liệu. Hỗ trợ bằng bốn từ ánh sáng, góc chụp, nền, độ nét.",
        "answers": [
          "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp. Phải thử thực tế mới biết dự đoán của mô hình."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ảnh nào nhìn rõ hơn?\n2. Nói dễ hiểu: Muốn nhận nhiều kiểu cốc, cần ảnh nào?\n3. Điều cần nhớ: Ảnh rõ, nhiều góc; thử thật rồi mới kết luận.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp. Phải thử thực tế mới biết dự đoán của mô hình.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ảnh nào nhìn rõ hơn?",
        "Muốn nhận nhiều kiểu cốc, cần ảnh nào?"
      ],
      "phase": "Khởi động",
      "scene": "cups",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Ảnh nào nhìn rõ hơn?",
        "Muốn nhận nhiều kiểu cốc, cần ảnh nào?",
        "Ảnh cần đủ rõ và đa dạng điều kiện phù hợp; phải thử thực tế mới biết dự đoán của mô hình."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ảnh nào nhìn rõ hơn?",
          "tone": "key",
          "note": "Thầy/Cô: Ảnh nào nhìn rõ hơn?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Muốn nhận nhiều kiểu cốc, cần ảnh nào?",
          "tone": "explain",
          "note": "Thầy/Cô: Muốn nhận nhiều kiểu cốc, cần ảnh nào?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ảnh rõ, nhiều góc; thử thật rồi mới kết luận.",
          "tone": "action",
          "note": "Thầy/Cô: Ảnh cần đủ rõ và đa dạng điều kiện phù hợp; phải thử thực tế mới biết dự đoán của mô hình."
        }
      ]
    },
    {
      "type": "divider",
      "id": "03-05",
      "title": "Khám phá: chuẩn bị dữ liệu ảnh",
      "note": {
        "activity": "Khám phá 2.1 Chuẩn bị nhãn và dữ liệu",
        "purpose": "Lựa chọn dữ liệu đúng hai lớp và nêu tiêu chí ảnh.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
        "assessment": "Quan sát việc tổ chức dữ liệu 1.3.TC1a. Yêu cầu sửa ngay ảnh đặt sai nhãn.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "cups",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_5_95.jpg",
      "id": "03-06",
      "title": "Máy nhìn ảnh bằng gì?",
      "note": {
        "activity": "Khám phá 2.1 Chuẩn bị nhãn và dữ liệu",
        "purpose": "Lựa chọn dữ liệu đúng hai lớp và nêu tiêu chí ảnh.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
        "assessment": "Quan sát việc tổ chức dữ liệu 1.3.TC1a. Yêu cầu sửa ngay ảnh đặt sai nhãn.",
        "answers": [
          "Ảnh số gồm nhiều ô nhỏ gọi là điểm ảnh. Máy xử lí các giá trị số biểu diễn ảnh.",
          "Trong ví dụ này, cần ảnh của cả Bút và Cốc, đặt đúng nhãn và chụp ở các điều kiện phù hợp."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ảnh số gồm những điểm ảnh nhỏ.\n2. Nói dễ hiểu: Máy xử lí các giá trị số của ảnh.\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ảnh số gồm nhiều ô nhỏ gọi là điểm ảnh. Máy xử lí các giá trị số biểu diễn ảnh.\nTrong ví dụ này, cần ảnh của cả Bút và Cốc, đặt đúng nhãn và chụp ở các điều kiện phù hợp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ảnh số gồm những điểm ảnh nhỏ.",
        "Máy xử lí các giá trị số của ảnh.",
        "Cần những ảnh nào cho Bút/Cốc?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "Ảnh số gồm những điểm ảnh nhỏ.",
        "Máy xử lí các giá trị số của ảnh.",
        "Cần những ảnh nào cho Bút/Cốc?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ảnh số gồm những điểm ảnh nhỏ.",
          "tone": "key",
          "note": "Thầy/Cô: Ảnh số gồm những điểm ảnh nhỏ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Máy xử lí các giá trị số của ảnh.",
          "tone": "explain",
          "note": "Thầy/Cô: Máy xử lí các giá trị số của ảnh."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Cần những ảnh nào cho Bút/Cốc?"
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 5,
        "title": "AI: How Computer Vision Works",
        "start": 85,
        "end": 110,
        "poster": "frame_5_95.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/5LHEqBfj39mMaxu0jlpFBQ/e8c81cbd51865522b439643e03a24d53/videoplayback.mp4",
        "question": "Máy xử lí ảnh dưới dạng gì?",
        "local": "code-5.mp4"
      },
      "id": "03-07",
      "title": "Từ điểm ảnh đến nhận dạng",
      "note": {
        "activity": "Khám phá 2.1 Chuẩn bị nhãn và dữ liệu",
        "purpose": "Lựa chọn dữ liệu đúng hai lớp và nêu tiêu chí ảnh.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
        "assessment": "Quan sát việc tổ chức dữ liệu 1.3.TC1a. Yêu cầu sửa ngay ảnh đặt sai nhãn.",
        "answers": [
          "Ảnh số gồm nhiều ô nhỏ gọi là điểm ảnh. Máy xử lí các giá trị số biểu diễn ảnh.",
          "Trong ví dụ này, cần ảnh của cả Bút và Cốc, đặt đúng nhãn và chụp ở các điều kiện phù hợp."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: Tìm cách ảnh được biểu diễn. Nhắc lại dữ liệu cần cho Bút/Cốc.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "Ảnh số gồm nhiều ô nhỏ gọi là điểm ảnh. Máy xử lí các giá trị số biểu diễn ảnh.\nTrong ví dụ này, cần ảnh của cả Bút và Cốc, đặt đúng nhãn và chụp ở các điều kiện phù hợp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "fallback": "Ảnh gồm các điểm ảnh. Máy xử lí giá trị số của chúng, rồi học đặc điểm từ các ảnh mẫu.",
      "v6": true,
      "screen": [
        "Tìm cách ảnh được biểu diễn.",
        "Nhắc lại dữ liệu cần cho Bút/Cốc."
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 25 giây, em ghi một ví dụ vào vở."
      ],
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm cách ảnh được biểu diễn.",
        "Nhắc lại dữ liệu cần cho Bút/Cốc."
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "type": "concept",
      "id": "03-08",
      "title": "Chuẩn bị hai nhóm ảnh",
      "note": {
        "activity": "Khám phá 2.1 Chuẩn bị nhãn và dữ liệu",
        "purpose": "Lựa chọn dữ liệu đúng hai lớp và nêu tiêu chí ảnh.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
        "assessment": "Quan sát việc tổ chức dữ liệu 1.3.TC1a. Yêu cầu sửa ngay ảnh đặt sai nhãn.",
        "answers": [
          "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em muốn máy phân biệt Bút với Cốc.\n2. Nói dễ hiểu: Mỗi nhóm chứa ảnh đúng vật, nhiều góc phù hợp.\n3. Điều cần nhớ: Đặt đúng tên nhóm trước khi thêm ảnh.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Một nhóm Bút, một nhóm Cốc.",
        "Ảnh rõ vật, đúng nhãn.",
        "Hai nhóm có điều kiện chụp tương tự."
      ],
      "phase": "Khám phá",
      "scene": "cups",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Một nhóm Bút, một nhóm Cốc.",
        "Ảnh rõ vật, đúng nhãn.",
        "Hai nhóm có điều kiện chụp tương tự."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em muốn máy phân biệt Bút với Cốc.",
          "tone": "key",
          "note": "Thầy/Cô: Em muốn máy phân biệt Bút với Cốc."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mỗi nhóm chứa ảnh đúng vật, nhiều góc phù hợp.",
          "tone": "explain",
          "note": "Thầy/Cô: Mỗi nhóm chứa ảnh đúng vật, nhiều góc phù hợp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đặt đúng tên nhóm trước khi thêm ảnh.",
          "tone": "action",
          "note": "Thầy/Cô: Đặt đúng tên nhóm trước khi thêm ảnh."
        }
      ]
    },
    {
      "id": "03-09-mau",
      "type": "worked",
      "v6": true,
      "title": "Lên kế hoạch ảnh bằng một mẫu",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "pencil-ruler",
      "worked": {
        "title": "Lên kế hoạch ảnh bằng một mẫu",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Hai nhóm ảnh",
          "Số ảnh dự kiến",
          "Góc chụp",
          "Nền ảnh",
          "Thông tin không chụp"
        ],
        "values": [
          "Bút chì / Thước kẻ",
          "Bắt đầu 15–20 ảnh khác nhau mỗi nhóm",
          "Chính diện và hơi nghiêng",
          "Hai vật có nền tương tự",
          "Mặt người và thông tin riêng"
        ],
        "why": [
          "Tên nhóm nói rõ vật cần phân biệt.",
          "Đổi góc giúp ảnh bớt giống hệt.",
          "Số ảnh không bảo đảm AI luôn đúng."
        ],
        "question": "Em nên tránh chụp thêm thông tin nào?",
        "scene": "Pencil-ruler"
      },
      "targetId": "03-09",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Mặt người và thông tin riêng",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Hai nhóm ảnh: Bút chì / Thước kẻ\nSố ảnh dự kiến: Bắt đầu 15–20 ảnh khác nhau mỗi nhóm\nGóc chụp: Chính diện và hơi nghiêng\nNền ảnh: Hai vật có nền tương tự\nThông tin không chụp: Mặt người và thông tin riêng"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chụp ảnh Bút chì / Thước kẻ.\n2. Nói dễ hiểu: Mỗi nhóm có ảnh nhiều góc, tên vật đúng.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Hai nhóm ảnh: Bút chì / Thước kẻ\nSố ảnh dự kiến: Bắt đầu 15–20 ảnh khác nhau mỗi nhóm\nGóc chụp: Chính diện và hơi nghiêng\nNền ảnh: Hai vật có nền tương tự\nThông tin không chụp: Mặt người và thông tin riêng",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 9,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chụp ảnh Bút chì / Thước kẻ.",
          "tone": "key",
          "note": "Thầy/Cô: Chụp ảnh Bút chì / Thước kẻ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mỗi nhóm có ảnh nhiều góc, tên vật đúng.",
          "tone": "explain",
          "note": "Thầy/Cô: Mỗi nhóm có ảnh nhiều góc, tên vật đúng."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em nên tránh chụp thêm thông tin nào? Gợi ý: Mặt người và thông tin riêng"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P3.1 Kế hoạch dữ liệu ảnh",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Bốn yếu tố: ánh sáng, góc chụp, hình nền, độ nét. Loại/chụp lại ảnh không thấy đủ vật hoặc gán nhãn sai. Không phải mọi ảnh khó đều phải bỏ nếu nó đại diện điều kiện thực tế và còn nhận biết được.",
          "Cho cả hai lớp xuất hiện ở các nền/điều kiện phù hợp tương tự. Giữ vật thể rõ. Số lượng ghi theo thực tế, 20–30 chỉ là gợi ý khởi điểm quản lí thời gian."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Bắt đầu với 15–20 ảnh mỗi nhóm. Chưa thể bảo đảm AI đoán đúng.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Lập kế hoạch chụp ảnh",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Nhóm ảnh",
              "Số ảnh dự kiến",
              "Số ảnh thực tế"
            ],
            "rows": [
              [
                "Bút",
                {
                  "label": "Số ảnh bút dự kiến",
                  "key": "03-09-v3-0"
                },
                {
                  "label": "Số ảnh bút thực tế",
                  "key": "03-09-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Lập kế hoạch chụp ảnh",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Nhóm ảnh",
              "Số ảnh dự kiến",
              "Số ảnh thực tế"
            ],
            "rows": [
              [
                "Cốc",
                {
                  "label": "Số ảnh cốc dự kiến",
                  "key": "03-09-v3-2"
                },
                {
                  "label": "Số ảnh cốc thực tế",
                  "key": "03-09-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn điều kiện chụp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ thay đổi góc chụp và ánh sáng thế nào?",
                "key": "03-09-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Chọn điều kiện chụp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ảnh nào cần chụp lại hoặc chuyển sang đúng nhóm? Vì sao?",
                "key": "03-09-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Chọn điều kiện chụp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vì sao không nên chỉ chụp bút trên nền xanh và cốc trên nền đỏ?",
                "key": "03-09-v3-6"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 3
        }
      },
      "time": 5,
      "id": "03-09",
      "title": "P3.1 — Lên kế hoạch chụp ảnh",
      "note": {
        "activity": "Khám phá 2.1 Chuẩn bị nhãn và dữ liệu",
        "purpose": "Hoàn thành chuẩn bị bộ ảnh theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Bốn yếu tố: ánh sáng, góc chụp, hình nền, độ nét. Loại/chụp lại ảnh không thấy đủ vật hoặc gán nhãn sai. Không phải mọi ảnh khó đều phải bỏ nếu nó đại diện điều kiện thực tế và còn nhận biết được.",
          "Cho cả hai lớp xuất hiện ở các nền/điều kiện phù hợp tương tự. Giữ vật thể rõ. Số lượng ghi theo thực tế, 20–30 chỉ là gợi ý khởi điểm quản lí thời gian."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Dự kiến số ảnh mỗi nhóm. Chọn góc, ánh sáng và nền. Chỉ chụp đồ vật.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Bốn yếu tố: ánh sáng, góc chụp, hình nền, độ nét. Loại/chụp lại ảnh không thấy đủ vật hoặc gán nhãn sai. Không phải mọi ảnh khó đều phải bỏ nếu nó đại diện điều kiện thực tế và còn nhận biết được.\nCho cả hai lớp xuất hiện ở các nền/điều kiện phù hợp tương tự. Giữ vật thể rõ. Số lượng ghi theo thực tế, 20–30 chỉ là gợi ý khởi điểm quản lí thời gian.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em so kết quả để rút ra điều có căn cứ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dự kiến số ảnh mỗi nhóm.",
        "Chọn góc, ánh sáng và nền.",
        "Chỉ chụp đồ vật."
      ],
      "phase": "Khám phá",
      "scene": "cups",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "03-09-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 10,
      "v7": true,
      "originalTeachingPoints": [
        "Dự kiến số ảnh mỗi nhóm.",
        "Chọn góc, ánh sáng và nền.",
        "Chỉ chụp đồ vật."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P3.1 · Lên kế hoạch ảnh"
    },
    {
      "type": "conclusion",
      "id": "03-10",
      "title": "Bộ ảnh đã sẵn sàng chưa?",
      "note": {
        "activity": "Khám phá 2.1 Chuẩn bị nhãn và dữ liệu",
        "purpose": "Lựa chọn dữ liệu đúng hai lớp và nêu tiêu chí ảnh.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
        "assessment": "Quan sát việc tổ chức dữ liệu 1.3.TC1a. Yêu cầu sửa ngay ảnh đặt sai nhãn.",
        "answers": [
          "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em so kết quả để rút ra điều có căn cứ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đúng vật và đúng nhãn?\n2. Nói dễ hiểu: Vật có nhìn rõ không?\n3. Điều cần nhớ: Có ảnh ở nhiều điều kiện phù hợp?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Gán nhãn đúng, ảnh đủ rõ và đa dạng quan trọng hơn chỉ tăng số lượng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đúng vật và đúng nhãn?",
        "Vật có nhìn rõ không?",
        "Có ảnh ở nhiều điều kiện phù hợp?"
      ],
      "phase": "Khám phá",
      "scene": "cups",
      "taskLines": [
        "Trong 30 giây, em nêu một căn cứ tại chỗ."
      ],
      "connector": "Em so kết quả để rút ra điều có căn cứ.",
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [
        "Đúng vật và đúng nhãn?",
        "Vật có nhìn rõ không?",
        "Có ảnh ở nhiều điều kiện phù hợp?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đúng vật và đúng nhãn?",
          "tone": "key",
          "note": "Thầy/Cô: Đúng vật và đúng nhãn?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Vật có nhìn rõ không?",
          "tone": "explain",
          "note": "Thầy/Cô: Vật có nhìn rõ không?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Có ảnh ở nhiều điều kiện phù hợp?",
          "tone": "action",
          "note": "Thầy/Cô: Có ảnh ở nhiều điều kiện phù hợp?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "03-11",
      "title": "Thực hành: tạo và thử mô hình",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “chuẩn bị bút chì / thước kẻ”."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "03-v7-groups",
      "type": "guide",
      "title": "Chuẩn bị Bút chì / Thước kẻ",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Đặt tên hai nhóm: Bút chì và Thước kẻ.",
        "Bắt đầu với 15–20 ảnh khác nhau mỗi nhóm.",
        "Đủ góc chụp; số ảnh này chưa bảo đảm đúng."
      ],
      "scene": "tm",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "So tên AI với đồ vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Đặt tên hai nhóm: Bút chì và Thước kẻ. / Bắt đầu với 15–20 ảnh khác nhau mỗi nhóm. / Đủ góc chụp; số ảnh này chưa bảo đảm đúng."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Chuẩn bị Bút chì / Thước kẻ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đặt tên hai nhóm: Bút chì và Thước kẻ.\n2. Nói dễ hiểu: Bắt đầu với 15–20 ảnh khác nhau mỗi nhóm.\n3. Điều cần nhớ: Đủ góc chụp; số ảnh này chưa bảo đảm đúng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Đặt tên hai nhóm: Bút chì và Thước kẻ. / Bắt đầu với 15–20 ảnh khác nhau mỗi nhóm. / Đủ góc chụp; số ảnh này chưa bảo đảm đúng.",
          "closing": "Thầy/Cô chốt: Đủ góc chụp; số ảnh này chưa bảo đảm đúng.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "realImage": "tm_book_ui.png",
      "number": 13,
      "originalTeachingPoints": [
        "Đặt tên hai nhóm: Bút chì và Thước kẻ.",
        "Bắt đầu với 15–20 ảnh khác nhau mỗi nhóm.",
        "Đủ góc chụp; số ảnh này chưa bảo đảm đúng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đặt tên hai nhóm: Bút chì và Thước kẻ.",
          "tone": "key",
          "note": "Thầy/Cô: Đặt tên hai nhóm: Bút chì và Thước kẻ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bắt đầu với 15–20 ảnh khác nhau mỗi nhóm.",
          "tone": "explain",
          "note": "Thầy/Cô: Bắt đầu với 15–20 ảnh khác nhau mỗi nhóm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đủ góc chụp; số ảnh này chưa bảo đảm đúng.",
          "tone": "action",
          "note": "Thầy/Cô: Đủ góc chụp; số ảnh này chưa bảo đảm đúng."
        }
      ]
    },
    {
      "id": "03-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Ba bước dạy AI qua hình ảnh",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "pencil-ruler",
      "worked": {
        "title": "Ba bước dạy AI qua hình ảnh",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "1. Tạo hai nhóm",
          "2. Thêm ảnh mẫu",
          "3. Dạy AI",
          "Ảnh mới để thử",
          "Căn cứ kiểm"
        ],
        "values": [
          "Đặt tên Bút chì và Thước kẻ",
          "Đưa ảnh vào đúng tên nhóm",
          "Chọn Train Model và chờ",
          "Giữ riêng ảnh chưa dùng dạy AI",
          "So tên AI với đồ vật thật"
        ],
        "why": [
          "Ghi tên trước giúp tránh bỏ nhầm ảnh.",
          "Train Model bắt đầu quá trình máy học.",
          "Ảnh mới giúp em kiểm cách AI đoán."
        ],
        "question": "Em dùng điều gì để kiểm tên AI?",
        "scene": "Pencil-ruler"
      },
      "targetId": "03-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "So tên AI với đồ vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "1. Tạo hai nhóm: Đặt tên Bút chì và Thước kẻ\n2. Thêm ảnh mẫu: Đưa ảnh vào đúng tên nhóm\n3. Dạy AI: Chọn Train Model và chờ\nẢnh mới để thử: Giữ riêng ảnh chưa dùng dạy AI\nCăn cứ kiểm: So tên AI với đồ vật thật"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tạo hai nhóm Bút chì / Thước kẻ.\n2. Nói dễ hiểu: Đặt tên, thêm ảnh, bấm Train Model, rồi thử mới.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "1. Tạo hai nhóm: Đặt tên Bút chì và Thước kẻ\n2. Thêm ảnh mẫu: Đưa ảnh vào đúng tên nhóm\n3. Dạy AI: Chọn Train Model và chờ\nẢnh mới để thử: Giữ riêng ảnh chưa dùng dạy AI\nCăn cứ kiểm: So tên AI với đồ vật thật",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tạo hai nhóm Bút chì / Thước kẻ.",
          "tone": "key",
          "note": "Thầy/Cô: Tạo hai nhóm Bút chì / Thước kẻ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đặt tên, thêm ảnh, bấm Train Model, rồi thử mới.",
          "tone": "explain",
          "note": "Thầy/Cô: Đặt tên, thêm ảnh, bấm Train Model, rồi thử mới."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em dùng điều gì để kiểm tên AI? Gợi ý: So tên AI với đồ vật thật"
        }
      ]
    },
    {
      "type": "task",
      "id": "03-12",
      "title": "Tạo mô hình Bút/Cốc",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [
          "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Thêm ảnh vào hai nhóm.\n2. Nói dễ hiểu: Dạy AI và thử hai ảnh mới.\n3. Điều cần nhớ: Ghi kết quả, lưu dự án.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Có ảnh mẫu rồi, em mở đúng dự án ảnh."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Thêm ảnh vào hai nhóm.",
        "Dạy AI và thử hai ảnh mới.",
        "Ghi kết quả, lưu dự án."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 11 phút, em tạo và thử AI Bút/Cốc trên máy."
      ],
      "sampleId": "03-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [
        "Thêm ảnh vào hai nhóm.",
        "Dạy AI và thử hai ảnh mới.",
        "Ghi kết quả, lưu dự án."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Thêm ảnh vào hai nhóm.",
          "tone": "key",
          "note": "Thầy/Cô: Thêm ảnh vào hai nhóm."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dạy AI và thử hai ảnh mới.",
          "tone": "explain",
          "note": "Thầy/Cô: Dạy AI và thử hai ảnh mới."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi kết quả, lưu dự án.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi kết quả, lưu dự án."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 0,
      "id": "03-13",
      "title": "Bước 1 — Mở dự án ảnh",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [
          "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Có ảnh mẫu rồi, em mở đúng dự án ảnh.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mở Teachable Machine.\n2. Nói dễ hiểu: Chọn Image Project.\n3. Điều cần nhớ: Chọn mô hình ảnh tiêu chuẩn nếu có.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Dự án đã mở. Em đặt tên rồi thêm ảnh."
        }
      },
      "theme": "cream",
      "highlight": 1,
      "v6": true,
      "screen": [
        "Mở Teachable Machine.",
        "Chọn Image Project.",
        "Chọn mô hình ảnh tiêu chuẩn nếu có."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "tm",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Có ảnh mẫu rồi, em mở đúng dự án ảnh.",
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [
        "Mở Teachable Machine.",
        "Chọn Image Project.",
        "Chọn mô hình ảnh tiêu chuẩn nếu có."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mở Teachable Machine.",
          "tone": "key",
          "note": "Thầy/Cô: Mở Teachable Machine."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chọn Image Project.",
          "tone": "explain",
          "note": "Thầy/Cô: Chọn Image Project."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chọn mô hình ảnh tiêu chuẩn nếu có.",
          "tone": "action",
          "note": "Thầy/Cô: Chọn mô hình ảnh tiêu chuẩn nếu có."
        }
      ]
    },
    {
      "type": "step",
      "step": 2,
      "time": 0,
      "id": "03-14",
      "title": "Bước 2 — Thêm ảnh đúng nhóm",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [
          "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Dự án đã mở. Em đặt tên rồi thêm ảnh.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đổi Class 1 thành Bút.\n2. Nói dễ hiểu: Đổi Class 2 thành Cốc.\n3. Điều cần nhớ: Thêm ảnh vào đúng nhóm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Ảnh đã đủ. Em kiểm trước khi dạy AI."
        }
      },
      "theme": "cream",
      "highlight": 2,
      "v6": true,
      "screen": [
        "Đổi Class 1 thành Bút.",
        "Đổi Class 2 thành Cốc.",
        "Thêm ảnh vào đúng nhóm."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "tm",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Dự án đã mở. Em đặt tên rồi thêm ảnh.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Đổi Class 1 thành Bút.",
        "Đổi Class 2 thành Cốc.",
        "Thêm ảnh vào đúng nhóm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đổi Class 1 thành Bút.",
          "tone": "key",
          "note": "Thầy/Cô: Đổi Class 1 thành Bút."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đổi Class 2 thành Cốc.",
          "tone": "explain",
          "note": "Thầy/Cô: Đổi Class 2 thành Cốc."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Thêm ảnh vào đúng nhóm.",
          "tone": "action",
          "note": "Thầy/Cô: Thêm ảnh vào đúng nhóm."
        }
      ]
    },
    {
      "type": "step",
      "step": 3,
      "time": 0,
      "id": "03-15",
      "title": "Bước 3 — Kiểm rồi dạy AI",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [
          "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Ảnh đã đủ. Em kiểm trước khi dạy AI.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Sửa ảnh sai nhãn.\n2. Nói dễ hiểu: Bỏ hoặc chụp lại ảnh không rõ vật.\n3. Điều cần nhớ: Bấm Train Model và chờ.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: AI học xong. Em thử ảnh mới rồi lưu."
        }
      },
      "theme": "cream",
      "highlight": 3,
      "v6": true,
      "screen": [
        "Sửa ảnh sai nhãn.",
        "Bỏ hoặc chụp lại ảnh không rõ vật.",
        "Bấm Train Model và chờ."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "tm",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Ảnh đã đủ. Em kiểm trước khi dạy AI.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Sửa ảnh sai nhãn.",
        "Bỏ hoặc chụp lại ảnh không rõ vật.",
        "Bấm Train Model và chờ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Sửa ảnh sai nhãn.",
          "tone": "key",
          "note": "Thầy/Cô: Sửa ảnh sai nhãn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bỏ hoặc chụp lại ảnh không rõ vật.",
          "tone": "explain",
          "note": "Thầy/Cô: Bỏ hoặc chụp lại ảnh không rõ vật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Bấm Train Model và chờ.",
          "tone": "action",
          "note": "Thầy/Cô: Bấm Train Model và chờ."
        }
      ]
    },
    {
      "type": "step",
      "step": 4,
      "time": 0,
      "id": "03-16",
      "title": "Bước 4 — Thử mới và lưu",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [
          "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: AI học xong. Em thử ảnh mới rồi lưu.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Thử một ảnh Bút, một ảnh Cốc mới.\n2. Nói dễ hiểu: So dự đoán với vật thật.\n3. Điều cần nhớ: Lưu dự án và giữ bộ ảnh.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “lần thử 1 · em kiểm bằng vật thật”."
        }
      },
      "theme": "cream",
      "highlight": 4,
      "v6": true,
      "screen": [
        "Thử một ảnh Bút, một ảnh Cốc mới.",
        "So dự đoán với vật thật.",
        "Lưu dự án và giữ bộ ảnh."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "tm",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "AI học xong. Em thử ảnh mới rồi lưu.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "Thử một ảnh Bút, một ảnh Cốc mới.",
        "So dự đoán với vật thật.",
        "Lưu dự án và giữ bộ ảnh."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Thử một ảnh Bút, một ảnh Cốc mới.",
          "tone": "key",
          "note": "Thầy/Cô: Thử một ảnh Bút, một ảnh Cốc mới."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So dự đoán với vật thật.",
          "tone": "explain",
          "note": "Thầy/Cô: So dự đoán với vật thật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Lưu dự án và giữ bộ ảnh.",
          "tone": "action",
          "note": "Thầy/Cô: Lưu dự án và giữ bộ ảnh."
        }
      ]
    },
    {
      "id": "03-v7-trial1",
      "type": "guide",
      "title": "Lần thử 1 · Em kiểm bằng vật thật",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Ảnh mới là bút chì đặt thẳng.",
        "Ví dụ: máy ghi Bút chì, điểm 98%.",
        "Đúng vì tên khớp vật; không phải vì 98%."
      ],
      "scene": "test",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI đúng lượt 1, nhầm lượt 2",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Ảnh mới là bút chì đặt thẳng. / Ví dụ: máy ghi Bút chì, điểm 98%. / Đúng vì tên khớp vật; không phải vì 98%."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Lần thử 1 · Em kiểm bằng vật thật.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ảnh mới là bút chì đặt thẳng.\n2. Nói dễ hiểu: Ví dụ: máy ghi Bút chì, điểm 98%.\n3. Điều cần nhớ: Đúng vì tên khớp vật; không phải vì 98%.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ảnh mới là bút chì đặt thẳng. / Ví dụ: máy ghi Bút chì, điểm 98%. / Đúng vì tên khớp vật; không phải vì 98%.",
          "closing": "Thầy/Cô chốt: Đúng vì tên khớp vật; không phải vì 98%.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “lần thử 2 · vật ngoài hai nhóm”."
        }
      },
      "guideTable": {
        "headers": [
          "Ảnh mới",
          "AI gợi ý",
          "Em đối chiếu"
        ],
        "rows": [
          [
            "Bút chì",
            "Bút chì · 98% (mẫu)",
            "Đúng: vật thật là bút chì"
          ]
        ],
        "label": "Số liệu minh họa; chưa chạy AI."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 20,
      "originalTeachingPoints": [
        "Ảnh mới là bút chì đặt thẳng.",
        "Ví dụ: máy ghi Bút chì, điểm 98%.",
        "Đúng vì tên khớp vật; không phải vì 98%."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ảnh mới là bút chì đặt thẳng.",
          "tone": "key",
          "note": "Thầy/Cô: Ảnh mới là bút chì đặt thẳng."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ví dụ: máy ghi Bút chì, điểm 98%.",
          "tone": "explain",
          "note": "Thầy/Cô: Ví dụ: máy ghi Bút chì, điểm 98%."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đúng vì tên khớp vật; không phải vì 98%.",
          "tone": "action",
          "note": "Thầy/Cô: Đúng vì tên khớp vật; không phải vì 98%."
        }
      ]
    },
    {
      "id": "03-v7-trial2",
      "type": "guide",
      "title": "Lần thử 2 · Vật ngoài hai nhóm",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Em đưa ảnh cục tẩy vào máy.",
        "Máy chỉ được dạy Bút chì / Thước kẻ.",
        "Ví dụ máy gọi Thước kẻ: em ghi Sai."
      ],
      "scene": "test",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI đúng lượt 1, nhầm lượt 2",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Em đưa ảnh cục tẩy vào máy. / Máy chỉ được dạy Bút chì / Thước kẻ. / Ví dụ máy gọi Thước kẻ: em ghi Sai."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Lần thử 2 · Vật ngoài hai nhóm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em đưa ảnh cục tẩy vào máy.\n2. Nói dễ hiểu: Máy chỉ được dạy Bút chì / Thước kẻ.\n3. Điều cần nhớ: Ví dụ máy gọi Thước kẻ: em ghi Sai.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Em đưa ảnh cục tẩy vào máy. / Máy chỉ được dạy Bút chì / Thước kẻ. / Ví dụ máy gọi Thước kẻ: em ghi Sai.",
          "closing": "Thầy/Cô chốt: Ví dụ máy gọi Thước kẻ: em ghi Sai.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "guideTable": {
        "headers": [
          "Ảnh mới",
          "AI gợi ý",
          "Em đối chiếu"
        ],
        "rows": [
          [
            "Cục tẩy",
            "Thước kẻ (mẫu)",
            "Sai: vật thật là cục tẩy"
          ]
        ],
        "label": "Kết quả minh họa; chưa chạy AI."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 21,
      "originalTeachingPoints": [
        "Em đưa ảnh cục tẩy vào máy.",
        "Máy chỉ được dạy Bút chì / Thước kẻ.",
        "Ví dụ máy gọi Thước kẻ: em ghi Sai."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em đưa ảnh cục tẩy vào máy.",
          "tone": "error",
          "note": "Thầy/Cô: Em đưa ảnh cục tẩy vào máy."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Máy chỉ được dạy Bút chì / Thước kẻ.",
          "tone": "explain",
          "note": "Thầy/Cô: Máy chỉ được dạy Bút chì / Thước kẻ."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ví dụ máy gọi Thước kẻ: em ghi Sai.",
          "tone": "action",
          "note": "Thầy/Cô: Ví dụ máy gọi Thước kẻ: em ghi Sai."
        }
      ]
    },
    {
      "id": "03-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Ghi mẫu hai lượt thử",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "worked": {
        "title": "Ghi mẫu hai lượt thử",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Lượt 1: đưa vào",
          "Lượt 1: đối chiếu",
          "Lượt 2: đưa vào",
          "Lượt 2: đối chiếu",
          "Kết luận vừa đủ"
        ],
        "values": [
          "Bút chì thẳng: AI ghi Bút chì · 98% (mẫu)",
          "Đúng: tên khớp bút chì thật",
          "Cục tẩy: AI gọi Thước kẻ (mẫu)",
          "Sai: vật thật là cục tẩy",
          "Đúng lượt 1, sai lượt 2; cần thử thêm"
        ],
        "why": [
          "Ghi cả tên AI và tên vật thật.",
          "Vật lạ có thể vẫn nhận một tên.",
          "Hai lượt chưa chứng minh đúng mọi vật."
        ],
        "question": "Từ hai lượt, em kết luận thế nào?",
        "scene": "Test"
      },
      "targetId": "03-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI đúng lượt 1, nhầm lượt 2",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Lượt 1: đưa vào: Bút chì thẳng: AI ghi Bút chì · 98% (mẫu)\nLượt 1: đối chiếu: Đúng: tên khớp bút chì thật\nLượt 2: đưa vào: Cục tẩy: AI gọi Thước kẻ (mẫu)\nLượt 2: đối chiếu: Sai: vật thật là cục tẩy\nKết luận vừa đủ: Đúng lượt 1, sai lượt 2; cần thử thêm"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI đoán tên hai vật mới.\n2. Nói dễ hiểu: Tên khớp vật mới là đúng; điểm cao chưa đủ.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Lượt 1: đưa vào: Bút chì thẳng: AI ghi Bút chì · 98% (mẫu)\nLượt 1: đối chiếu: Đúng: tên khớp bút chì thật\nLượt 2: đưa vào: Cục tẩy: AI gọi Thước kẻ (mẫu)\nLượt 2: đối chiếu: Sai: vật thật là cục tẩy\nKết luận vừa đủ: Đúng lượt 1, sai lượt 2; cần thử thêm",
          "closing": "Thầy/Cô chốt: Lần 1 khớp tên vật thật. Lần 2 là cục tẩy, ngoài hai nhóm, nên không dùng tên Thước kẻ. 98% chỉ là điểm trong ví dụ tạo sẵn; không phải độ chính xác của mô hình.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI đoán tên hai vật mới.",
          "tone": "key",
          "note": "Thầy/Cô: AI đoán tên hai vật mới."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tên khớp vật mới là đúng; điểm cao chưa đủ.",
          "tone": "explain",
          "note": "Thầy/Cô: Tên khớp vật mới là đúng; điểm cao chưa đủ."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Từ hai lượt, em kết luận thế nào? Gợi ý: Đúng lượt 1, sai lượt 2; cần thử thêm"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P3.2 Quy trình và bảng ghi mô hình",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Sản phẩm đạt khi có hai lớp, ảnh được gán nhãn, hoàn thành dạy AI và ghi hai lượt thử mới. Có thể dự đoán sai. Không dựng kết quả.",
          "Thầy/Cô ghi bước từng các em đã tham gia điều khiển. Nếu chỉ có máy Thầy/Cô, các em có thể chỉ định thao tác/đầu vào và luân phiên đại diện thực hiện. Cần bổ sung lượt trực tiếp cho em chưa có minh chứng."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Image Project → đặt tên Bút/Cốc → thêm ảnh → Train Model → Preview.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Kiểm tra trước khi chạy thử",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Hai nhóm ảnh đã đặt tên là gì?",
                "key": "03-17-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Kiểm tra trước khi chạy thử",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Mỗi nhóm có bao nhiêu ảnh?",
                "key": "03-17-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Kiểm tra trước khi chạy thử",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Dạy AI đã hoàn tất chưa?",
                "options": [
                  "Đã hoàn tất",
                  "Chưa hoàn tất"
                ],
                "key": "03-17-v3-2",
                "optionLabels": [
                  "Đã hoàn tất",
                  "Chưa hoàn tất"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi hai lần thử với ảnh mới",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vật thật / điều kiện thử",
              "Mô hình gọi tên gì?",
              "Đúng hay chưa đúng?"
            ],
            "rows": [
              [
                "Bút: ảnh mới",
                {
                  "label": "Dự đoán cho bút",
                  "key": "03-17-v3-3"
                },
                {
                  "label": "Nhận xét dự đoán bút",
                  "key": "03-17-v3-4"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi hai lần thử với ảnh mới",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vật thật / điều kiện thử",
              "Mô hình gọi tên gì?",
              "Đúng hay chưa đúng?"
            ],
            "rows": [
              [
                "Cốc: ảnh mới",
                {
                  "label": "Dự đoán cho cốc",
                  "key": "03-17-v3-5"
                },
                {
                  "label": "Nhận xét dự đoán cốc",
                  "key": "03-17-v3-6"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Lưu: menu góc trái → Download project as file. Mở lại: menu → Open project from file.",
            "originalPage": 2,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Giữ thư mục ảnh học để tạo lại khi cần.",
            "originalPage": 2,
            "referenceOnly": true
          },
          {
            "title": "Lưu công việc của em",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã lưu dự án hoặc bộ ảnh ở đâu?",
                "key": "03-17-v3-7"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Lưu công việc của em",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Mỗi em đã trực tiếp làm bước nào?",
                "key": "03-17-v3-8"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Lưu công việc của em",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nếu chưa chạy được, em vướng bước nào?",
                "key": "03-17-v3-9"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4,
          "2": 6
        }
      },
      "time": 16,
      "id": "03-17",
      "title": "P3.2 — bảng ghi thử mô hình",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Hoàn thành nhật kí chạy thử theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Sản phẩm đạt khi có hai lớp, ảnh được gán nhãn, hoàn thành dạy AI và ghi hai lượt thử mới. Có thể dự đoán sai. Không dựng kết quả.",
          "Thầy/Cô ghi bước từng các em đã tham gia điều khiển. Nếu chỉ có máy Thầy/Cô, các em có thể chỉ định thao tác/đầu vào và luân phiên đại diện thực hiện. Cần bổ sung lượt trực tiếp cho em chưa có minh chứng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Đã làm bước nào? Hai ảnh mới cho kết quả gì? Dự án được lưu ở đâu?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Sản phẩm đạt khi có hai lớp, ảnh được gán nhãn, hoàn thành dạy AI và ghi hai lượt thử mới. Có thể dự đoán sai. Không dựng kết quả.\nThầy/Cô ghi bước từng các em đã tham gia điều khiển. Nếu chỉ có máy Thầy/Cô, các em có thể chỉ định thao tác/đầu vào và luân phiên đại diện thực hiện. Cần bổ sung lượt trực tiếp cho em chưa có minh chứng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đã làm bước nào?",
        "Hai ảnh mới cho kết quả gì?",
        "Dự án được lưu ở đâu?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "03-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [
        "Đã làm bước nào?",
        "Hai ảnh mới cho kết quả gì?",
        "Dự án được lưu ở đâu?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P3.2 · Ghi hai lượt thử"
    },
    {
      "type": "report",
      "id": "03-18",
      "title": "Báo cáo từ lần thử thật",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [
          "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đã thử ảnh nào?\n2. Nói dễ hiểu: Mô hình dự đoán gì?\n3. Điều cần nhớ: Em đối chiếu bằng gì?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đã thử ảnh nào?",
        "Mô hình dự đoán gì?",
        "Em đối chiếu bằng gì?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [
        "Đã thử ảnh nào?",
        "Mô hình dự đoán gì?",
        "Em đối chiếu bằng gì?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đã thử ảnh nào?",
          "tone": "key",
          "note": "Thầy/Cô: Đã thử ảnh nào?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mô hình dự đoán gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Mô hình dự đoán gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em đối chiếu bằng gì?",
          "tone": "action",
          "note": "Thầy/Cô: Em đối chiếu bằng gì?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "03-20",
      "title": "Luyện tập: đọc kết quả",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Nhận biết sai nhãn và đọc đúng kết quả công cụ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Số hiển thị gắn một lần dự đoán; muốn đánh giá cần thử nhiều mẫu phù hợp và ghi đúng/sai.",
        "assessment": "Đạt khi xử lí đúng ít nhất 2/3 tình huống. Hỏi lại riêng cách dùng ảnh mới.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "03-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu đọc một điểm dự đoán",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "worked": {
        "title": "Mẫu đọc một điểm dự đoán",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Ảnh đưa vào",
          "Tên vật thật",
          "Tên AI gợi ý",
          "Điểm hiển thị",
          "Việc kiểm"
        ],
        "values": [
          "Một chiếc thìa",
          "Thìa",
          "Thước",
          "99% trong ví dụ",
          "So nhãn với vật thật, kết quả vẫn sai"
        ],
        "why": [
          "Số lớn chưa bảo đảm tên đúng.",
          "Ảnh có tên thật để đối chiếu.",
          "Không gọi 99% là đúng mọi ảnh."
        ],
        "question": "Em dùng điểm hay vật thật để kiểm?",
        "scene": "Test"
      },
      "targetId": "03-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "So nhãn với vật thật, kết quả vẫn sai",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Ảnh đưa vào: Một chiếc thìa\nTên vật thật: Thìa\nTên AI gợi ý: Thước\nĐiểm hiển thị: 99% trong ví dụ\nViệc kiểm: So nhãn với vật thật, kết quả vẫn sai"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ví dụ: AI gọi Thước, điểm 99%, nhưng là thìa.\n2. Nói dễ hiểu: AI vẫn sai nếu tên không khớp vật thật.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Ảnh đưa vào: Một chiếc thìa\nTên vật thật: Thìa\nTên AI gợi ý: Thước\nĐiểm hiển thị: 99% trong ví dụ\nViệc kiểm: So nhãn với vật thật, kết quả vẫn sai",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ví dụ: AI gọi Thước, điểm 99%, nhưng là thìa.",
          "tone": "key",
          "note": "Thầy/Cô: Ví dụ: AI gọi Thước, điểm 99%, nhưng là thìa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI vẫn sai nếu tên không khớp vật thật.",
          "tone": "explain",
          "note": "Thầy/Cô: AI vẫn sai nếu tên không khớp vật thật."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em dùng điểm hay vật thật để kiểm? Gợi ý: So nhãn với vật thật, kết quả vẫn sai"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P3.3 Đọc kết quả và chuẩn bị kiểm thử",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "1: Chuyển ảnh cốc về nhóm Cốc hoặc loại ảnh đặt sai trước khi dạy AI.",
          "2: Không. 98% là điểm mô hình hiển thị cho một dự đoán, không phải số đo đúng trên mọi 100 ảnh khác.",
          "3: Thử ảnh mới để kiểm tra khả năng xử lí ảnh chưa dùng để học."
        ],
        "pages": [
          {
            "title": "Kiểm tra ảnh và đọc kết quả",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Một ảnh cốc nằm trong nhóm Bút. Em sửa gì trước khi dạy AI?",
                "key": "03-21-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Kiểm tra ảnh và đọc kết quả",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Điểm 98% của ảnh này có bảo đảm các ảnh khác đúng? Vì sao?",
                "key": "03-21-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn ảnh để thử",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nên thử bằng ảnh đã dùng để học hay bằng ảnh mới? Vì sao?",
                "key": "03-21-v3-2"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2
        }
      },
      "time": 4,
      "id": "03-21",
      "title": "P3.3A — Đọc kết quả cho đúng",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành đọc và kiểm tra kết quả theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Số hiển thị gắn một lần dự đoán; muốn đánh giá cần thử nhiều mẫu phù hợp và ghi đúng/sai.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1: Chuyển ảnh cốc về nhóm Cốc hoặc loại ảnh đặt sai trước khi dạy AI.",
          "2: Không. 98% là điểm mô hình hiển thị cho một dự đoán, không phải số đo đúng trên mọi 100 ảnh khác.",
          "3: Thử ảnh mới để kiểm tra khả năng xử lí ảnh chưa dùng để học."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Nhãn ảnh học đã đúng chưa? Ảnh thử có thật sự mới không? Phần trăm có bảo đảm đúng không?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1: Chuyển ảnh cốc về nhóm Cốc hoặc loại ảnh đặt sai trước khi dạy AI.\n2: Không. 98% là điểm mô hình hiển thị cho một dự đoán, không phải số đo đúng trên mọi 100 ảnh khác.\n3: Thử ảnh mới để kiểm tra khả năng xử lí ảnh chưa dùng để học.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nhãn ảnh học đã đúng chưa?",
        "Ảnh thử có thật sự mới không?",
        "Phần trăm có bảo đảm đúng không?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "03-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [
        "Nhãn ảnh học đã đúng chưa?",
        "Ảnh thử có thật sự mới không?",
        "Phần trăm có bảo đảm đúng không?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P3.3A · Em tự làm"
    },
    {
      "type": "recap",
      "id": "03-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Huấn luyện và chạy thử",
        "purpose": "Tạo mô hình hai lớp và ghi dự đoán với đầu vào mới.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào; một con số cao không chứng minh luôn đúng.",
        "assessment": "Thầy/Cô quan sát thao tác thật và thu P3.2. Nếu chỉ xem video thì ghi chưa có minh chứng tạo mô hình.",
        "answers": [
          "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ảnh học rõ vật và đúng nhãn.\n2. Nói dễ hiểu: Ảnh thử phải mới với mô hình.\n3. Điều cần nhớ: Điểm dự đoán không bảo đảm luôn đúng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Công cụ học từ các ví dụ có nhãn để tạo mô hình. Kết quả phụ thuộc dữ liệu và điều kiện đầu vào. Một con số cao không chứng minh luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ảnh học rõ vật và đúng nhãn.",
        "Ảnh thử phải mới với mô hình.",
        "Điểm dự đoán không bảo đảm luôn đúng."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [
        "Ảnh học rõ vật và đúng nhãn.",
        "Ảnh thử phải mới với mô hình.",
        "Điểm dự đoán không bảo đảm luôn đúng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ảnh học rõ vật và đúng nhãn.",
          "tone": "key",
          "note": "Thầy/Cô: Ảnh học rõ vật và đúng nhãn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh thử phải mới với mô hình.",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh thử phải mới với mô hình."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Điểm dự đoán không bảo đảm luôn đúng.",
          "tone": "action",
          "note": "Thầy/Cô: Điểm dự đoán không bảo đảm luôn đúng."
        }
      ]
    },
    {
      "type": "divider",
      "id": "03-22",
      "title": "Vận dụng: thiết kế lần thử mới",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Đề xuất cách chuẩn bị kiểm thử tiết sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm thử cần đầu vào mới và nhãn thực để đối chiếu.",
        "assessment": "Chấp nhận các biến đổi khác nhau. Loại yêu cầu thu ảnh người hoặc dùng đồ vật nguy hiểm.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "cups",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "03-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu đề xuất ảnh để thử mới",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "cups",
      "worked": {
        "title": "Mẫu đề xuất ảnh để thử mới",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Vật cần thử",
          "Điều kiện mới",
          "Ảnh mẫu đã học",
          "Ảnh sẽ thử",
          "Tên đúng để đối chiếu"
        ],
        "values": [
          "Cốc",
          "Góc nghiêng, vật rõ",
          "Ảnh chính diện",
          "Chụp một ảnh mới, giữ ngoài bộ học",
          "Cốc theo đồ vật thật"
        ],
        "why": [
          "Nêu rõ điều kiện cần kiểm.",
          "Chưa biết kết quả khi chưa thử.",
          "Giữ ảnh mới trước lần thử."
        ],
        "question": "Em lấy tên đúng từ đâu?",
        "scene": "Cups"
      },
      "targetId": "03-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cốc theo đồ vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Vật cần thử: Cốc\nĐiều kiện mới: Góc nghiêng, vật rõ\nẢnh mẫu đã học: Ảnh chính diện\nẢnh sẽ thử: Chụp một ảnh mới, giữ ngoài bộ học\nTên đúng để đối chiếu: Cốc theo đồ vật thật"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Cốc mới có góc nghiêng khác ảnh đã học.\n2. Nói dễ hiểu: Ảnh mới giúp thử điều máy chưa gặp.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Vật cần thử: Cốc\nĐiều kiện mới: Góc nghiêng, vật rõ\nẢnh mẫu đã học: Ảnh chính diện\nẢnh sẽ thử: Chụp một ảnh mới, giữ ngoài bộ học\nTên đúng để đối chiếu: Cốc theo đồ vật thật",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 30,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Cốc mới có góc nghiêng khác ảnh đã học.",
          "tone": "key",
          "note": "Thầy/Cô: Cốc mới có góc nghiêng khác ảnh đã học."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh mới giúp thử điều máy chưa gặp.",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh mới giúp thử điều máy chưa gặp."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em lấy tên đúng từ đâu? Gợi ý: Cốc theo đồ vật thật"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P3.3 Đọc kết quả và chuẩn bị kiểm thử",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "B Ví dụ đổi góc bút, dùng cốc khác, đổi nền vừa phải. Có nhãn thật và không dùng ảnh đã dạy AI."
        ],
        "pages": [
          {
            "title": "Chuẩn bị ba lần thử mới",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Lần thử",
              "Vật và tên đúng",
              "Điều kiện muốn thử"
            ],
            "rows": [
              [
                "1",
                {
                  "label": "Vật ở lần 1",
                  "key": "03-23-v3-0"
                },
                {
                  "label": "Điều kiện lần 1",
                  "key": "03-23-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Chuẩn bị ba lần thử mới",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Lần thử",
              "Vật và tên đúng",
              "Điều kiện muốn thử"
            ],
            "rows": [
              [
                "2",
                {
                  "label": "Vật ở lần 2",
                  "key": "03-23-v3-2"
                },
                {
                  "label": "Điều kiện lần 2",
                  "key": "03-23-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Chuẩn bị ba lần thử mới",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Lần thử",
              "Vật và tên đúng",
              "Điều kiện muốn thử"
            ],
            "rows": [
              [
                "3",
                {
                  "label": "Vật ở lần 3",
                  "key": "03-23-v3-4"
                },
                {
                  "label": "Điều kiện lần 3",
                  "key": "03-23-v3-5"
                }
              ]
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 3,
      "id": "03-23",
      "title": "P3.3B — Chọn ba ảnh mới",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Hoàn thành đề xuất lần thử mới theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm thử cần đầu vào mới và nhãn thực để đối chiếu.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "B Ví dụ đổi góc bút, dùng cốc khác, đổi nền vừa phải. Có nhãn thật và không dùng ảnh đã dạy AI."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Chọn vật cần thử. Thay đổi điều kiện chụp. Chưa đoán trước đúng hay sai.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "B Ví dụ đổi góc bút, dùng cốc khác, đổi nền vừa phải. Có nhãn thật và không dùng ảnh đã dạy AI.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn vật cần thử.",
        "Thay đổi điều kiện chụp.",
        "Chưa đoán trước đúng hay sai."
      ],
      "phase": "Vận dụng",
      "scene": "cups",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "03-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 31,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn vật cần thử.",
        "Thay đổi điều kiện chụp.",
        "Chưa đoán trước đúng hay sai."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P3.3B · Em tự làm"
    },
    {
      "type": "home",
      "id": "03-24",
      "title": "Lưu để tiếp tục ở tiết sau",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Đề xuất cách chuẩn bị kiểm thử tiết sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm thử cần đầu vào mới và nhãn thực để đối chiếu.",
        "assessment": "Chấp nhận các biến đổi khác nhau. Loại yêu cầu thu ảnh người hoặc dùng đồ vật nguy hiểm.",
        "answers": [
          "Kiểm thử cần đầu vào mới và nhãn thực để đối chiếu."
        ],
        "source": "Bài 2 Dạy máy học, mục Thực hành Tạo và kiểm tra mô hình học máy, trang in 13; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh và Dạy máy tính phân loại hình ảnh, trang in 20.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Lưu tệp dự án.\n2. Nói dễ hiểu: Giữ thư mục ảnh có nhãn.\n3. Điều cần nhớ: Ghi vị trí lưu vào P3.2.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Kiểm thử cần đầu vào mới và nhãn thực để đối chiếu.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Lưu tệp dự án.",
        "Giữ thư mục ảnh có nhãn.",
        "Ghi vị trí lưu vào P3.2."
      ],
      "phase": "Vận dụng",
      "scene": "cups",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 32,
      "v7": true,
      "originalTeachingPoints": [
        "Lưu tệp dự án.",
        "Giữ thư mục ảnh có nhãn.",
        "Ghi vị trí lưu vào P3.2."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Lưu tệp dự án.",
          "tone": "key",
          "note": "Thầy/Cô: Lưu tệp dự án."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Giữ thư mục ảnh có nhãn.",
          "tone": "explain",
          "note": "Thầy/Cô: Giữ thư mục ảnh có nhãn."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi vị trí lưu vào P3.2.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi vị trí lưu vào P3.2."
        }
      ]
    }
  ],
  "rubric": [],
  "evidence": [
    [
      "Thu và sắp xếp ảnh",
      "1.3.TC1a",
      "Chọn ảnh rõ và tổ chức đúng lớp.",
      "P3.1, cấu trúc hai lớp",
      "Không nhầm nhãn; nếu sai phải sửa trước huấn luyện."
    ],
    [
      "Huấn luyện và xem trước",
      "6.2.TC1b",
      "Thực hiện tạo mô hình đơn giản.",
      "GV quan sát, P3.2 và lời giải thích từng em",
      "Có tham gia điều khiển ít nhất một bước; chỉ quan sát chưa đủ kết luận thao tác."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
