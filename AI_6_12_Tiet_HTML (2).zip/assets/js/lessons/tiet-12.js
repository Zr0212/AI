window.AI6_LESSON={
  "id": 12,
  "title": "Dự án tại nhà - Giai đoạn 4: Hoàn thiện và nộp sản phẩm",
  "mode": "Dự án tại nhà · tự làm, có thể chia phiên",
  "count": 21,
  "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 9,
    "title": "Ethics & AI: Equal Access and Algorithmic Bias",
    "start": 120,
    "end": 150,
    "poster": "frame_9_135.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/6bdcJTTcr9iESnI5jMsxGR/f61be02642cc453a5f03df83d0d4fffb/ai-06-ai-ethics-access-bias.mp4",
    "question": "Người dùng, quyền riêng tư, khả năng tiếp cận và việc kiểm tra kết quả đã được thể hiện chưa?",
    "local": "code-9.mp4"
  },
  "outcome": "Bản cuối, video 2–3 phút và những lỗi em đã sửa.",
  "slides": [
    {
      "type": "cover",
      "id": "12-01",
      "title": "Dự án tại nhà - Giai đoạn 4: Hoàn thiện và nộp sản phẩm",
      "note": {
        "activity": "Đọc và chọn góp ý",
        "purpose": "Xác định thay đổi có ích cho sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Nhóm ghi điều sẽ thay đổi trước khi sửa.",
        "conclusion": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "assessment": "Đạt khi lí do thay đổi liên quan chất lượng nội dung/người dùng.",
        "answers": [
          "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "storyboard",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "12-02",
      "title": "Giai đoạn này cần hoàn thành gì?",
      "note": {
        "activity": "Đọc và chọn góp ý",
        "purpose": "Xác định thay đổi có ích cho sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi điều sẽ thay đổi trước khi sửa.",
        "conclusion": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "assessment": "Đạt khi lí do thay đổi liên quan chất lượng nội dung/người dùng.",
        "answers": [
          "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Sửa ít nhất một điểm theo góp ý.\n2. Nói dễ hiểu: Tự đánh giá bằng minh chứng.\n3. Điều cần nhớ: Quay 2–3 phút, kiểm và nộp hồ sơ.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Sửa ít nhất một điểm theo góp ý.",
        "Tự đánh giá bằng minh chứng.",
        "Quay 2–3 phút, kiểm và nộp hồ sơ."
      ],
      "phase": "Khởi động",
      "scene": "storyboard",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Sửa ít nhất một điểm theo góp ý.",
        "Tự đánh giá bằng minh chứng.",
        "Quay 2–3 phút, kiểm và nộp hồ sơ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Sửa ít nhất một điểm theo góp ý.",
          "tone": "key",
          "note": "Thầy/Cô: Sửa ít nhất một điểm theo góp ý."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tự đánh giá bằng minh chứng.",
          "tone": "explain",
          "note": "Thầy/Cô: Tự đánh giá bằng minh chứng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Quay 2–3 phút, kiểm và nộp hồ sơ.",
          "tone": "action",
          "note": "Thầy/Cô: Quay 2–3 phút, kiểm và nộp hồ sơ."
        }
      ]
    },
    {
      "type": "divider",
      "id": "12-03",
      "title": "Khởi động: chọn góp ý",
      "note": {
        "activity": "Đọc và chọn góp ý",
        "purpose": "Xác định thay đổi có ích cho sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm ghi điều sẽ thay đổi trước khi sửa.",
        "conclusion": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "assessment": "Đạt khi lí do thay đổi liên quan chất lượng nội dung/người dùng.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "storyboard",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "id": "12-04",
      "title": "Chọn góp ý giúp sản phẩm tốt hơn",
      "note": {
        "activity": "Đọc và chọn góp ý",
        "purpose": "Xác định thay đổi có ích cho sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi điều sẽ thay đổi trước khi sửa.",
        "conclusion": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "assessment": "Đạt khi lí do thay đổi liên quan chất lượng nội dung/người dùng.",
        "answers": [
          "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đọc góp ý đã nhận.\n2. Nói dễ hiểu: Ưu tiên nội dung đúng và rõ.\n3. Điều cần nhớ: Không sửa máy móc mọi ý.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đọc góp ý đã nhận.",
        "Ưu tiên nội dung đúng và rõ.",
        "Không sửa máy móc mọi ý."
      ],
      "phase": "Khởi động",
      "scene": "storyboard",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Đọc góp ý đã nhận.",
        "Ưu tiên nội dung đúng và rõ.",
        "Không sửa máy móc mọi ý."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đọc góp ý đã nhận.",
          "tone": "key",
          "note": "Thầy/Cô: Đọc góp ý đã nhận."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ưu tiên nội dung đúng và rõ.",
          "tone": "explain",
          "note": "Thầy/Cô: Ưu tiên nội dung đúng và rõ."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không sửa máy móc mọi ý.",
          "tone": "action",
          "note": "Thầy/Cô: Không sửa máy móc mọi ý."
        }
      ]
    },
    {
      "type": "concept",
      "id": "12-07",
      "title": "Sửa để người dùng biết phải làm gì",
      "note": {
        "activity": "Đọc và chọn góp ý",
        "purpose": "Xác định thay đổi có ích cho sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi điều sẽ thay đổi trước khi sửa.",
        "conclusion": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "assessment": "Đạt khi lí do thay đổi liên quan chất lượng nội dung/người dùng.",
        "answers": [
          "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Bản trước thiếu bước kiểm nghĩa của từ.\n2. Nói dễ hiểu: Nhóm thêm người so bảng từ và sửa nghĩa sai.\n3. Điều cần nhớ: Ghi trước–sau và lí do của lần sửa.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Trước: chưa có người kiểm bản dịch.",
        "Sau: thêm đối chiếu bảng từ hoặc hỏi Thầy/Cô.",
        "Lí do: biết xử lí kết quả chưa rõ."
      ],
      "phase": "Khám phá",
      "scene": "storyboard",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [
        "Trước: chưa có người kiểm bản dịch.",
        "Sau: thêm đối chiếu bảng từ hoặc hỏi Thầy/Cô.",
        "Lí do: biết xử lí kết quả chưa rõ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Bản trước thiếu bước kiểm nghĩa của từ.",
          "tone": "key",
          "note": "Thầy/Cô: Bản trước thiếu bước kiểm nghĩa của từ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nhóm thêm người so bảng từ và sửa nghĩa sai.",
          "tone": "explain",
          "note": "Thầy/Cô: Nhóm thêm người so bảng từ và sửa nghĩa sai."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi trước–sau và lí do của lần sửa.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi trước–sau và lí do của lần sửa."
        }
      ]
    },
    {
      "id": "12-05-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu ghi một sửa có lí do",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "before-after",
      "worked": {
        "title": "Mẫu ghi một sửa có lí do",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Góp ý",
          "Quyết định",
          "Bản trước",
          "Bản sau",
          "Lí do"
        ],
        "values": [
          "Cần nói ai kiểm nghĩa",
          "Bổ sung bước người kiểm",
          "AI gợi nghĩa → thẻ từ",
          "AI gợi nghĩa → em kiểm → thẻ từ",
          "Người dùng biết phải kiểm trước khi học"
        ],
        "why": [
          "Ghi thay đổi thật, không chỉ nói đã sửa.",
          "Một góp ý có thể làm rõ trách nhiệm.",
          "Không cần làm theo mọi góp ý máy móc."
        ],
        "question": "Vì sao thay đổi này có ích?",
        "scene": "Before-after"
      },
      "targetId": "12-05",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Người dùng biết phải kiểm trước khi học",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Góp ý: Cần nói ai kiểm nghĩa\nQuyết định: Bổ sung bước người kiểm\nBản trước: AI gợi nghĩa → thẻ từ\nBản sau: AI gợi nghĩa → em kiểm → thẻ từ\nLí do: Người dùng biết phải kiểm trước khi học"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Bản trước chưa có người kiểm nghĩa.\n2. Nói dễ hiểu: Thêm bước người kiểm trước khi dùng thẻ từ.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Góp ý: Cần nói ai kiểm nghĩa\nQuyết định: Bổ sung bước người kiểm\nBản trước: AI gợi nghĩa → thẻ từ\nBản sau: AI gợi nghĩa → em kiểm → thẻ từ\nLí do: Người dùng biết phải kiểm trước khi học",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Bản trước chưa có người kiểm nghĩa.",
          "tone": "key",
          "note": "Thầy/Cô: Bản trước chưa có người kiểm nghĩa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thêm bước người kiểm trước khi dùng thẻ từ.",
          "tone": "explain",
          "note": "Thầy/Cô: Thêm bước người kiểm trước khi dùng thẻ từ."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Vì sao thay đổi này có ích? Gợi ý: Người dùng biết phải kiểm trước khi học"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P12.1 Tiếp nhận và sử dụng góp ý",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Ví dụ thêm câu Nếu bản dịch chưa rõ, đối chiếu bảng từ hoặc hỏi Thầy/Cô vì bản 1 chưa có xử lí khi sai. Chỉ đổi màu không đủ minh chứng cải thiện nội dung theo phản hồi.",
          "Nếu chưa áp dụng một góp ý, cần lí do phù hợp. Vẫn phải có ít nhất một chỉnh sửa có căn cứ."
        ],
        "pages": [
          {
            "title": "Đọc và chọn góp ý",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Góp ý là gì? Do ai góp ý?",
                "key": "12-05-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đọc và chọn góp ý",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm quyết định sửa điều gì? Vì sao?",
                "key": "12-05-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi thay đổi cụ thể",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Bản trước viết hoặc làm thế nào?",
                "key": "12-05-v3-2"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi thay đổi cụ thể",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Bản sau đã thay đổi thế nào?",
                "key": "12-05-v3-3"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi thay đổi cụ thể",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã trực tiếp sửa phần nào?",
                "key": "12-05-v3-4"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2
        }
      },
      "id": "12-05",
      "title": "P12.1 — Ghi thay đổi có lí do",
      "note": {
        "activity": "Đọc và chọn góp ý",
        "purpose": "Hoàn thành quyết định chỉnh sửa theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm ghi điều sẽ thay đổi trước khi sửa.",
        "conclusion": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Ví dụ thêm câu Nếu bản dịch chưa rõ, đối chiếu bảng từ hoặc hỏi Thầy/Cô vì bản 1 chưa có xử lí khi sai. Chỉ đổi màu không đủ minh chứng cải thiện nội dung theo phản hồi.",
          "Nếu chưa áp dụng một góp ý, cần lí do phù hợp. Vẫn phải có ít nhất một chỉnh sửa có căn cứ."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Góp ý nào, từ ai? Nhóm sửa phần nào, vì sao? Trước và sau khác nhau ở đâu?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Ví dụ thêm câu Nếu bản dịch chưa rõ, đối chiếu bảng từ hoặc hỏi Thầy/Cô vì bản 1 chưa có xử lí khi sai. Chỉ đổi màu không đủ minh chứng cải thiện nội dung theo phản hồi.\nNếu chưa áp dụng một góp ý, cần lí do phù hợp. Vẫn phải có ít nhất một chỉnh sửa có căn cứ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Góp ý nào, từ ai?",
        "Nhóm sửa phần nào, vì sao?",
        "Trước và sau khác nhau ở đâu?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "12-05-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Góp ý nào, từ ai?",
        "Nhóm sửa phần nào, vì sao?",
        "Trước và sau khác nhau ở đâu?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P12.1 · Ghi thay đổi"
    },
    {
      "type": "divider",
      "id": "12-09",
      "title": "Thực hành: hoàn thiện và giới thiệu",
      "note": {
        "activity": "Chỉnh sửa và giới thiệu",
        "purpose": "Hoàn thiện nội dung, quay video ngắn có cấu trúc.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm lưu bản cũ/bản cuối để chỉ ra thay đổi; kiểm tra thời lượng video.",
        "conclusion": "Giới thiệu phải giải thích đúng chức năng và giới hạn; video là minh chứng trình bày, không phải quảng cáo công cụ.",
        "assessment": "Đánh giá nội dung và thay đổi. Không kết luận đã nộp video nếu mới có kịch bản.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “quay phần 1–2 · tên và dùng thử”."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "12-v7-video12",
      "type": "guide",
      "title": "Quay phần 1–2 · Tên và dùng thử",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "30 giây: chào, tên dự án, giúp ai.",
        "60 giây: quay ví dụ dùng thử và cách kiểm.",
        "Quay rõ sản phẩm; không bắt buộc lộ mặt."
      ],
      "scene": "storyboard",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mở video để kiểm nghe, nhìn và thời lượng",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "30 giây: chào, tên dự án, giúp ai. / 60 giây: quay ví dụ dùng thử và cách kiểm. / Quay rõ sản phẩm; không bắt buộc lộ mặt."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Quay phần 1–2 · Tên và dùng thử.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: 30 giây: chào, tên dự án, giúp ai.\n2. Nói dễ hiểu: 60 giây: quay ví dụ dùng thử và cách kiểm.\n3. Điều cần nhớ: Quay rõ sản phẩm; không bắt buộc lộ mặt.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "30 giây: chào, tên dự án, giúp ai. / 60 giây: quay ví dụ dùng thử và cách kiểm. / Quay rõ sản phẩm; không bắt buộc lộ mặt.",
          "closing": "Thầy/Cô chốt: Quay rõ sản phẩm; không bắt buộc lộ mặt.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “quay phần 3–4 · lỗi và lời kết”."
        }
      },
      "number": 9,
      "originalTeachingPoints": [
        "30 giây: chào, tên dự án, giúp ai.",
        "60 giây: quay ví dụ dùng thử và cách kiểm.",
        "Quay rõ sản phẩm; không bắt buộc lộ mặt."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "30 giây: chào, tên dự án, giúp ai.",
          "tone": "key",
          "note": "Thầy/Cô: 30 giây: chào, tên dự án, giúp ai."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "60 giây: quay ví dụ dùng thử và cách kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: 60 giây: quay ví dụ dùng thử và cách kiểm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Quay rõ sản phẩm; không bắt buộc lộ mặt.",
          "tone": "action",
          "note": "Thầy/Cô: Quay rõ sản phẩm; không bắt buộc lộ mặt."
        }
      ]
    },
    {
      "id": "12-v7-video34",
      "type": "guide",
      "title": "Quay phần 3–4 · Lỗi và lời kết",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "30 giây: kể một lỗi và cách nhóm sửa.",
        "20 giây: nói giới hạn, nguồn và lời kết.",
        "Nếu chưa chạy AI, nói rõ đây là ý tưởng."
      ],
      "scene": "storyboard",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mở video để kiểm nghe, nhìn và thời lượng",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "30 giây: kể một lỗi và cách nhóm sửa. / 20 giây: nói giới hạn, nguồn và lời kết. / Nếu chưa chạy AI, nói rõ đây là ý tưởng."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Quay phần 3–4 · Lỗi và lời kết.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: 30 giây: kể một lỗi và cách nhóm sửa.\n2. Nói dễ hiểu: 20 giây: nói giới hạn, nguồn và lời kết.\n3. Điều cần nhớ: Nếu chưa chạy AI, nói rõ đây là ý tưởng.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "30 giây: kể một lỗi và cách nhóm sửa. / 20 giây: nói giới hạn, nguồn và lời kết. / Nếu chưa chạy AI, nói rõ đây là ý tưởng.",
          "closing": "Thầy/Cô chốt: Nếu chưa chạy AI, nói rõ đây là ý tưởng.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "number": 10,
      "originalTeachingPoints": [
        "30 giây: kể một lỗi và cách nhóm sửa.",
        "20 giây: nói giới hạn, nguồn và lời kết.",
        "Nếu chưa chạy AI, nói rõ đây là ý tưởng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "30 giây: kể một lỗi và cách nhóm sửa.",
          "tone": "key",
          "note": "Thầy/Cô: 30 giây: kể một lỗi và cách nhóm sửa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "20 giây: nói giới hạn, nguồn và lời kết.",
          "tone": "explain",
          "note": "Thầy/Cô: 20 giây: nói giới hạn, nguồn và lời kết."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nếu chưa chạy AI, nói rõ đây là ý tưởng.",
          "tone": "action",
          "note": "Thầy/Cô: Nếu chưa chạy AI, nói rõ đây là ý tưởng."
        }
      ]
    },
    {
      "id": "12-08-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu lời giới thiệu hai phút",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "worked": {
        "title": "Mẫu lời giới thiệu hai phút",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "0:00–0:30",
          "0:30–1:30",
          "1:30–2:00",
          "2:00–2:20",
          "Trước khi gửi"
        ],
        "values": [
          "Chào, tên dự án, giúp ai",
          "Quay một lần dùng và cách kiểm",
          "Kể lỗi có thật, nêu cách sửa",
          "Nói giới hạn, nguồn, lời kết",
          "Mở video; kiểm nghe, nhìn, dữ liệu riêng"
        ],
        "why": [
          "Mỗi phần nói đúng một nhóm ý.",
          "Ví dụ giúp người xem hiểu cách dùng.",
          "Không chỉ đọc tên các phần."
        ],
        "question": "Sau khi quay, em cần kiểm gì trước?",
        "scene": "Storyboard"
      },
      "targetId": "12-08",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mở video để kiểm nghe, nhìn và thời lượng",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "0:00–0:30: Chào, tên dự án, giúp ai\n0:30–1:30: Quay một lần dùng và cách kiểm\n1:30–2:00: Kể lỗi có thật, nêu cách sửa\n2:00–2:20: Nói giới hạn, nguồn, lời kết\nTrước khi gửi: Mở video; kiểm nghe, nhìn, dữ liệu riêng"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm chuẩn bị video khoảng 140 giây.\n2. Nói dễ hiểu: Quay bốn phần; khoảng 140 giây là một gợi ý.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "0:00–0:30: Chào, tên dự án, giúp ai\n0:30–1:30: Quay một lần dùng và cách kiểm\n1:30–2:00: Kể lỗi có thật, nêu cách sửa\n2:00–2:20: Nói giới hạn, nguồn, lời kết\nTrước khi gửi: Mở video; kiểm nghe, nhìn, dữ liệu riêng",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm chuẩn bị video khoảng 140 giây.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm chuẩn bị video khoảng 140 giây."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Quay bốn phần; khoảng 140 giây là một gợi ý.",
          "tone": "explain",
          "note": "Thầy/Cô: Quay bốn phần; khoảng 140 giây là một gợi ý."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Sau khi quay, em cần kiểm gì trước? Gợi ý: Mở video; kiểm nghe, nhìn, dữ liệu riêng"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P12.2A Viết kịch bản",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Tổng gợi ý khoảng 2–2 phút 40 giây. Thầy/Cô chấp nhận 2–3 phút theo khung. Không chấm theo hiệu ứng hoặc giọng đọc chuyên nghiệp.",
          "Nhóm chưa quay được cần được hỗ trợ và ghi rõ thiếu video, không coi kịch bản đã là video."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Phần 1 · 30 giây: chào, tên dự án và giúp ai.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Phần 2 · 60 giây: quay một lần dùng và cách kiểm.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Phần 3 · 30 giây: kể một lỗi và cách nhóm sửa.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Phần 4 · 20 giây: giới hạn, nguồn và lời kết.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Chia thời gian giới thiệu",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm phân công ai giới thiệu phần nào?",
                "key": "12-08-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Viết lời giới thiệu — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Lời mở đầu",
                "key": "12-08-v3-1"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Viết lời giới thiệu — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Lời giải thích cách dự án hoạt động",
                "key": "12-08-v3-2"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Viết lời giới thiệu — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ví dụ sử dụng và cách kiểm tra",
                "key": "12-08-v3-3"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Viết lời giới thiệu — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Giới hạn, nguồn và điều đã sửa sau góp ý",
                "key": "12-08-v3-4"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 5,
          "2": 7
        }
      },
      "id": "12-08",
      "title": "P12.2A — Viết lời giới thiệu",
      "note": {
        "activity": "Chỉnh sửa và giới thiệu",
        "purpose": "Hoàn thành kịch bản video 2–3 phút theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm lưu bản cũ/bản cuối để chỉ ra thay đổi; kiểm tra thời lượng video.",
        "conclusion": "Giới thiệu phải giải thích đúng chức năng và giới hạn; video là minh chứng trình bày, không phải quảng cáo công cụ.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Tổng gợi ý khoảng 2–2 phút 40 giây. Thầy/Cô chấp nhận 2–3 phút theo khung. Không chấm theo hiệu ứng hoặc giọng đọc chuyên nghiệp.",
          "Nhóm chưa quay được cần được hỗ trợ và ghi rõ thiếu video, không coi kịch bản đã là video."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Nêu vấn đề và cách hoạt động. Dùng một ví dụ cùng cách kiểm. Nói giới hạn, nguồn và điều đã sửa.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Tổng gợi ý khoảng 2–2 phút 40 giây. Thầy/Cô chấp nhận 2–3 phút theo khung. Không chấm theo hiệu ứng hoặc giọng đọc chuyên nghiệp.\nNhóm chưa quay được cần được hỗ trợ và ghi rõ thiếu video, không coi kịch bản đã là video.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nêu vấn đề và cách hoạt động.",
        "Dùng một ví dụ cùng cách kiểm.",
        "Nói giới hạn, nguồn và điều đã sửa."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "12-08-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [
        "Nêu vấn đề và cách hoạt động.",
        "Dùng một ví dụ cùng cách kiểm.",
        "Nói giới hạn, nguồn và điều đã sửa."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P12.2A · Soạn lời giới thiệu"
    },
    {
      "id": "12-10-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu kiểm bản quay đã mở",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "worked": {
        "title": "Mẫu kiểm bản quay đã mở",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Thời lượng",
          "Âm thanh",
          "Hình ảnh",
          "Thông tin riêng",
          "Kết luận kiểm"
        ],
        "values": [
          "Khoảng 2 phút 20 giây trong ví dụ",
          "Nghe được lời giới thiệu",
          "Nhìn rõ sản phẩm và ví dụ",
          "Không có tên thật, liên hệ hoặc địa chỉ",
          "Chỉ gửi sau khi em mở tệp và tự kiểm"
        ],
        "why": [
          "Thời lượng không thay chất lượng nội dung.",
          "Không bắt buộc lộ mặt.",
          "Chưa quay thì ghi rõ cần hỗ trợ."
        ],
        "question": "Khi nào em có thể đánh dấu đã kiểm?",
        "scene": "Storyboard"
      },
      "targetId": "12-10",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Chỉ gửi sau khi em mở tệp và tự kiểm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Thời lượng: Khoảng 2 phút 20 giây trong ví dụ\nÂm thanh: Nghe được lời giới thiệu\nHình ảnh: Nhìn rõ sản phẩm và ví dụ\nThông tin riêng: Không có tên thật, liên hệ hoặc địa chỉ\nKết luận kiểm: Chỉ gửi sau khi em mở tệp và tự kiểm"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Video cần được mở lại trước khi nộp.\n2. Nói dễ hiểu: Đánh dấu đã kiểm chỉ sau khi mở video thật.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Thời lượng: Khoảng 2 phút 20 giây trong ví dụ\nÂm thanh: Nghe được lời giới thiệu\nHình ảnh: Nhìn rõ sản phẩm và ví dụ\nThông tin riêng: Không có tên thật, liên hệ hoặc địa chỉ\nKết luận kiểm: Chỉ gửi sau khi em mở tệp và tự kiểm",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Video cần được mở lại trước khi nộp.",
          "tone": "key",
          "note": "Thầy/Cô: Video cần được mở lại trước khi nộp."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đánh dấu đã kiểm chỉ sau khi mở video thật.",
          "tone": "explain",
          "note": "Thầy/Cô: Đánh dấu đã kiểm chỉ sau khi mở video thật."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Khi nào em có thể đánh dấu đã kiểm? Gợi ý: Chỉ gửi sau khi em mở tệp và tự kiểm"
        }
      ]
    },
    {
      "type": "worksheet",
      "id": "12-10",
      "title": "P12.2B — Quay rồi mở lại để kiểm",
      "note": {
        "activity": "Chỉnh sửa và giới thiệu",
        "purpose": "Hoàn thiện nội dung, quay video ngắn có cấu trúc.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm lưu bản cũ/bản cuối để chỉ ra thay đổi; kiểm tra thời lượng video.",
        "conclusion": "Giới thiệu phải giải thích đúng chức năng và giới hạn; video là minh chứng trình bày, không phải quảng cáo công cụ.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Video 2–3 phút, nói rõ chức năng/ví dụ, phần AI hỗ trợ và con người kiểm tra.",
          "Không bắt buộc lộ mặt. Nếu thiếu video hoặc tệp lỗi, ghi đúng để Thầy/Cô hỗ trợ."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Nhìn và nghe rõ: Quay sản phẩm kèm thuyết minh. Không bắt buộc lộ mặt.\nGiới thiệu 2–3 phút: Chức năng, ví dụ, phần AI hỗ trợ, phần người kiểm tra.\nXem lại trước gửi: Kiểm âm thanh/hình ảnh, dữ liệu riêng và tệp có mở được không.\nÝ cần giảng rõ: Quay sản phẩm và lời giới thiệu. Không bắt buộc lộ mặt. Mở lại: đủ nghe, nhìn và an toàn?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Video 2–3 phút, nói rõ chức năng/ví dụ, phần AI hỗ trợ và con người kiểm tra.\nKhông bắt buộc lộ mặt. Nếu thiếu video hoặc tệp lỗi, ghi đúng để Thầy/Cô hỗ trợ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "worksheet": {
        "title": "P12.2B Quay và kiểm tra",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Video 2–3 phút, nói rõ chức năng/ví dụ, phần AI hỗ trợ và con người kiểm tra.",
          "Không bắt buộc lộ mặt. Nếu thiếu video hoặc tệp lỗi, ghi đúng để Thầy/Cô hỗ trợ."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Quay đủ nghe và nhìn. Mở lại để kiểm thời lượng và thông tin riêng.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Nếu chưa quay được, ghi phần còn thiếu và hỗ trợ cần hỏi.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Quay xong, mở video để kiểm tra",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Video dài bao lâu? Nghe và nhìn có rõ không?",
                "key": "12-08-v3-5"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Quay xong, mở video để kiểm tra",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có lộ thông tin cá nhân không cần thiết không?",
                "key": "12-08-v3-6"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Quay xong, mở video để kiểm tra",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tệp đã mở thử được chưa? Còn cần hỗ trợ gì?",
                "key": "12-08-v3-7"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "v6": true,
      "screen": [
        "Quay sản phẩm và lời giới thiệu.",
        "Không bắt buộc lộ mặt.",
        "Mở lại: đủ nghe, nhìn và an toàn?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "12-10-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [
        "Quay sản phẩm và lời giới thiệu.",
        "Không bắt buộc lộ mặt.",
        "Mở lại: đủ nghe, nhìn và an toàn?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P12.2B · Kiểm video"
    },
    {
      "type": "concept",
      "id": "12-11",
      "title": "Hồ sơ cuối có những gì?",
      "note": {
        "activity": "Chỉnh sửa và giới thiệu",
        "purpose": "Hoàn thiện nội dung, quay video ngắn có cấu trúc.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu bản cũ/bản cuối để chỉ ra thay đổi; kiểm tra thời lượng video.",
        "conclusion": "Giới thiệu phải giải thích đúng chức năng và giới hạn; video là minh chứng trình bày, không phải quảng cáo công cụ.",
        "assessment": "Đánh giá nội dung và thay đổi. Không kết luận đã nộp video nếu mới có kịch bản.",
        "answers": [
          "Hồ sơ gồm sản phẩm cuối, video giới thiệu 2–3 phút và các bảng ghi theo yêu cầu của lớp.",
          "Các tệp mở được, có nguồn và không chứa thông tin cá nhân không cần thiết. Ghi đúng phần còn thiếu, không đánh dấu đã đủ khi chưa có."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm sắp nộp sản phẩm và video.\n2. Nói dễ hiểu: Người nhận cần mở tệp và xem được phần kiểm.\n3. Điều cần nhớ: Kèm nguồn, thay đổi và đóng góp có thật.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Hồ sơ gồm sản phẩm cuối, video giới thiệu 2–3 phút và các bảng ghi theo yêu cầu của lớp.\nCác tệp mở được, có nguồn và không chứa thông tin cá nhân không cần thiết. Ghi đúng phần còn thiếu, không đánh dấu đã đủ khi chưa có.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Sản phẩm cuối và video.",
        "Tự đánh giá, bảng ghi thay đổi và đóng góp.",
        "Nguồn rõ, dữ liệu phù hợp, tệp mở được."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [
        "Sản phẩm cuối và video.",
        "Tự đánh giá, bảng ghi thay đổi và đóng góp.",
        "Nguồn rõ, dữ liệu phù hợp, tệp mở được."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm sắp nộp sản phẩm và video.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm sắp nộp sản phẩm và video."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Người nhận cần mở tệp và xem được phần kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: Người nhận cần mở tệp và xem được phần kiểm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Kèm nguồn, thay đổi và đóng góp có thật.",
          "tone": "action",
          "note": "Thầy/Cô: Kèm nguồn, thay đổi và đóng góp có thật."
        }
      ]
    },
    {
      "type": "divider",
      "id": "12-12",
      "title": "Tự đánh giá bằng minh chứng",
      "note": {
        "activity": "Tự đánh giá và kiểm tra an toàn",
        "purpose": "Kiểm tra bản cuối và tự nhận xét có căn cứ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm thống nhất điểm còn cần cải thiện, không ép mọi thành viên tự chấm giống nhau.",
        "conclusion": "Tự đánh giá trung thực giúp nhận rõ điều đã làm được và điều cần hỗ trợ.",
        "assessment": "Đạt khi điểm gắn bằng chứng. Không dùng tự chấm thay kết luận của Thầy/Cô.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "12-13-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu tự chấm bằng bằng chứng",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "rubric",
      "worked": {
        "title": "Mẫu tự chấm bằng bằng chứng",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Mục tiêu: chọn 2",
          "Chức năng AI: chọn 2",
          "An toàn: chọn 1",
          "Nguồn / quá trình: chọn 2",
          "Hợp tác / giới thiệu"
        ],
        "values": [
          "Nêu rõ ba từ, người dùng và cách kiểm",
          "Ghi đúng áp phích là ý tưởng minh họa",
          "Có người kiểm. Cần ghi rõ dữ liệu không thu",
          "Có nguồn và những lỗi đã sửa",
          "Chọn mức phù hợp rồi chỉ minh chứng"
        ],
        "why": [
          "Điểm phải khớp mô tả của tiêu chí.",
          "Không đủ bằng chứng thì chưa chọn tối đa.",
          "Ô trống khác với đã chọn 0."
        ],
        "question": "Em cần xem minh chứng nào trước khi chọn ô cuối?",
        "scene": "Rubric"
      },
      "targetId": "12-13",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Chọn mức phù hợp rồi chỉ minh chứng",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Mục tiêu: chọn 2: Nêu rõ ba từ, người dùng và cách kiểm\nChức năng AI: chọn 2: Ghi đúng áp phích là ý tưởng minh họa\nAn toàn: chọn 1: Có người kiểm. Cần ghi rõ dữ liệu không thu\nNguồn / quá trình: chọn 2: Có nguồn và những lỗi đã sửa\nHợp tác / giới thiệu: Chọn mức phù hợp rồi chỉ minh chứng"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em chấm điểm bằng chi tiết có trong sản phẩm.\n2. Nói dễ hiểu: Chọn mức điểm khớp bằng chứng, không chấm theo cảm giác.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Mục tiêu: chọn 2: Nêu rõ ba từ, người dùng và cách kiểm\nChức năng AI: chọn 2: Ghi đúng áp phích là ý tưởng minh họa\nAn toàn: chọn 1: Có người kiểm. Cần ghi rõ dữ liệu không thu\nNguồn / quá trình: chọn 2: Có nguồn và những lỗi đã sửa\nHợp tác / giới thiệu: Chọn mức phù hợp rồi chỉ minh chứng",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em chấm điểm bằng chi tiết có trong sản phẩm.",
          "tone": "key",
          "note": "Thầy/Cô: Em chấm điểm bằng chi tiết có trong sản phẩm."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chọn mức điểm khớp bằng chứng, không chấm theo cảm giác.",
          "tone": "explain",
          "note": "Thầy/Cô: Chọn mức điểm khớp bằng chứng, không chấm theo cảm giác."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em cần xem minh chứng nào trước khi chọn ô cuối? Gợi ý: Chọn mức phù hợp rồi chỉ minh chứng"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P12.3 Tự đánh giá và hồ sơ nộp",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Mỗi điểm tự chấm phải có chi tiết trong sản phẩm hoặc bảng ghi làm căn cứ. Cộng năm tiêu chí, tối đa 10 điểm.",
          "Bộ hồ sơ có sản phẩm cuối, video 2–3 phút, tự đánh giá và ghi chép thay đổi/đóng góp. Nếu thiếu phần nào, ghi rõ để Thầy/Cô hỗ trợ."
        ],
        "pages": [
          {
            "title": "Mục tiêu",
            "reference": "0 điểm: Chưa rõ người dùng hoặc việc cần giúp.",
            "referenceLabel": "Tiêu chí 1 · Mục tiêu",
            "referenceOnly": true,
            "originalPage": 0
          },
          {
            "title": "Mục tiêu",
            "reference": "1 điểm: Đã rõ người dùng, nhưng việc còn rộng.",
            "referenceLabel": "Tiêu chí 1 · Mục tiêu",
            "referenceOnly": true,
            "originalPage": 0
          },
          {
            "title": "Mục tiêu",
            "reference": "2 điểm: Người dùng, việc và dấu hiệu hoàn thành rõ, vừa sức.",
            "referenceLabel": "Tiêu chí 1 · Mục tiêu",
            "referenceOnly": true,
            "originalPage": 0
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tiêu chí 1 — điểm nhóm tự chấm",
                "options": [
                  "0",
                  "1",
                  "2"
                ],
                "key": "12-13-v3-0",
                "optionLabels": [
                  "0",
                  "1",
                  "2"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Minh chứng cho tiêu chí 1",
                "key": "12-13-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Chức năng AI",
            "reference": "0 điểm: Nêu sai hoặc chưa có căn cứ về AI.",
            "referenceLabel": "Tiêu chí 2 · Chức năng AI",
            "referenceOnly": true,
            "originalPage": 1
          },
          {
            "title": "Chức năng AI",
            "reference": "1 điểm: Có đầu vào, đầu ra; cách hoạt động chưa rõ.",
            "referenceLabel": "Tiêu chí 2 · Chức năng AI",
            "referenceOnly": true,
            "originalPage": 1
          },
          {
            "title": "Chức năng AI",
            "reference": "2 điểm: Đúng tính năng, có ví dụ; nói rõ ý tưởng hay đã chạy.",
            "referenceLabel": "Tiêu chí 2 · Chức năng AI",
            "referenceOnly": true,
            "originalPage": 1
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tiêu chí 2 — điểm nhóm tự chấm",
                "options": [
                  "0",
                  "1",
                  "2"
                ],
                "key": "12-13-v3-2",
                "optionLabels": [
                  "0",
                  "1",
                  "2"
                ]
              }
            ],
            "originalPage": 1
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Minh chứng cho tiêu chí 2",
                "key": "12-13-v3-3"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Con người, an toàn",
            "reference": "0 điểm: Thiếu người kiểm hoặc lộ thông tin riêng không cần thiết.",
            "referenceLabel": "Tiêu chí 3 · Con người, an toàn",
            "referenceOnly": true,
            "originalPage": 2
          },
          {
            "title": "Con người, an toàn",
            "reference": "1 điểm: Có người kiểm; cách kiểm hoặc bảo vệ thông tin chưa rõ.",
            "referenceLabel": "Tiêu chí 3 · Con người, an toàn",
            "referenceOnly": true,
            "originalPage": 2
          },
          {
            "title": "Con người, an toàn",
            "reference": "2 điểm: Có cách kiểm, sửa khi sai; chỉ dùng dữ liệu cần.",
            "referenceLabel": "Tiêu chí 3 · Con người, an toàn",
            "referenceOnly": true,
            "originalPage": 2
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tiêu chí 3 — điểm nhóm tự chấm",
                "options": [
                  "0",
                  "1",
                  "2"
                ],
                "key": "12-13-v3-4",
                "optionLabels": [
                  "0",
                  "1",
                  "2"
                ]
              }
            ],
            "originalPage": 2
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Minh chứng cho tiêu chí 3",
                "key": "12-13-v3-5"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Nguồn, quá trình",
            "reference": "0 điểm: Thiếu phần chính, nguồn hoặc ghi chép quá trình.",
            "referenceLabel": "Tiêu chí 4 · Nguồn, quá trình",
            "referenceOnly": true,
            "originalPage": 3
          },
          {
            "title": "Nguồn, quá trình",
            "reference": "1 điểm: Đọc được; nguồn hoặc ghi chép còn thiếu.",
            "referenceLabel": "Tiêu chí 4 · Nguồn, quá trình",
            "referenceOnly": true,
            "originalPage": 3
          },
          {
            "title": "Nguồn, quá trình",
            "reference": "2 điểm: Đủ, dễ xem; nguồn mở lại được, có ghi quá trình.",
            "referenceLabel": "Tiêu chí 4 · Nguồn, quá trình",
            "referenceOnly": true,
            "originalPage": 3
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 4",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tiêu chí 4 — điểm nhóm tự chấm",
                "options": [
                  "0",
                  "1",
                  "2"
                ],
                "key": "12-13-v3-6",
                "optionLabels": [
                  "0",
                  "1",
                  "2"
                ]
              }
            ],
            "originalPage": 3
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 4",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Minh chứng cho tiêu chí 4",
                "key": "12-13-v3-7"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Hợp tác, giới thiệu",
            "reference": "0 điểm: Chưa ghi việc, sửa bài hoặc giới thiệu sản phẩm.",
            "referenceLabel": "Tiêu chí 5 · Hợp tác, giới thiệu",
            "referenceOnly": true,
            "originalPage": 4
          },
          {
            "title": "Hợp tác, giới thiệu",
            "reference": "1 điểm: Có đóng góp; lí do sửa hoặc minh chứng chưa rõ.",
            "referenceLabel": "Tiêu chí 5 · Hợp tác, giới thiệu",
            "referenceOnly": true,
            "originalPage": 4
          },
          {
            "title": "Hợp tác, giới thiệu",
            "reference": "2 điểm: Có đóng góp, sửa có lí do; video rõ vai AI/người.",
            "referenceLabel": "Tiêu chí 5 · Hợp tác, giới thiệu",
            "referenceOnly": true,
            "originalPage": 4
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 5",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tiêu chí 5 — điểm nhóm tự chấm",
                "options": [
                  "0",
                  "1",
                  "2"
                ],
                "key": "12-13-v3-8",
                "optionLabels": [
                  "0",
                  "1",
                  "2"
                ]
              }
            ],
            "originalPage": 4
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Tự đánh giá tiêu chí 5",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Minh chứng cho tiêu chí 5",
                "key": "12-13-v3-9"
              }
            ],
            "originalPage": 4
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Kiểm tra bộ hồ sơ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Sản phẩm, video và các bảng ghi đã đủ chưa?",
                "key": "12-13-v3-10"
              }
            ],
            "originalPage": 5
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Kiểm tra bộ hồ sơ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn, thông tin riêng và tệp đã kiểm chưa?",
                "key": "12-13-v3-11"
              }
            ],
            "originalPage": 5
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Nhìn lại phần việc cá nhân",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã làm và sửa phần nào?",
                "key": "12-13-v3-13"
              }
            ],
            "originalPage": 6
          },
          {
            "totalKeys": [
              "12-13-v3-0",
              "12-13-v3-2",
              "12-13-v3-4",
              "12-13-v3-6",
              "12-13-v3-8"
            ],
            "title": "Nhìn lại phần việc cá nhân",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Một điều em học được và muốn làm tốt hơn lần sau",
                "key": "12-13-v4-reflection"
              }
            ],
            "originalPage": 6
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 5,
          "2": 10,
          "3": 15,
          "4": 20
        }
      },
      "id": "12-13",
      "title": "P12.3 — Có minh chứng rồi chấm điểm",
      "note": {
        "activity": "Tự đánh giá và kiểm tra an toàn",
        "purpose": "Hoàn thành tự đánh giá bằng minh chứng theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm thống nhất điểm còn cần cải thiện, không ép mọi thành viên tự chấm giống nhau.",
        "conclusion": "Tự đánh giá trung thực giúp nhận rõ điều đã làm được và điều cần hỗ trợ.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Mỗi điểm tự chấm phải có chi tiết trong sản phẩm hoặc bảng ghi làm căn cứ. Cộng năm tiêu chí, tối đa 10 điểm.",
          "Bộ hồ sơ có sản phẩm cuối, video 2–3 phút, tự đánh giá và ghi chép thay đổi/đóng góp. Nếu thiếu phần nào, ghi rõ để Thầy/Cô hỗ trợ."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Để trống khác chọn 0. Tự chấm cần minh chứng. Tổng điểm không thay nhận xét của Thầy/Cô. Năm tiêu chí và mô tả 0–2 dùng lại từ hướng dẫn dự án.\nÝ cần giảng rõ: Đọc mô tả mức 0–2. Chỉ chi tiết làm minh chứng. Chọn điểm rồi nhìn lại phần việc.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Mỗi điểm tự chấm phải có chi tiết trong sản phẩm hoặc bảng ghi làm căn cứ. Cộng năm tiêu chí, tối đa 10 điểm.\nBộ hồ sơ có sản phẩm cuối, video 2–3 phút, tự đánh giá và ghi chép thay đổi/đóng góp. Nếu thiếu phần nào, ghi rõ để Thầy/Cô hỗ trợ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đọc mô tả mức 0–2.",
        "Chỉ chi tiết làm minh chứng.",
        "Chọn điểm rồi nhìn lại phần việc."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "12-13-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Đọc mô tả mức 0–2.",
        "Chỉ chi tiết làm minh chứng.",
        "Chọn điểm rồi nhìn lại phần việc."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P12.3 · Tự chấm"
    },
    {
      "type": "recap",
      "id": "12-14",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Tự đánh giá và kiểm tra an toàn",
        "purpose": "Kiểm tra bản cuối và tự nhận xét có căn cứ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm thống nhất điểm còn cần cải thiện, không ép mọi thành viên tự chấm giống nhau.",
        "conclusion": "Tự đánh giá trung thực giúp nhận rõ điều đã làm được và điều cần hỗ trợ.",
        "assessment": "Đạt khi điểm gắn bằng chứng. Không dùng tự chấm thay kết luận của Thầy/Cô.",
        "answers": [
          "Tự đánh giá trung thực giúp nhận rõ điều đã làm được và điều cần hỗ trợ."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Sửa có lí do và ghi trước–sau.\n2. Nói dễ hiểu: Kiểm nguồn, dữ liệu riêng và khả năng mở tệp.\n3. Điều cần nhớ: Giới thiệu rõ phần AI và phần con người.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tự đánh giá trung thực giúp nhận rõ điều đã làm được và điều cần hỗ trợ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Sửa có lí do và ghi trước–sau.",
        "Kiểm nguồn, dữ liệu riêng và khả năng mở tệp.",
        "Giới thiệu rõ phần AI và phần con người."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "storyboard",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "Sửa có lí do và ghi trước–sau.",
        "Kiểm nguồn, dữ liệu riêng và khả năng mở tệp.",
        "Giới thiệu rõ phần AI và phần con người."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Sửa có lí do và ghi trước–sau.",
          "tone": "key",
          "note": "Thầy/Cô: Sửa có lí do và ghi trước–sau."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Kiểm nguồn, dữ liệu riêng và khả năng mở tệp.",
          "tone": "explain",
          "note": "Thầy/Cô: Kiểm nguồn, dữ liệu riêng và khả năng mở tệp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Giới thiệu rõ phần AI và phần con người.",
          "tone": "action",
          "note": "Thầy/Cô: Giới thiệu rõ phần AI và phần con người."
        }
      ]
    },
    {
      "type": "divider",
      "id": "12-15",
      "title": "Vận dụng: nộp và nhìn lại",
      "note": {
        "activity": "Nộp và nhận xét cuối dự án",
        "purpose": "Chia sẻ đúng phạm vi và nhận phản hồi.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Mỗi em viết câu tổng kết ngắn về vai trò kiểm tra của con người.",
        "conclusion": "Dự án hoàn thành khi nội dung, quá trình và việc chia sẻ được kiểm tra; những phần còn thiếu phải được ghi rõ.",
        "assessment": "Thầy/Cô tách điểm sản phẩm với nhận xét năng lực số. Xác định hỗ trợ cho nhóm chưa quay/nộp được trực tuyến.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Bản cần gửi đã có. Em mở thử trước khi nộp."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "storyboard",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "submission",
      "id": "12-16",
      "title": "Nộp bản cuối và nhìn lại",
      "note": {
        "activity": "Nộp và nhận xét cuối dự án",
        "purpose": "Chia sẻ đúng phạm vi và nhận phản hồi.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
        "report": "Mỗi em viết câu tổng kết ngắn về vai trò kiểm tra của con người.",
        "conclusion": "Dự án hoàn thành khi nội dung, quá trình và việc chia sẻ được kiểm tra; những phần còn thiếu phải được ghi rõ.",
        "assessment": "Thầy/Cô tách điểm sản phẩm với nhận xét năng lực số. Xác định hỗ trợ cho nhóm chưa quay/nộp được trực tuyến.",
        "answers": [
          "Dự án hoàn thành khi nội dung, quá trình và việc chia sẻ được kiểm tra. Những phần còn thiếu phải được ghi rõ."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Bản cần gửi đã có. Em mở thử trước khi nộp.",
          "explanation": "Nộp sản phẩm cuối, video giới thiệu và các bảng ghi theo kênh Thầy/Cô đã thông báo. Mở thử các tệp trước khi gửi.\nÝ cần giảng rõ: Mở thử các tệp lần cuối. Nộp đúng kênh Thầy/Cô thông báo. Nói một điều em đã học được.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
          "answer": "Dự án hoàn thành khi nội dung, quá trình và việc chia sẻ được kiểm tra. Những phần còn thiếu phải được ghi rõ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mở thử các tệp lần cuối.",
        "Nộp đúng kênh Thầy/Cô thông báo.",
        "Nói một điều em đã học được."
      ],
      "phase": "Vận dụng",
      "scene": "storyboard",
      "taskLines": [
        "Trong 3 phút, em kiểm hồ sơ ở thư mục.",
        "Sau đó, em gửi tệp theo kênh của lớp."
      ],
      "connector": "Bản cần gửi đã có. Em mở thử trước khi nộp.",
      "number": 21,
      "v7": true,
      "originalTeachingPoints": [
        "Mở thử các tệp lần cuối.",
        "Nộp đúng kênh Thầy/Cô thông báo.",
        "Nói một điều em đã học được."
      ],
      "pupilTask": "Em kiểm tệp; ghi phần việc rồi tải bài."
    }
  ],
  "rubric": [
    [
      "1 Vấn đề và tính khả thi",
      "Chưa nêu vấn đề/người dùng hoặc mục tiêu không thể thực hiện.",
      "Có vấn đề/người dùng nhưng mục tiêu hoặc cách thực hiện còn rộng.",
      "Vấn đề, người dùng, mục tiêu rõ. Hình thức và quy mô phù hợp điều kiện."
    ],
    [
      "2 Chức năng AI và chính xác",
      "Không mô tả đúng AI hoặc gán chức năng không có bằng chứng.",
      "Có đầu vào/đầu ra. Còn thiếu liên kết hoặc chưa rõ mức đã làm.",
      "Chức năng, đầu vào/đầu ra và ví dụ đúng. Ghi rõ minh họa hay hoạt động thật."
    ],
    [
      "3 Con người và an toàn",
      "Chưa có bước kiểm tra. Hoặc còn chia sẻ thông tin riêng không cần thiết.",
      "Có người kiểm tra nhưng cách kiểm/điều kiện riêng tư còn chung chung.",
      "Có nguồn kiểm và cách xử lí khi sai. Con người quyết định. Chỉ dùng dữ liệu cần thiết."
    ],
    [
      "4 Sản phẩm nguồn và quá trình",
      "Thiếu phần chính, nguồn hoặc bằng chứng quá trình.",
      "Sản phẩm đọc được. Còn thiếu phần, nguồn khó xem lại hoặc bảng ghi chưa rõ.",
      "Đủ nội dung. Nguồn mở lại được. Sản phẩm dễ xem. Có bảng ghi quá trình."
    ],
    [
      "5 Hợp tác chỉnh sửa giới thiệu",
      "Chưa có đóng góp, góp ý hoặc sửa bài. Chưa giới thiệu sản phẩm.",
      "Có phân công hoặc sửa nhưng lí do chưa rõ. Giới thiệu chưa đủ hoặc còn thiếu minh chứng.",
      "Có đóng góp và một sửa có lí do. Video 2–3 phút nêu rõ vai AI và người."
    ]
  ],
  "evidence": [
    [
      "Tích hợp góp ý",
      "3.2.TC1a",
      "Chỉnh sửa và hoàn thiện theo phản hồi.",
      "P12.1, bản 1/bản cuối",
      "Có thay đổi cụ thể và lí do; không chỉ đổi màu."
    ],
    [
      "Nộp và chia sẻ",
      "2.2.TC1a",
      "Chọn cách nộp phù hợp và đúng phạm vi.",
      "Tệp nộp, xác nhận nhận, P12.3",
      "Mở được, không lộ dữ liệu, có video; thiếu thiết bị thì ghi rõ minh chứng chờ bổ sung."
    ]
  ],
  "review": {
    "type": "video",
    "video": {
      "index": 9,
      "title": "Ethics & AI: Equal Access and Algorithmic Bias",
      "start": 120,
      "end": 150,
      "poster": "frame_9_135.jpg",
      "url": "https://contentful-videos.code.org/90t6bu6vlf76/6bdcJTTcr9iESnI5jMsxGR/f61be02642cc453a5f03df83d0d4fffb/ai-06-ai-ethics-access-bias.mp4",
      "question": "Ai kiểm kết quả và dữ liệu riêng trước khi nộp?",
      "local": "code-9.mp4"
    },
    "optional": true,
    "id": "12-06",
    "number": 6,
    "title": "Ôn nhanh: trước khi chia sẻ sản phẩm",
    "note": {
      "activity": "Đọc và chọn góp ý",
      "purpose": "Xác định thay đổi có ích cho sản phẩm.",
      "teacher": "GV gửi góp ý rõ vị trí và yêu cầu, ví dụ thêm bước đối chiếu bản dịch bằng bảng từ. Nhận câu hỏi qua kênh lớp; không đòi tất cả thành viên trực tuyến cùng lúc.",
      "students": "Đọc độc lập, trao đổi và ghi góp ý ưu tiên.",
      "report": "Nhóm ghi điều sẽ thay đổi trước khi sửa.",
      "conclusion": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
      "assessment": "Đạt khi lí do thay đổi liên quan chất lượng nội dung/người dùng.",
      "answers": [
        "Kiểm trong chính sản phẩm: ai dùng, dữ liệu nào không cần thu, ai đối chiếu kết quả, tệp có mở được không."
      ],
      "source": "Bài 13 Dự án AI sáng tạo, định hướng trình bày dự án; Bài 12, quyền riêng tư và trách nhiệm, trang in 90–91, 94. Hình thức nộp video tại nhà theo khung, không thêm buổi báo cáo trực tiếp.",
      "time": "Tự làm theo mốc 7′ đọc nhiệm vụ + 27′ thực hiện + 8′ tự kiểm + 3′ nộp/lưu phản hồi. Phản hồi có thể đến sau.",
      "script": {
        "opening": "Mình xem đoạn video với câu hỏi: Người dùng, quyền riêng tư, khả năng tiếp cận và việc kiểm tra kết quả đã được thể hiện chưa?",
        "explanation": "Dùng nút Phát đoạn gợi ý, từ 120 đến 150 giây. Video tiếng Anh; GV giải nghĩa phần liên quan bằng tiếng Việt. Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "delivery": "Trước xem: giao một câu hỏi. Trong xem: cho HS chú ý một ví dụ, dừng khi cần giải nghĩa. Sau xem: mời hai ý kiến và yêu cầu chỉ chi tiết làm căn cứ. Đây là đoạn ôn tùy chọn trong dự án tại nhà, có thể dùng ảnh và tóm tắt thay thế. Nếu trình duyệt chặn âm thanh ở màn chiếu, bấm phát trực tiếp tại cửa sổ đó một lần.",
        "answer": "• Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "closing": "Tiếp nhận góp ý cần xem xét bằng mục tiêu và bằng chứng, không sửa máy móc.",
        "transition": "Tiếp theo, mình cùng tìm hiểu: “Chỉnh sửa và kiểm tra lại”.",
        "students": "Quan sát chi tiết liên quan câu hỏi; nêu một nhận xét có căn cứ sau đoạn xem."
      }
    },
    "theme": "cream",
    "fallback": "Em xem lại nguồn, dữ liệu riêng và khả năng mở tệp. Em ghi phần còn thiếu."
  },
  "revision": "V7 — 19/11/2026"
};
