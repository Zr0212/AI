window.AI6_LESSON={
  "id": 10,
  "title": "Dự án tại nhà - Giai đoạn 2: Tìm kiếm thông tin và thiết kế ý tưởng",
  "mode": "Dự án tại nhà · tự làm, có thể chia phiên",
  "count": 20,
  "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 5,
    "title": "AI: How Computer Vision Works",
    "start": 85,
    "end": 110,
    "poster": "frame_5_95.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/5LHEqBfj39mMaxu0jlpFBQ/e8c81cbd51865522b439643e03a24d53/videoplayback.mp4",
    "question": "Từ ví dụ ảnh đầu vào, hãy chọn dữ liệu tương ứng với chức năng dự án, không sao chép hình máy móc.",
    "local": "code-5.mp4"
  },
  "outcome": "Hai nguồn đã đọc, sơ đồ và bố cục sản phẩm.",
  "slides": [
    {
      "type": "cover",
      "id": "10-01",
      "title": "Dự án tại nhà - Giai đoạn 2: Tìm kiếm thông tin và thiết kế ý tưởng",
      "note": {
        "activity": "Xem lại câu hỏi cần tìm",
        "purpose": "Chuyển kế hoạch thành câu hỏi thông tin.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Nhóm ghi câu hỏi của từng người vào nhật kí.",
        "conclusion": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "assessment": "Đạt khi câu hỏi gắn với một trường thông tin của dự án.",
        "answers": [
          "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "sources",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "10-02",
      "title": "Giai đoạn này cần hoàn thành gì?",
      "note": {
        "activity": "Xem lại câu hỏi cần tìm",
        "purpose": "Chuyển kế hoạch thành câu hỏi thông tin.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi câu hỏi của từng người vào nhật kí.",
        "conclusion": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "assessment": "Đạt khi câu hỏi gắn với một trường thông tin của dự án.",
        "answers": [
          "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tìm, đọc và ghi hai nguồn phù hợp.\n2. Nói dễ hiểu: Nêu phần thông tin sẽ dùng.\n3. Điều cần nhớ: Vẽ sơ đồ và bố cục sản phẩm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tìm, đọc và ghi hai nguồn phù hợp.",
        "Nêu phần thông tin sẽ dùng.",
        "Vẽ sơ đồ và bố cục sản phẩm."
      ],
      "phase": "Khởi động",
      "scene": "sources",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm, đọc và ghi hai nguồn phù hợp.",
        "Nêu phần thông tin sẽ dùng.",
        "Vẽ sơ đồ và bố cục sản phẩm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tìm, đọc và ghi hai nguồn phù hợp.",
          "tone": "key",
          "note": "Thầy/Cô: Tìm, đọc và ghi hai nguồn phù hợp."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nêu phần thông tin sẽ dùng.",
          "tone": "explain",
          "note": "Thầy/Cô: Nêu phần thông tin sẽ dùng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Vẽ sơ đồ và bố cục sản phẩm.",
          "tone": "action",
          "note": "Thầy/Cô: Vẽ sơ đồ và bố cục sản phẩm."
        }
      ]
    },
    {
      "type": "divider",
      "id": "10-03",
      "title": "Khởi động: hỏi điều còn thiếu",
      "note": {
        "activity": "Xem lại câu hỏi cần tìm",
        "purpose": "Chuyển kế hoạch thành câu hỏi thông tin.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm ghi câu hỏi của từng người vào nhật kí.",
        "conclusion": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "assessment": "Đạt khi câu hỏi gắn với một trường thông tin của dự án.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "sources",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "id": "10-04",
      "title": "Nhóm còn thiếu thông tin nào?",
      "note": {
        "activity": "Xem lại câu hỏi cần tìm",
        "purpose": "Chuyển kế hoạch thành câu hỏi thông tin.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi câu hỏi của từng người vào nhật kí.",
        "conclusion": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "assessment": "Đạt khi câu hỏi gắn với một trường thông tin của dự án.",
        "answers": [
          "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Muốn làm sản phẩm, cần biết gì?\n2. Nói dễ hiểu: Câu hỏi nào có thể tìm trong nguồn?\n3. Điều cần nhớ: Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Muốn làm sản phẩm, cần biết gì?",
        "Câu hỏi nào có thể tìm trong nguồn?"
      ],
      "phase": "Khởi động",
      "scene": "sources",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Muốn làm sản phẩm, cần biết gì?",
        "Câu hỏi nào có thể tìm trong nguồn?",
        "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Muốn làm sản phẩm, cần biết gì?",
          "tone": "key",
          "note": "Thầy/Cô: Muốn làm sản phẩm, cần biết gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Câu hỏi nào có thể tìm trong nguồn?",
          "tone": "explain",
          "note": "Thầy/Cô: Câu hỏi nào có thể tìm trong nguồn?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
          "tone": "action",
          "note": "Thầy/Cô: Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm."
        }
      ]
    },
    {
      "type": "concept",
      "id": "10-05",
      "title": "Tìm theo câu hỏi, không tìm lan man",
      "note": {
        "activity": "Xem lại câu hỏi cần tìm",
        "purpose": "Chuyển kế hoạch thành câu hỏi thông tin.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi câu hỏi của từng người vào nhật kí.",
        "conclusion": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "assessment": "Đạt khi câu hỏi gắn với một trường thông tin của dự án.",
        "answers": [
          "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dự án cần biết under nghĩa là gì.\n2. Nói dễ hiểu: Mở bảng từ, tìm đúng mục under và đọc.\n3. Điều cần nhớ: Ghi tên nguồn, trang hoặc đường dẫn mở lại.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "sourceAccess": true,
      "v6": true,
      "screen": [
        "Nguồn 1: tìm đúng mục và đọc chi tiết.",
        "Ghi tác giả, tên nguồn, trang hoặc đường dẫn.",
        "Nguồn có trả lời đúng câu hỏi của em không?"
      ],
      "phase": "Khám phá",
      "scene": "sources",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [
        "Nguồn 1: tìm đúng mục và đọc chi tiết.",
        "Ghi tác giả, tên nguồn, trang hoặc đường dẫn.",
        "Nguồn có trả lời đúng câu hỏi của em không?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dự án cần biết under nghĩa là gì.",
          "tone": "key",
          "note": "Thầy/Cô: Dự án cần biết under nghĩa là gì."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mở bảng từ, tìm đúng mục under và đọc.",
          "tone": "explain",
          "note": "Thầy/Cô: Mở bảng từ, tìm đúng mục under và đọc."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi tên nguồn, trang hoặc đường dẫn mở lại.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi tên nguồn, trang hoặc đường dẫn mở lại."
        }
      ]
    },
    {
      "id": "10-07-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu ghi một nguồn đã mở",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "sources",
      "worked": {
        "title": "Mẫu ghi một nguồn đã mở",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Câu hỏi cần tìm",
          "Cách mở",
          "Tên nguồn",
          "Vị trí để xem lại",
          "Điều cần ghi sau đọc"
        ],
        "values": [
          "AI dịch thuật giúp việc gì?",
          "Mở PDF, tìm mục AI dịch thuật",
          "SGK Trí tuệ nhân tạo 6, Bài 8",
          "Ghi trang thật em đã đọc",
          "Một ý trả lời câu hỏi của dự án"
        ],
        "why": [
          "Không ghi trang chưa xem.",
          "Tên nguồn cần giúp mở lại.",
          "Phần dùng phải đúng điều em đã đọc."
        ],
        "question": "Sau khi đọc, em cần ghi ý nào?",
        "scene": "Sources"
      },
      "targetId": "10-07",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Một ý trả lời câu hỏi của dự án",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Câu hỏi cần tìm: AI dịch thuật giúp việc gì?\nCách mở: Mở PDF, tìm mục AI dịch thuật\nTên nguồn: SGK Trí tuệ nhân tạo 6, Bài 8\nVị trí để xem lại: Ghi trang thật em đã đọc\nĐiều cần ghi sau đọc: Một ý trả lời câu hỏi của dự án"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em mở SGK AI 6, Bài 8 để tìm thông tin.\n2. Nói dễ hiểu: Ghi đúng trang đã đọc để mở lại được.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Câu hỏi cần tìm: AI dịch thuật giúp việc gì?\nCách mở: Mở PDF, tìm mục AI dịch thuật\nTên nguồn: SGK Trí tuệ nhân tạo 6, Bài 8\nVị trí để xem lại: Ghi trang thật em đã đọc\nĐiều cần ghi sau đọc: Một ý trả lời câu hỏi của dự án",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em mở SGK AI 6, Bài 8 để tìm thông tin.",
          "tone": "key",
          "note": "Thầy/Cô: Em mở SGK AI 6, Bài 8 để tìm thông tin."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi đúng trang đã đọc để mở lại được.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi đúng trang đã đọc để mở lại được."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Sau khi đọc, em cần ghi ý nào? Gợi ý: Một ý trả lời câu hỏi của dự án"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P10.1 bảng ghi tìm kiếm",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Chấp nhận hai nguồn khác nhau phù hợp, ví dụ sách về chức năng dịch và Code.org về dữ liệu/giới hạn. Ghi đúng nguồn thực sự dùng, không tự điền nguồn chưa đọc.",
          "Cần có câu hỏi, từ khóa/cách tìm và vị trí thông tin. Nguồn in sẵn hỗ trợ đọc và so sánh nhưng chưa chứng minh tìm kiếm số."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Ghi nguồn đã thật sự đọc. Dùng bản in thì ghi đọc bản in.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Chưa mở được thì ghi cần Thầy/Cô hỗ trợ.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Ghi nguồn 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em cần tìm câu trả lời cho câu hỏi nào?",
                "key": "10-07-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi nguồn 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã dùng từ khóa hoặc mở mục nào?",
                "key": "10-07-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi nguồn 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tên nguồn, tác giả/đơn vị và vị trí thông tin",
                "key": "10-07-v3-2"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi nguồn 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Thông tin nào em sẽ dùng cho dự án?",
                "key": "10-07-v3-3"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Ghi nguồn đã thật sự đọc. Dùng bản in thì ghi đọc bản in.",
            "originalPage": 1,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Chưa mở được thì ghi cần Thầy/Cô hỗ trợ.",
            "originalPage": 1,
            "referenceOnly": true
          },
          {
            "title": "Ghi nguồn 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em cần tìm câu trả lời cho câu hỏi nào?",
                "key": "10-07-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi nguồn 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã dùng từ khóa hoặc mở mục nào?",
                "key": "10-07-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi nguồn 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tên nguồn, tác giả/đơn vị và vị trí thông tin",
                "key": "10-07-v3-6"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi nguồn 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Thông tin nào em sẽ dùng cho dự án?",
                "key": "10-07-v3-7"
              }
            ],
            "originalPage": 1
          }
        ],
        "sourceAccess": true,
        "v7PageMap": {
          "0": 0,
          "1": 6
        }
      },
      "id": "10-07",
      "title": "P10.1 — Ghi hai nguồn đã đọc",
      "note": {
        "activity": "Xem lại câu hỏi cần tìm",
        "purpose": "Hoàn thành nhật kí tìm kiếm theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm ghi câu hỏi của từng người vào nhật kí.",
        "conclusion": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Chấp nhận hai nguồn khác nhau phù hợp, ví dụ sách về chức năng dịch và Code.org về dữ liệu/giới hạn. Ghi đúng nguồn thực sự dùng, không tự điền nguồn chưa đọc.",
          "Cần có câu hỏi, từ khóa/cách tìm và vị trí thông tin. Nguồn in sẵn hỗ trợ đọc và so sánh nhưng chưa chứng minh tìm kiếm số."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Đã tìm bằng từ khóa hay mục nào? Nguồn ở đâu? Thông tin nào phục vụ dự án?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Chấp nhận hai nguồn khác nhau phù hợp, ví dụ sách về chức năng dịch và Code.org về dữ liệu/giới hạn. Ghi đúng nguồn thực sự dùng, không tự điền nguồn chưa đọc.\nCần có câu hỏi, từ khóa/cách tìm và vị trí thông tin. Nguồn in sẵn hỗ trợ đọc và so sánh nhưng chưa chứng minh tìm kiếm số.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “nguồn thứ hai có giúp kiểm nguồn đầu?”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đã tìm bằng từ khóa hay mục nào?",
        "Nguồn ở đâu?",
        "Thông tin nào phục vụ dự án?"
      ],
      "phase": "Khám phá",
      "scene": "sources",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "10-07-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Đã tìm bằng từ khóa hay mục nào?",
        "Nguồn ở đâu?",
        "Thông tin nào phục vụ dự án?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P10.1 · Ghi hai nguồn"
    },
    {
      "id": "10-v7-source2",
      "type": "guide",
      "title": "Nguồn thứ hai có giúp kiểm nguồn đầu?",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Đọc cùng một chi tiết trong hai nguồn phù hợp.",
        "Hai câu AI trả lời chưa phải hai nguồn độc lập.",
        "Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô."
      ],
      "scene": "sources",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Nguồn này trả lời đúng câu hỏi đang cần",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Đọc cùng một chi tiết trong hai nguồn phù hợp. / Hai câu AI trả lời chưa phải hai nguồn độc lập. / Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Nguồn thứ hai có giúp kiểm nguồn đầu?.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đọc cùng một chi tiết trong hai nguồn phù hợp.\n2. Nói dễ hiểu: Hai câu AI trả lời chưa phải hai nguồn độc lập.\n3. Điều cần nhớ: Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Đọc cùng một chi tiết trong hai nguồn phù hợp. / Hai câu AI trả lời chưa phải hai nguồn độc lập. / Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô.",
          "closing": "Thầy/Cô chốt: Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "number": 8,
      "originalTeachingPoints": [
        "Đọc cùng một chi tiết trong hai nguồn phù hợp.",
        "Hai câu AI trả lời chưa phải hai nguồn độc lập.",
        "Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đọc cùng một chi tiết trong hai nguồn phù hợp.",
          "tone": "key",
          "note": "Thầy/Cô: Đọc cùng một chi tiết trong hai nguồn phù hợp."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Hai câu AI trả lời chưa phải hai nguồn độc lập.",
          "tone": "explain",
          "note": "Thầy/Cô: Hai câu AI trả lời chưa phải hai nguồn độc lập."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô.",
          "tone": "action",
          "note": "Thầy/Cô: Nếu khác nhau, ghi chỗ khác và hỏi Thầy/Cô."
        }
      ]
    },
    {
      "id": "10-08-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu so nguồn theo câu hỏi",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "sources",
      "worked": {
        "title": "Mẫu so nguồn theo câu hỏi",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Nguồn 1",
          "Nguồn 2",
          "Câu hỏi",
          "Phần phù hợp",
          "Lí do chọn"
        ],
        "values": [
          "Bảng từ có mục under",
          "Video nói chung về nhận dạng ảnh",
          "Under nghĩa là gì trong câu?",
          "Mục under trong bảng từ",
          "Nguồn này trả lời đúng câu hỏi đang cần"
        ],
        "why": [
          "Nguồn tốt còn phải khớp mục đích.",
          "Không chọn chỉ vì có video.",
          "Nguồn khác có thể hợp câu hỏi khác."
        ],
        "question": "Em chọn nguồn 1 vì điều gì?",
        "scene": "Sources"
      },
      "targetId": "10-08",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Nguồn này trả lời đúng câu hỏi đang cần",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Nguồn 1: Bảng từ có mục under\nNguồn 2: Video nói chung về nhận dạng ảnh\nCâu hỏi: Under nghĩa là gì trong câu?\nPhần phù hợp: Mục under trong bảng từ\nLí do chọn: Nguồn này trả lời đúng câu hỏi đang cần"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em cần nguồn giải thích nghĩa under trong câu.\n2. Nói dễ hiểu: Nguồn phù hợp phải trả lời chi tiết đang hỏi.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Nguồn 1: Bảng từ có mục under\nNguồn 2: Video nói chung về nhận dạng ảnh\nCâu hỏi: Under nghĩa là gì trong câu?\nPhần phù hợp: Mục under trong bảng từ\nLí do chọn: Nguồn này trả lời đúng câu hỏi đang cần",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 9,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em cần nguồn giải thích nghĩa under trong câu.",
          "tone": "key",
          "note": "Thầy/Cô: Em cần nguồn giải thích nghĩa under trong câu."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nguồn phù hợp phải trả lời chi tiết đang hỏi.",
          "tone": "explain",
          "note": "Thầy/Cô: Nguồn phù hợp phải trả lời chi tiết đang hỏi."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em chọn nguồn 1 vì điều gì? Gợi ý: Nguồn này trả lời đúng câu hỏi đang cần"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P10.2 So sánh nguồn",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Lí do tốt gắn với mức liên quan và khả năng kiểm tra lại. Không chỉ vì đứng đầu tìm kiếm hoặc trình bày đẹp.",
          "Với nguồn chưa rõ tác giả/căn cứ, dùng thận trọng và tìm nguồn phù hợp hơn trong bộ Thầy/Cô cung cấp."
        ],
        "pages": [
          {
            "title": "So sánh nguồn — Mức liên quan",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn 1: giúp trả lời câu hỏi nào của dự án?",
                "key": "10-08-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "So sánh nguồn — Mức liên quan",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn 2: giúp trả lời câu hỏi nào của dự án?",
                "key": "10-08-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "So sánh nguồn — Khả năng xem lại",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn 1: do ai/đơn vị nào tạo, tìm lại ở trang hoặc đường dẫn nào?",
                "key": "10-08-v3-2"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "So sánh nguồn — Khả năng xem lại",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn 2: do ai/đơn vị nào tạo, tìm lại ở trang hoặc đường dẫn nào?",
                "key": "10-08-v3-3"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "So sánh nguồn — Lựa chọn",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn 1: nhóm giữ thông tin nào, còn điều gì cần hỏi hoặc kiểm tra?",
                "key": "10-08-v3-4"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "So sánh nguồn — Lựa chọn",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn 2: nhóm giữ thông tin nào, còn điều gì cần hỏi hoặc kiểm tra?",
                "key": "10-08-v3-5"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2,
          "2": 4
        }
      },
      "id": "10-08",
      "title": "P10.2 — So hai nguồn theo mục đích",
      "note": {
        "activity": "Tìm nguồn và thiết kế sơ đồ",
        "purpose": "Hoàn thành so sánh hai nguồn theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm ghi nguồn dùng cho từng phần; không sao chép nguyên trang làm sản phẩm.",
        "conclusion": "Nguồn cần liên quan, nhận diện được và kiểm tra lại được. Sơ đồ phải có phần con người kiểm tra, không kết thúc ở kết quả AI.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Lí do tốt gắn với mức liên quan và khả năng kiểm tra lại. Không chỉ vì đứng đầu tìm kiếm hoặc trình bày đẹp.",
          "Với nguồn chưa rõ tác giả/căn cứ, dùng thận trọng và tìm nguồn phù hợp hơn trong bộ Thầy/Cô cung cấp."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Nguồn nào trả lời đúng câu hỏi? Nguồn nào có thể xem lại? Dùng phần nào từ mỗi nguồn?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Lí do tốt gắn với mức liên quan và khả năng kiểm tra lại. Không chỉ vì đứng đầu tìm kiếm hoặc trình bày đẹp.\nVới nguồn chưa rõ tác giả/căn cứ, dùng thận trọng và tìm nguồn phù hợp hơn trong bộ Thầy/Cô cung cấp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nguồn nào trả lời đúng câu hỏi?",
        "Nguồn nào có thể xem lại?",
        "Dùng phần nào từ mỗi nguồn?"
      ],
      "phase": "Khám phá",
      "scene": "sources",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "10-08-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 10,
      "v7": true,
      "originalTeachingPoints": [
        "Nguồn nào trả lời đúng câu hỏi?",
        "Nguồn nào có thể xem lại?",
        "Dùng phần nào từ mỗi nguồn?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P10.2 · So hai nguồn"
    },
    {
      "type": "divider",
      "id": "10-09",
      "title": "Thực hành: vẽ cách hoạt động",
      "note": {
        "activity": "Tìm nguồn và thiết kế sơ đồ",
        "purpose": "Tìm hai nguồn phù hợp và dùng chúng để mô tả dự án.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm ghi nguồn dùng cho từng phần; không sao chép nguyên trang làm sản phẩm.",
        "conclusion": "Nguồn cần liên quan, nhận diện được và kiểm tra lại được. Sơ đồ phải có phần con người kiểm tra, không kết thúc ở kết quả AI.",
        "assessment": "Đạt khi nguồn gắn nội dung được dùng, sơ đồ đủ bốn phần. Chưa có tìm kiếm số thì ghi rõ thiếu minh chứng 1.1.TC1b.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "sources",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "concept",
      "id": "10-10",
      "title": "Bốn phần của một lần sử dụng",
      "note": {
        "activity": "Tìm nguồn và thiết kế sơ đồ",
        "purpose": "Tìm hai nguồn phù hợp và dùng chúng để mô tả dự án.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi nguồn dùng cho từng phần; không sao chép nguyên trang làm sản phẩm.",
        "conclusion": "Nguồn cần liên quan, nhận diện được và kiểm tra lại được. Sơ đồ phải có phần con người kiểm tra, không kết thúc ở kết quả AI.",
        "assessment": "Đạt khi nguồn gắn nội dung được dùng, sơ đồ đủ bốn phần. Chưa có tìm kiếm số thì ghi rõ thiếu minh chứng 1.1.TC1b.",
        "answers": [
          "Nguồn cần liên quan, nhận diện được và kiểm tra lại được. Sơ đồ phải có phần con người kiểm tra, không kết thúc ở kết quả AI."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em đưa một từ vào công cụ AI.\n2. Nói dễ hiểu: AI gợi nghĩa; em so bảng từ trước khi dùng.\n3. Điều cần nhớ: Chưa kiểm được thì em chưa dùng kết quả.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Nguồn cần liên quan, nhận diện được và kiểm tra lại được. Sơ đồ phải có phần con người kiểm tra, không kết thúc ở kết quả AI.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đầu vào → AI hỗ trợ → Em kiểm → Sản phẩm.",
        "AI trả gợi ý trước bước em kiểm.",
        "Nếu chưa kiểm được, chưa dùng kết quả."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "verified-flow",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [
        "Đầu vào → AI hỗ trợ → Em kiểm → Sản phẩm.",
        "AI trả gợi ý trước bước em kiểm.",
        "Nếu chưa kiểm được, chưa dùng kết quả."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em đưa một từ vào công cụ AI.",
          "tone": "key",
          "note": "Thầy/Cô: Em đưa một từ vào công cụ AI."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI gợi nghĩa; em so bảng từ trước khi dùng.",
          "tone": "explain",
          "note": "Thầy/Cô: AI gợi nghĩa; em so bảng từ trước khi dùng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chưa kiểm được thì em chưa dùng kết quả.",
          "tone": "action",
          "note": "Thầy/Cô: Đầu vào → AI hỗ trợ → Em kiểm → Sản phẩm."
        }
      ]
    },
    {
      "id": "10-11-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu sơ đồ từ hỏi đến dùng",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "verified-flow",
      "worked": {
        "title": "Mẫu sơ đồ từ hỏi đến dùng",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Đầu vào",
          "AI xử lí",
          "Con người kiểm tra",
          "Kết quả có thể dùng",
          "Nếu chưa kiểm được"
        ],
        "values": [
          "Từ under trong một câu",
          "AI gợi nghĩa và ví dụ",
          "Em so với bảng từ hoặc hỏi Thầy/Cô",
          "Thẻ từ sau khi kiểm và sửa",
          "Chưa dùng. Tìm nguồn hoặc hỏi hỗ trợ"
        ],
        "why": [
          "AI đã gợi kết quả trước lúc em kiểm.",
          "Bước người kiểm quyết định bản sẽ dùng.",
          "Sơ đồ mẫu ghi rõ xử lí khi chưa chắc."
        ],
        "question": "Nếu chưa kiểm được, em đi nhánh nào?",
        "scene": "Verified-flow"
      },
      "targetId": "10-11",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Chưa dùng. Tìm nguồn hoặc hỏi hỗ trợ",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Đầu vào: Từ under trong một câu\nAI xử lí: AI gợi nghĩa và ví dụ\nCon người kiểm tra: Em so với bảng từ hoặc hỏi Thầy/Cô\nKết quả có thể dùng: Thẻ từ sau khi kiểm và sửa\nNếu chưa kiểm được: Chưa dùng. Tìm nguồn hoặc hỏi hỗ trợ"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Từ under đi qua AI rồi được em kiểm.\n2. Nói dễ hiểu: AI gợi ý trước; em kiểm xong mới dùng.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Đầu vào: Từ under trong một câu\nAI xử lí: AI gợi nghĩa và ví dụ\nCon người kiểm tra: Em so với bảng từ hoặc hỏi Thầy/Cô\nKết quả có thể dùng: Thẻ từ sau khi kiểm và sửa\nNếu chưa kiểm được: Chưa dùng. Tìm nguồn hoặc hỏi hỗ trợ",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Từ under đi qua AI rồi được em kiểm.",
          "tone": "key",
          "note": "Thầy/Cô: Từ under đi qua AI rồi được em kiểm."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI gợi ý trước; em kiểm xong mới dùng.",
          "tone": "explain",
          "note": "Thầy/Cô: AI gợi ý trước; em kiểm xong mới dùng."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Nếu chưa kiểm được, em đi nhánh nào? Gợi ý: Chưa dùng. Tìm nguồn hoặc hỏi hỗ trợ"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P10.3A Sơ đồ và bố cục",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Sơ đồ cần khớp ví dụ và có người kiểm tra. Poster không phải mô hình chạy thật. Ghi rõ chức năng dự kiến.",
          "Mỗi phần thông tin lấy từ nguồn phải có ghi nguồn. Chấp nhận vẽ tay nếu logic rõ. Ghi minh chứng số còn thiếu nếu chưa thao tác."
        ],
        "pages": [
          {
            "title": "Viết sơ đồ bốn phần",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Người dùng đưa dữ liệu gì vào?",
                "key": "10-11-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Viết sơ đồ bốn phần",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "AI sẽ hỗ trợ làm gì?",
                "key": "10-11-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Viết sơ đồ bốn phần",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "AI trả kết quả gì?",
                "key": "10-11-v3-2"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Viết sơ đồ bốn phần",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Con người kiểm tra kết quả bằng gì và quyết định thế nào?",
                "key": "10-11-v3-3"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Thử giải thích bằng một ví dụ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ví dụ: dữ liệu đưa vào và kết quả dự kiến",
                "key": "10-11-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Thử giải thích bằng một ví dụ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nếu kết quả sai hoặc chưa rõ, ai sẽ làm gì?",
                "key": "10-11-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Sáu phần: nhu cầu, dữ liệu, việc AI làm, kết quả, cách kiểm, nguồn.",
            "originalPage": 2,
            "referenceOnly": true
          },
          {
            "title": "Phác thảo cách trình bày",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Sản phẩm sẽ có những phần nào?",
                "key": "10-11-v3-6"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4,
          "2": 6
        }
      },
      "id": "10-11",
      "title": "P10.3A — Vẽ cách hoạt động",
      "note": {
        "activity": "Tìm nguồn và thiết kế sơ đồ",
        "purpose": "Hoàn thành sơ đồ và bố cục sản phẩm theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm ghi nguồn dùng cho từng phần; không sao chép nguyên trang làm sản phẩm.",
        "conclusion": "Nguồn cần liên quan, nhận diện được và kiểm tra lại được. Sơ đồ phải có phần con người kiểm tra, không kết thúc ở kết quả AI.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Sơ đồ cần khớp ví dụ và có người kiểm tra. Poster không phải mô hình chạy thật. Ghi rõ chức năng dự kiến.",
          "Mỗi phần thông tin lấy từ nguồn phải có ghi nguồn. Chấp nhận vẽ tay nếu logic rõ. Ghi minh chứng số còn thiếu nếu chưa thao tác."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Điền bốn phần bằng nội dung cụ thể. Thử giải thích với một ví dụ. Phác thảo bố cục và chỗ ghi nguồn.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Sơ đồ cần khớp ví dụ và có người kiểm tra. Poster không phải mô hình chạy thật. Ghi rõ chức năng dự kiến.\nMỗi phần thông tin lấy từ nguồn phải có ghi nguồn. Chấp nhận vẽ tay nếu logic rõ. Ghi minh chứng số còn thiếu nếu chưa thao tác.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Điền bốn phần bằng nội dung cụ thể.",
        "Thử giải thích với một ví dụ.",
        "Phác thảo bố cục và chỗ ghi nguồn."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "sources",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "10-11-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [
        "Điền bốn phần bằng nội dung cụ thể.",
        "Thử giải thích với một ví dụ.",
        "Phác thảo bố cục và chỗ ghi nguồn."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P10.3A · Vẽ cách hoạt động"
    },
    {
      "type": "divider",
      "id": "10-12",
      "title": "Tự kiểm tra thiết kế",
      "note": {
        "activity": "Tự kiểm tra thiết kế",
        "purpose": "Kiểm tra nguồn và quan hệ các phần trong sơ đồ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm ghi góp ý và thay đổi vào cuối P10.3.",
        "conclusion": "Một sơ đồ dễ đọc phải giải thích được bằng tình huống cụ thể.",
        "assessment": "Đánh giá tính mạch lạc. Không chấm theo độ cầu kì của hình vẽ.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "sources",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "10-13-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu nhận một góp ý cụ thể",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "verified-flow",
      "worked": {
        "title": "Mẫu nhận một góp ý cụ thể",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Điều em đọc lại",
          "Chỗ chưa rõ",
          "Câu hỏi",
          "Việc nhóm sửa",
          "Căn cứ kiểm sau sửa"
        ],
        "values": [
          "AI gợi nghĩa cho ba từ",
          "Chưa thấy người kiểm",
          "Ai kiểm khi nghĩa chưa rõ?",
          "Thêm bước so bảng từ, hỏi Thầy/Cô",
          "Nhờ em khác đọc lại bằng một ví dụ"
        ],
        "why": [
          "Hỏi đúng chỗ giúp sửa đúng việc.",
          "Không chỉ nhận xét đẹp hay xấu.",
          "Em kiểm xem sửa đã giúp dễ hiểu chưa."
        ],
        "question": "Nhóm nên thử đọc lại thế nào?",
        "scene": "Verified-flow"
      },
      "targetId": "10-13",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Nhờ em khác đọc lại bằng một ví dụ",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Điều em đọc lại: AI gợi nghĩa cho ba từ\nChỗ chưa rõ: Chưa thấy người kiểm\nCâu hỏi: Ai kiểm khi nghĩa chưa rõ?\nViệc nhóm sửa: Thêm bước so bảng từ, hỏi Thầy/Cô\nCăn cứ kiểm sau sửa: Nhờ em khác đọc lại bằng một ví dụ"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Sơ đồ đang thiếu bước con người kiểm nghĩa.\n2. Nói dễ hiểu: Thêm người kiểm để biết xử lí nghĩa sai.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Điều em đọc lại: AI gợi nghĩa cho ba từ\nChỗ chưa rõ: Chưa thấy người kiểm\nCâu hỏi: Ai kiểm khi nghĩa chưa rõ?\nViệc nhóm sửa: Thêm bước so bảng từ, hỏi Thầy/Cô\nCăn cứ kiểm sau sửa: Nhờ em khác đọc lại bằng một ví dụ",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Sơ đồ đang thiếu bước con người kiểm nghĩa.",
          "tone": "key",
          "note": "Thầy/Cô: Sơ đồ đang thiếu bước con người kiểm nghĩa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thêm người kiểm để biết xử lí nghĩa sai.",
          "tone": "explain",
          "note": "Thầy/Cô: Thêm người kiểm để biết xử lí nghĩa sai."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Nhóm nên thử đọc lại thế nào? Gợi ý: Nhờ em khác đọc lại bằng một ví dụ"
        }
      ]
    },
    {
      "type": "worksheet",
      "id": "10-13",
      "title": "P10.3B — Nhờ em cùng nhóm thử giải thích",
      "note": {
        "activity": "Tự kiểm tra thiết kế",
        "purpose": "Kiểm tra nguồn và quan hệ các phần trong sơ đồ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm ghi góp ý và thay đổi vào cuối P10.3.",
        "conclusion": "Một sơ đồ dễ đọc phải giải thích được bằng tình huống cụ thể.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Em cùng nhóm cần chỉ đúng dữ liệu vào, AI làm gì, kết quả và người kiểm tra.",
          "Nhóm ghi đúng một góp ý và điều đã sửa. Nếu chưa sửa, nêu điều còn cần hỏi."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Nhờ một em đọc sơ đồ và dùng một ví dụ để giải thích. Hỏi thêm: nếu kết quả sai, ai kiểm tra và làm gì?\nÝ cần giảng rõ: Em cùng nhóm dùng một ví dụ để đọc sơ đồ. Hỏi: kết quả sai thì ai làm gì? Ghi góp ý và điều đã sửa.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Em cùng nhóm cần chỉ đúng dữ liệu vào, AI làm gì, kết quả và người kiểm tra.\nNhóm ghi đúng một góp ý và điều đã sửa. Nếu chưa sửa, nêu điều còn cần hỏi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "worksheet": {
        "title": "P10.3B Góp ý thiết kế",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Em cùng nhóm cần chỉ đúng dữ liệu vào, AI làm gì, kết quả và người kiểm tra.",
          "Nhóm ghi đúng một góp ý và điều đã sửa. Nếu chưa sửa, nêu điều còn cần hỏi."
        ],
        "pages": [
          {
            "title": "Thử giải thích rồi sửa thiết kế",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em cùng nhóm dùng ví dụ nào? Em cùng nhóm góp ý điều gì?",
                "key": "10-13-v4-feedback"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Thử giải thích rồi sửa thiết kế",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Sau khi em cùng nhóm/Thầy/Cô góp ý, nhóm sửa điều gì?",
                "key": "10-11-v3-7"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "v6": true,
      "screen": [
        "Em cùng nhóm dùng một ví dụ để đọc sơ đồ.",
        "Hỏi: kết quả sai thì ai làm gì?",
        "Ghi góp ý và điều đã sửa."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "sources",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "10-13-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Em cùng nhóm dùng một ví dụ để đọc sơ đồ.",
        "Hỏi: kết quả sai thì ai làm gì?",
        "Ghi góp ý và điều đã sửa."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P10.3B · Em tự làm"
    },
    {
      "type": "recap",
      "id": "10-14",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Tự kiểm tra thiết kế",
        "purpose": "Kiểm tra nguồn và quan hệ các phần trong sơ đồ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi góp ý và thay đổi vào cuối P10.3.",
        "conclusion": "Một sơ đồ dễ đọc phải giải thích được bằng tình huống cụ thể.",
        "assessment": "Đánh giá tính mạch lạc. Không chấm theo độ cầu kì của hình vẽ.",
        "answers": [
          "Một sơ đồ dễ đọc phải giải thích được bằng tình huống cụ thể."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nguồn phải trả lời câu hỏi của dự án.\n2. Nói dễ hiểu: Ghi vị trí để mở lại nguồn.\n3. Điều cần nhớ: Sơ đồ có dữ liệu, AI, kết quả, người kiểm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Một sơ đồ dễ đọc phải giải thích được bằng tình huống cụ thể.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nguồn phải trả lời câu hỏi của dự án.",
        "Ghi vị trí để mở lại nguồn.",
        "Sơ đồ có dữ liệu, AI, kết quả, người kiểm."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "sources",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Nguồn phải trả lời câu hỏi của dự án.",
        "Ghi vị trí để mở lại nguồn.",
        "Sơ đồ có dữ liệu, AI, kết quả, người kiểm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nguồn phải trả lời câu hỏi của dự án.",
          "tone": "key",
          "note": "Thầy/Cô: Nguồn phải trả lời câu hỏi của dự án."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi vị trí để mở lại nguồn.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi vị trí để mở lại nguồn."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Sơ đồ có dữ liệu, AI, kết quả, người kiểm.",
          "tone": "action",
          "note": "Thầy/Cô: Sơ đồ có dữ liệu, AI, kết quả, người kiểm."
        }
      ]
    },
    {
      "type": "divider",
      "id": "10-15",
      "title": "Vận dụng: gửi bản thiết kế",
      "note": {
        "activity": "Nộp và nhận phản hồi",
        "purpose": "Bàn giao thiết kế đủ để tạo sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm xác nhận nội dung được giữ và nội dung cần sửa.",
        "conclusion": "Giai đoạn 3 ưu tiên diễn đạt đúng thiết kế đã kiểm tra.",
        "assessment": "Nếu nguồn chưa phù hợp, Thầy/Cô cung cấp một nguồn thay thế cụ thể trong bộ tuyển chọn.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Bản cần gửi đã có. Em mở thử trước khi nộp."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "sources",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "submission",
      "id": "10-16",
      "title": "Gửi nguồn và bản thiết kế",
      "note": {
        "activity": "Nộp và nhận phản hồi",
        "purpose": "Bàn giao thiết kế đủ để tạo sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
        "report": "Nhóm xác nhận nội dung được giữ và nội dung cần sửa.",
        "conclusion": "Giai đoạn 3 ưu tiên diễn đạt đúng thiết kế đã kiểm tra.",
        "assessment": "Nếu nguồn chưa phù hợp, Thầy/Cô cung cấp một nguồn thay thế cụ thể trong bộ tuyển chọn.",
        "answers": [
          "Giai đoạn 3 ưu tiên diễn đạt đúng thiết kế đã kiểm tra."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Bản cần gửi đã có. Em mở thử trước khi nộp.",
          "explanation": "Nộp phiếu nguồn, sơ đồ và bản nháp bố cục. Mỗi em ghi thông tin em đã kiểm tra.\nÝ cần giảng rõ: Bảng ghi hai nguồn. Sơ đồ và bản phác thảo. Mỗi em nêu một thông tin đã kiểm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
          "answer": "Giai đoạn 3 ưu tiên diễn đạt đúng thiết kế đã kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Bảng ghi hai nguồn.",
        "Sơ đồ và bản phác thảo.",
        "Mỗi em nêu một thông tin đã kiểm."
      ],
      "phase": "Vận dụng",
      "scene": "sources",
      "taskLines": [
        "Trong 3 phút, em kiểm hồ sơ ở thư mục.",
        "Sau đó, em gửi tệp theo kênh của lớp."
      ],
      "connector": "Bản cần gửi đã có. Em mở thử trước khi nộp.",
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [
        "Bảng ghi hai nguồn.",
        "Sơ đồ và bản phác thảo.",
        "Mỗi em nêu một thông tin đã kiểm."
      ],
      "pupilTask": "Em kiểm tệp; ghi phần việc rồi tải bài."
    }
  ],
  "rubric": [
    [
      "1 Vấn đề và tính khả thi",
      "Chưa nêu vấn đề/người dùng hoặc mục tiêu không thể thực hiện.",
      "Có vấn đề/người dùng nhưng mục tiêu hoặc cách thực hiện còn rộng.",
      "Vấn đề, người dùng, mục tiêu rõ. Hình thức và quy mô phù hợp điều kiện."
    ],
    [
      "2 Chức năng AI và chính xác",
      "Không mô tả đúng AI hoặc gán chức năng không có bằng chứng.",
      "Có đầu vào/đầu ra. Còn thiếu liên kết hoặc chưa rõ mức đã làm.",
      "Chức năng, đầu vào/đầu ra và ví dụ đúng. Ghi rõ minh họa hay hoạt động thật."
    ],
    [
      "3 Con người và an toàn",
      "Chưa có bước kiểm tra. Hoặc còn chia sẻ thông tin riêng không cần thiết.",
      "Có người kiểm tra nhưng cách kiểm/điều kiện riêng tư còn chung chung.",
      "Có nguồn kiểm và cách xử lí khi sai. Con người quyết định. Chỉ dùng dữ liệu cần thiết."
    ],
    [
      "4 Sản phẩm nguồn và quá trình",
      "Thiếu phần chính, nguồn hoặc bằng chứng quá trình.",
      "Sản phẩm đọc được. Còn thiếu phần, nguồn khó xem lại hoặc bảng ghi chưa rõ.",
      "Đủ nội dung. Nguồn mở lại được. Sản phẩm dễ xem. Có bảng ghi quá trình."
    ],
    [
      "5 Hợp tác chỉnh sửa giới thiệu",
      "Chưa có đóng góp, góp ý hoặc sửa bài. Chưa giới thiệu sản phẩm.",
      "Có phân công hoặc sửa nhưng lí do chưa rõ. Giới thiệu chưa đủ hoặc còn thiếu minh chứng.",
      "Có đóng góp và một sửa có lí do. Video 2–3 phút nêu rõ vai AI và người."
    ]
  ],
  "evidence": [
    [
      "Tìm thông tin",
      "1.1.TC1b",
      "Dùng từ khóa/quy trình tìm kiếm phù hợp.",
      "P10.1 và quan sát/ghi chép thao tác",
      "Có câu hỏi, cách tìm, kết quả chọn; chỉ đọc nguồn in sẵn chưa đủ minh chứng tìm kiếm số."
    ],
    [
      "So sánh nguồn",
      "1.2.TC1a",
      "Chọn nguồn liên quan và kiểm tra được.",
      "P10.2, đóng góp cá nhân",
      "Lí do gắn nội dung, đơn vị và khả năng đối chiếu, không chỉ vì đứng đầu kết quả."
    ]
  ],
  "review": {
    "type": "video",
    "video": {
      "index": 5,
      "title": "AI: How Computer Vision Works",
      "start": 85,
      "end": 110,
      "poster": "frame_5_95.jpg",
      "url": "https://contentful-videos.code.org/90t6bu6vlf76/5LHEqBfj39mMaxu0jlpFBQ/e8c81cbd51865522b439643e03a24d53/videoplayback.mp4",
      "question": "Dự án cần nhận văn bản hay ảnh?",
      "local": "code-5.mp4"
    },
    "optional": true,
    "id": "10-06",
    "number": 6,
    "title": "Ôn nhanh: đầu vào của hệ thống AI",
    "note": {
      "activity": "Xem lại câu hỏi cần tìm",
      "purpose": "Chuyển kế hoạch thành câu hỏi thông tin.",
      "teacher": "GV giao bộ nguồn ngắn, hướng dẫn tìm trong phạm vi đã chọn thay vì toàn Internet. Gợi ý dùng tên chức năng và mục cần biết; cho phép hỏi nếu chưa tìm thấy.",
      "students": "Đọc kế hoạch, chọn thông tin cần bổ sung, viết từ khóa trước khi tìm.",
      "report": "Nhóm ghi câu hỏi của từng người vào nhật kí.",
      "conclusion": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
      "assessment": "Đạt khi câu hỏi gắn với một trường thông tin của dự án.",
      "answers": [
        "Ví dụ: dự án dịch dùng câu/từ; dự án nhận dạng dùng ảnh. Chọn dữ liệu khớp chức năng, không sao chép ví dụ máy móc."
      ],
      "source": "Bài 13 Dự án AI sáng tạo, trang in 99; Bài 8 AI dịch thuật, trang in 57 nếu chọn dự án từ vựng. Trang Code.org chính thức chỉ dùng theo chủ đề phù hợp.",
      "time": "Tự làm theo mốc 7′ đọc nhiệm vụ + 27′ thực hiện + 8′ tự kiểm + 3′ nộp/lưu phản hồi. Phản hồi có thể đến sau.",
      "script": {
        "opening": "Mình xem đoạn video với câu hỏi: Từ ví dụ ảnh đầu vào, hãy chọn dữ liệu tương ứng với chức năng dự án, không sao chép hình máy móc.",
        "explanation": "Dùng nút Phát đoạn gợi ý, từ 85 đến 110 giây. Video tiếng Anh; GV giải nghĩa phần liên quan bằng tiếng Việt. Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "delivery": "Trước xem: giao một câu hỏi. Trong xem: cho HS chú ý một ví dụ, dừng khi cần giải nghĩa. Sau xem: mời hai ý kiến và yêu cầu chỉ chi tiết làm căn cứ. Đây là đoạn ôn tùy chọn trong dự án tại nhà, có thể dùng ảnh và tóm tắt thay thế. Nếu trình duyệt chặn âm thanh ở màn chiếu, bấm phát trực tiếp tại cửa sổ đó một lần.",
        "answer": "• Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "closing": "Câu hỏi rõ giúp tìm đúng thông tin cần cho sản phẩm.",
        "transition": "Tiếp theo, mình cùng tìm hiểu: “P10.1 — Nhật kí tìm kiếm”.",
        "students": "Quan sát chi tiết liên quan câu hỏi; nêu một nhận xét có căn cứ sau đoạn xem."
      }
    },
    "theme": "cream",
    "fallback": "Ví dụ: AI dịch câu cần nhận văn bản. AI nhận dạng đồ vật cần ảnh."
  },
  "revision": "V7 — 19/11/2026"
};
