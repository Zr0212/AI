window.AI6_LESSON={
  "id": 7,
  "title": "Bài 7. Mặt tốt, hạn chế và lựa chọn sử dụng AI",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 29,
  "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 9,
    "title": "Ethics & AI: Equal Access and Algorithmic Bias",
    "start": 120,
    "end": 150,
    "poster": "frame_9_135.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/6bdcJTTcr9iESnI5jMsxGR/f61be02642cc453a5f03df83d0d4fffb/ai-06-ai-ethics-access-bias.mp4",
    "question": "Quan sát người dùng ở bối cảnh khác nhau. Dữ liệu và điều kiện sử dụng ảnh hưởng lựa chọn dùng AI thế nào?",
    "local": "code-9.mp4"
  },
  "outcome": "Bảng chọn cách dùng AI và ba quy tắc cụ thể.",
  "slides": [
    {
      "type": "cover",
      "id": "07-01",
      "title": "Bài 7. Mặt tốt, hạn chế và lựa chọn sử dụng AI",
      "note": {
        "activity": "Khởi động",
        "purpose": "Phát hiện cùng một công cụ có thể hữu ích và gây khó khăn.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng.",
        "assessment": "Không chấp nhận kết luận mọi gợi ý đều tốt hoặc đều xấu. Yêu cầu căn cứ tình huống.",
        "answers": [
          "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "decision",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "07-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Phát hiện cùng một công cụ có thể hữu ích và gây khó khăn.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng.",
        "assessment": "Không chấp nhận kết luận mọi gợi ý đều tốt hoặc đều xấu. Yêu cầu căn cứ tình huống.",
        "answers": [
          "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nêu lợi ích và hạn chế trong tình huống.\n2. Nói dễ hiểu: Chọn cách dùng AI và giải thích.\n3. Điều cần nhớ: Nêu cách kiểm, bảo vệ dữ liệu và thời gian.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nêu lợi ích và hạn chế trong tình huống.",
        "Chọn cách dùng AI và giải thích.",
        "Nêu cách kiểm, bảo vệ dữ liệu và thời gian."
      ],
      "phase": "Khởi động",
      "scene": "decision",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Nêu lợi ích và hạn chế trong tình huống.",
        "Chọn cách dùng AI và giải thích.",
        "Nêu cách kiểm, bảo vệ dữ liệu và thời gian."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nêu lợi ích và hạn chế trong tình huống.",
          "tone": "key",
          "note": "Thầy/Cô: Nêu lợi ích và hạn chế trong tình huống."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chọn cách dùng AI và giải thích.",
          "tone": "explain",
          "note": "Thầy/Cô: Chọn cách dùng AI và giải thích."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nêu cách kiểm, bảo vệ dữ liệu và thời gian.",
          "tone": "action",
          "note": "Thầy/Cô: Nêu cách kiểm, bảo vệ dữ liệu và thời gian."
        }
      ]
    },
    {
      "type": "divider",
      "id": "07-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Phát hiện cùng một công cụ có thể hữu ích và gây khó khăn.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng.",
        "assessment": "Không chấp nhận kết luận mọi gợi ý đều tốt hoặc đều xấu. Yêu cầu căn cứ tình huống.",
        "answers": [],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "decision",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "07-04",
      "title": "Gợi ý video giúp học hay giữ chân em?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Phát hiện cùng một công cụ có thể hữu ích và gây khó khăn.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng.",
        "assessment": "Không chấp nhận kết luận mọi gợi ý đều tốt hoặc đều xấu. Yêu cầu căn cứ tình huống.",
        "answers": [
          "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tìm được video học tập.\n2. Nói dễ hiểu: Ứng dụng gợi ý xem tiếp.\n3. Điều cần nhớ: Khi nào em nên dừng?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Đánh giá AI cần xét mục đích, điều kiện và ảnh hưởng đến người sử dụng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tìm được video học tập.",
        "Ứng dụng gợi ý xem tiếp.",
        "Khi nào em nên dừng?"
      ],
      "phase": "Khởi động",
      "scene": "decision",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm được video học tập.",
        "Ứng dụng gợi ý xem tiếp.",
        "Khi nào em nên dừng?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tìm được video học tập.",
          "tone": "key",
          "note": "Thầy/Cô: Tìm được video học tập."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ứng dụng gợi ý xem tiếp.",
          "tone": "explain",
          "note": "Thầy/Cô: Ứng dụng gợi ý xem tiếp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Khi nào em nên dừng?",
          "tone": "action",
          "note": "Thầy/Cô: Khi nào em nên dừng?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "07-05",
      "title": "Khám phá: dữ liệu có bao quát?",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và kết quả lệch",
        "purpose": "Giải thích đơn giản vai trò dữ liệu đa dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử.",
        "assessment": "Đạt khi chỉ ra yếu tố thiếu và một cách kiểm. Không đòi thuật ngữ chuyên sâu về thiên lệch.",
        "answers": [],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "decision",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_9_135.jpg",
      "id": "07-06",
      "title": "Một bộ dữ liệu có bao quát hết không?",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và kết quả lệch",
        "purpose": "Giải thích đơn giản vai trò dữ liệu đa dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử.",
        "assessment": "Đạt khi chỉ ra yếu tố thiếu và một cách kiểm. Không đòi thuật ngữ chuyên sâu về thiên lệch.",
        "answers": [
          "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ví dụ học có đủ khác nhau không?\n2. Nói dễ hiểu: Ai hoặc trường hợp nào có thể bị bỏ sót?\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ví dụ học có đủ khác nhau không?",
        "Ai hoặc trường hợp nào có thể bị bỏ sót?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "Ví dụ học có đủ khác nhau không?",
        "Ai hoặc trường hợp nào có thể bị bỏ sót?",
        "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ví dụ học có đủ khác nhau không?",
          "tone": "key",
          "note": "Thầy/Cô: Ví dụ học có đủ khác nhau không?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ai hoặc trường hợp nào có thể bị bỏ sót?",
          "tone": "explain",
          "note": "Thầy/Cô: Ai hoặc trường hợp nào có thể bị bỏ sót?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử."
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 9,
        "title": "Ethics & AI: Equal Access and Algorithmic Bias",
        "start": 120,
        "end": 150,
        "poster": "frame_9_135.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/6bdcJTTcr9iESnI5jMsxGR/f61be02642cc453a5f03df83d0d4fffb/ai-06-ai-ethics-access-bias.mp4",
        "question": "Ví dụ học đã bao quát các trường hợp chưa?",
        "local": "code-9.mp4"
      },
      "id": "07-07",
      "title": "Khi dữ liệu chưa bao quát",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và kết quả lệch",
        "purpose": "Giải thích đơn giản vai trò dữ liệu đa dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử.",
        "assessment": "Đạt khi chỉ ra yếu tố thiếu và một cách kiểm. Không đòi thuật ngữ chuyên sâu về thiên lệch.",
        "answers": [
          "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: Tìm điều kiện dữ liệu còn thiếu. Nêu điều cần kiểm tra trước khi dùng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tìm điều kiện dữ liệu còn thiếu.",
        "Nêu điều cần kiểm tra trước khi dùng."
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 30 giây, em ghi một ví dụ vào vở."
      ],
      "fallback": "Ví dụ chưa bao quát có thể làm kết quả lệch. Cần thử với các trường hợp phù hợp trước khi dùng.",
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm điều kiện dữ liệu còn thiếu.",
        "Nêu điều cần kiểm tra trước khi dùng."
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "type": "concept",
      "id": "07-08",
      "title": "Cùng 30 ảnh, khác cách chọn",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và kết quả lệch",
        "purpose": "Giải thích đơn giản vai trò dữ liệu đa dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử.",
        "assessment": "Đạt khi chỉ ra yếu tố thiếu và một cách kiểm. Không đòi thuật ngữ chuyên sâu về thiên lệch.",
        "answers": [
          "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Hai bộ cùng 30 ảnh cốc, khác cách chụp.\n2. Nói dễ hiểu: Bộ nhiều kiểu có thể bao quát nhiều trường hợp.\n3. Điều cần nhớ: Phải thử ảnh mới trước khi khẳng định tốt hơn.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Bộ A: một cốc, một góc.",
        "Bộ B: nhiều kiểu cốc và góc phù hợp.",
        "Muốn so sánh, cần thử ảnh mới."
      ],
      "phase": "Khám phá",
      "scene": "decision",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Bộ A: một cốc, một góc.",
        "Bộ B: nhiều kiểu cốc và góc phù hợp.",
        "Muốn so sánh, cần thử ảnh mới."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Hai bộ cùng 30 ảnh cốc, khác cách chụp.",
          "tone": "key",
          "note": "Thầy/Cô: Hai bộ cùng 30 ảnh cốc, khác cách chụp."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bộ nhiều kiểu có thể bao quát nhiều trường hợp.",
          "tone": "explain",
          "note": "Thầy/Cô: Bộ nhiều kiểu có thể bao quát nhiều trường hợp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Phải thử ảnh mới trước khi khẳng định tốt hơn.",
          "tone": "action",
          "note": "Thầy/Cô: Phải thử ảnh mới trước khi khẳng định tốt hơn."
        }
      ]
    },
    {
      "id": "07-09-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu so hai bộ ảnh",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "diversity",
      "worked": {
        "title": "Mẫu so hai bộ ảnh",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Giống nhau",
          "Bộ A",
          "Bộ B",
          "Dự đoán có lí do",
          "Cách kiểm dự đoán"
        ],
        "values": [
          "Cùng 30 ảnh cốc",
          "Một cốc trắng, cùng một góc",
          "Nhiều cốc và góc phù hợp",
          "B có thể bao quát nhiều trường hợp hơn",
          "Thử ảnh mới rồi so với cốc thật"
        ],
        "why": [
          "Số lượng giống chưa có nghĩa nội dung giống.",
          "Dự đoán chưa phải kết quả đã đo.",
          "Ảnh mới giúp kiểm điều em nghĩ."
        ],
        "question": "Em cần làm gì trước khi khẳng định?",
        "scene": "Diversity"
      },
      "targetId": "07-09",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thử ảnh mới rồi so với cốc thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Giống nhau: Cùng 30 ảnh cốc\nBộ A: Một cốc trắng, cùng một góc\nBộ B: Nhiều cốc và góc phù hợp\nDự đoán có lí do: B có thể bao quát nhiều trường hợp hơn\nCách kiểm dự đoán: Thử ảnh mới rồi so với cốc thật"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Hai bộ cùng 30 ảnh, khác góc và kiểu cốc.\n2. Nói dễ hiểu: Nhiều góc có thể hữu ích; phải thử mới biết.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Giống nhau: Cùng 30 ảnh cốc\nBộ A: Một cốc trắng, cùng một góc\nBộ B: Nhiều cốc và góc phù hợp\nDự đoán có lí do: B có thể bao quát nhiều trường hợp hơn\nCách kiểm dự đoán: Thử ảnh mới rồi so với cốc thật",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 9,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Hai bộ cùng 30 ảnh, khác góc và kiểu cốc.",
          "tone": "key",
          "note": "Thầy/Cô: Hai bộ cùng 30 ảnh, khác góc và kiểu cốc."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nhiều góc có thể hữu ích; phải thử mới biết.",
          "tone": "explain",
          "note": "Thầy/Cô: Nhiều góc có thể hữu ích; phải thử mới biết."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em cần làm gì trước khi khẳng định? Gợi ý: Thử ảnh mới rồi so với cốc thật"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P7.2 Dữ liệu đa dạng",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "B có dữ liệu đa dạng hơn về kiểu cốc và điều kiện, có thể phù hợp hơn với nhiệm vụ nhận nhiều kiểu cốc.",
          "Không thể bảo đảm luôn tốt hơn. Phải kiểm tra chất lượng, mức phù hợp và thử bằng đầu vào mới có nhãn thực.",
          "Bộ thử gồm các cốc mới ở điều kiện được ghi rõ, ngoài tập dạy AI. Không tự dựng tỉ lệ chính xác."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "A: 30 ảnh một cốc, một góc. B: 30 ảnh nhiều cốc, nhiều góc và nền.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Các ảnh đều được gắn nhãn đúng.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "So sánh hai bộ ảnh",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Bộ nào có nhiều kiểu cốc và điều kiện chụp hơn?",
                "key": "07-09-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "So sánh hai bộ ảnh",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vì sao bộ đó có thể phù hợp hơn khi cần nhận nhiều kiểu cốc?",
                "key": "07-09-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Cần thử để biết",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em cần thử bằng những ảnh mới nào để so sánh hai mô hình?",
                "key": "07-09-v3-2"
              }
            ],
            "originalPage": 1
          }
        ],
        "displayCode": "Phiếu A",
        "v7PageMap": {
          "0": 0,
          "1": 4
        }
      },
      "time": 5,
      "id": "07-09",
      "title": "Phiếu A — So sánh dữ liệu",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và kết quả lệch",
        "purpose": "Hoàn thành bộ dữ liệu nào bao quát hơn? theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "B có dữ liệu đa dạng hơn về kiểu cốc và điều kiện, có thể phù hợp hơn với nhiệm vụ nhận nhiều kiểu cốc.",
          "Không thể bảo đảm luôn tốt hơn. Phải kiểm tra chất lượng, mức phù hợp và thử bằng đầu vào mới có nhãn thực.",
          "Bộ thử gồm các cốc mới ở điều kiện được ghi rõ, ngoài tập dạy AI. Không tự dựng tỉ lệ chính xác."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Chỉ điểm giống và khác. Dự đoán có lí do. Đề xuất ảnh mới để thử.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "B có dữ liệu đa dạng hơn về kiểu cốc và điều kiện, có thể phù hợp hơn với nhiệm vụ nhận nhiều kiểu cốc.\nKhông thể bảo đảm luôn tốt hơn. Phải kiểm tra chất lượng, mức phù hợp và thử bằng đầu vào mới có nhãn thực.\nBộ thử gồm các cốc mới ở điều kiện được ghi rõ, ngoài tập dạy AI. Không tự dựng tỉ lệ chính xác.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em so kết quả để rút ra điều có căn cứ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chỉ điểm giống và khác.",
        "Dự đoán có lí do.",
        "Đề xuất ảnh mới để thử."
      ],
      "phase": "Khám phá",
      "scene": "decision",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "07-09-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 10,
      "v7": true,
      "originalTeachingPoints": [
        "Chỉ điểm giống và khác.",
        "Dự đoán có lí do.",
        "Đề xuất ảnh mới để thử."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "Phiếu A · So hai bộ ảnh"
    },
    {
      "type": "conclusion",
      "id": "07-10",
      "title": "Dữ liệu chỉ là một phần",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và kết quả lệch",
        "purpose": "Giải thích đơn giản vai trò dữ liệu đa dạng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp; muốn biết mức ảnh hưởng phải thử.",
        "assessment": "Đạt khi chỉ ra yếu tố thiếu và một cách kiểm. Không đòi thuật ngữ chuyên sâu về thiên lệch.",
        "answers": [
          "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em so kết quả để rút ra điều có căn cứ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ảnh học chưa bao quát có thể gây hạn chế.\n2. Nói dễ hiểu: Dùng với người còn cần xét ảnh hưởng.\n3. Điều cần nhớ: Không kết luận công bằng chỉ từ ảnh cốc.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu ít đa dạng có thể làm kết quả kém phù hợp ở một số trường hợp. Muốn biết mức ảnh hưởng phải thử.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ảnh học chưa bao quát có thể gây hạn chế.",
        "Dùng với người còn cần xét ảnh hưởng.",
        "Không kết luận công bằng chỉ từ ảnh cốc."
      ],
      "phase": "Khám phá",
      "scene": "decision",
      "taskLines": [
        "Trong 30 giây, em nêu một căn cứ tại chỗ."
      ],
      "connector": "Em so kết quả để rút ra điều có căn cứ.",
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [
        "Ảnh học chưa bao quát có thể gây hạn chế.",
        "Dùng với người còn cần xét ảnh hưởng.",
        "Không kết luận công bằng chỉ từ ảnh cốc."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ảnh học chưa bao quát có thể gây hạn chế.",
          "tone": "key",
          "note": "Thầy/Cô: Ảnh học chưa bao quát có thể gây hạn chế."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dùng với người còn cần xét ảnh hưởng.",
          "tone": "explain",
          "note": "Thầy/Cô: Dùng với người còn cần xét ảnh hưởng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không kết luận công bằng chỉ từ ảnh cốc.",
          "tone": "action",
          "note": "Thầy/Cô: Không kết luận công bằng chỉ từ ảnh cốc."
        }
      ]
    },
    {
      "type": "divider",
      "id": "07-11",
      "title": "Thực hành: chọn cách dùng AI",
      "note": {
        "activity": "Khám phá 2.2 Lựa chọn nên dùng hay không",
        "purpose": "Phân tích lợi ích, hạn chế và quyết định có điều kiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
        "assessment": "Đạt ít nhất 3/4 quyết định có lí do phù hợp. Chấp nhận cách lựa chọn khác nhau nếu xử lí rủi ro rõ.",
        "answers": [],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “nộp nguyên bài ai viết hộ?”."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "07-v7-essay1",
      "type": "guide",
      "title": "Nộp nguyên bài AI viết hộ?",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Một em định nộp nguyên bài văn AI viết.",
        "Em chưa tự chọn ý và luyện viết.",
        "Không nhận bài AI viết là bài em tự làm."
      ],
      "scene": "essay",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tự viết bài và kiểm lại nội dung",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Một em định nộp nguyên bài văn AI viết. / Em chưa tự chọn ý và luyện viết. / Không nhận bài AI viết là bài em tự làm."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Nộp nguyên bài AI viết hộ?.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Một em định nộp nguyên bài văn AI viết.\n2. Nói dễ hiểu: Em chưa tự chọn ý và luyện viết.\n3. Điều cần nhớ: Không nhận bài AI viết là bài em tự làm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Một em định nộp nguyên bài văn AI viết. / Em chưa tự chọn ý và luyện viết. / Không nhận bài AI viết là bài em tự làm.",
          "closing": "Thầy/Cô chốt: Không nhận bài AI viết là bài em tự làm.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “đổi cách nhờ ai để em vẫn học”."
        }
      },
      "number": 13,
      "originalTeachingPoints": [
        "Một em định nộp nguyên bài văn AI viết.",
        "Em chưa tự chọn ý và luyện viết.",
        "Không nhận bài AI viết là bài em tự làm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Một em định nộp nguyên bài văn AI viết.",
          "tone": "error",
          "note": "Thầy/Cô: Một em định nộp nguyên bài văn AI viết."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Em chưa tự chọn ý và luyện viết.",
          "tone": "explain",
          "note": "Thầy/Cô: Em chưa tự chọn ý và luyện viết."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không nhận bài AI viết là bài em tự làm.",
          "tone": "action",
          "note": "Thầy/Cô: Không nhận bài AI viết là bài em tự làm."
        }
      ]
    },
    {
      "id": "07-v7-essay2",
      "type": "guide",
      "title": "Đổi cách nhờ AI để em vẫn học",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Em nhờ AI gợi ý dàn ý ba phần.",
        "Em tự chọn ý, viết bài và đọc lại.",
        "Làm theo yêu cầu của Thầy/Cô về dùng AI."
      ],
      "scene": "essay",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tự viết bài và kiểm lại nội dung",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Em nhờ AI gợi ý dàn ý ba phần. / Em tự chọn ý, viết bài và đọc lại. / Làm theo yêu cầu của Thầy/Cô về dùng AI."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đổi cách nhờ AI để em vẫn học.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em nhờ AI gợi ý dàn ý ba phần.\n2. Nói dễ hiểu: Em tự chọn ý, viết bài và đọc lại.\n3. Điều cần nhớ: Làm theo yêu cầu của Thầy/Cô về dùng AI.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Em nhờ AI gợi ý dàn ý ba phần. / Em tự chọn ý, viết bài và đọc lại. / Làm theo yêu cầu của Thầy/Cô về dùng AI.",
          "closing": "Thầy/Cô chốt: Làm theo yêu cầu của Thầy/Cô về dùng AI.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "number": 14,
      "originalTeachingPoints": [
        "Em nhờ AI gợi ý dàn ý ba phần.",
        "Em tự chọn ý, viết bài và đọc lại.",
        "Làm theo yêu cầu của Thầy/Cô về dùng AI."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em nhờ AI gợi ý dàn ý ba phần.",
          "tone": "key",
          "note": "Thầy/Cô: Em nhờ AI gợi ý dàn ý ba phần."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Em tự chọn ý, viết bài và đọc lại.",
          "tone": "explain",
          "note": "Thầy/Cô: Em tự chọn ý, viết bài và đọc lại."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Làm theo yêu cầu của Thầy/Cô về dùng AI.",
          "tone": "action",
          "note": "Thầy/Cô: Làm theo yêu cầu của Thầy/Cô về dùng AI."
        }
      ]
    },
    {
      "id": "07-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu: có nên nhờ AI viết hộ?",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "worked": {
        "title": "Mẫu: có nên nhờ AI viết hộ?",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Cách dùng định chọn",
          "Nên hay không",
          "Vì sao",
          "Cách dùng phù hợp hơn",
          "Việc em tự làm"
        ],
        "values": [
          "Nhờ AI viết toàn bộ rồi nộp",
          "Không nộp nguyên bài như bài em tự viết",
          "Em chưa tự luyện viết và nêu ý",
          "Xin gợi ý câu hỏi hoặc dàn ý",
          "Tự viết bài và kiểm lại nội dung"
        ],
        "why": [
          "AI hỗ trợ không thay phần luyện của em.",
          "Em chịu trách nhiệm về bài nộp.",
          "Chọn hỗ trợ đúng mục tiêu học."
        ],
        "question": "Phần nào em vẫn phải tự làm?",
        "scene": "Decision"
      },
      "targetId": "07-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tự viết bài và kiểm lại nội dung",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Cách dùng định chọn: Nhờ AI viết toàn bộ rồi nộp\nNên hay không: Không nộp nguyên bài như bài em tự viết\nVì sao: Em chưa tự luyện viết và nêu ý\nCách dùng phù hợp hơn: Xin gợi ý câu hỏi hoặc dàn ý\nViệc em tự làm: Tự viết bài và kiểm lại nội dung"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Một em định nộp nguyên bài văn AI viết.\n2. Nói dễ hiểu: Em tự viết để luyện chọn ý và diễn đạt.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Cách dùng định chọn: Nhờ AI viết toàn bộ rồi nộp\nNên hay không: Không nộp nguyên bài như bài em tự viết\nVì sao: Em chưa tự luyện viết và nêu ý\nCách dùng phù hợp hơn: Xin gợi ý câu hỏi hoặc dàn ý\nViệc em tự làm: Tự viết bài và kiểm lại nội dung",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Một em định nộp nguyên bài văn AI viết.",
          "tone": "key",
          "note": "Thầy/Cô: Một em định nộp nguyên bài văn AI viết."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Em tự viết để luyện chọn ý và diễn đạt.",
          "tone": "explain",
          "note": "Thầy/Cô: Em tự viết để luyện chọn ý và diễn đạt."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Phần nào em vẫn phải tự làm? Gợi ý: Tự viết bài và kiểm lại nội dung"
        }
      ]
    },
    {
      "type": "task",
      "id": "07-12",
      "title": "Chọn cách dùng, nêu điều kiện",
      "note": {
        "activity": "Khám phá 2.2 Lựa chọn nên dùng hay không",
        "purpose": "Phân tích lợi ích, hạn chế và quyết định có điều kiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
        "assessment": "Đạt ít nhất 3/4 quyết định có lí do phù hợp. Chấp nhận cách lựa chọn khác nhau nếu xử lí rủi ro rõ.",
        "answers": [
          "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Xem lợi ích và hạn chế.\n2. Nói dễ hiểu: Chọn dùng / dùng có điều kiện / chưa dùng.\n3. Điều cần nhớ: Nói rõ vì sao.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem một tình huống trước khi tự chọn cách dùng."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Xem lợi ích và hạn chế.",
        "Chọn dùng / dùng có điều kiện / chưa dùng.",
        "Nói rõ vì sao."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 11 phút, em chọn cách dùng trên phiếu tình huống."
      ],
      "sampleId": "07-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [
        "Xem lợi ích và hạn chế.",
        "Chọn dùng / dùng có điều kiện / chưa dùng.",
        "Nói rõ vì sao."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Xem lợi ích và hạn chế.",
          "tone": "key",
          "note": "Thầy/Cô: Xem lợi ích và hạn chế."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chọn dùng / dùng có điều kiện / chưa dùng.",
          "tone": "explain",
          "note": "Thầy/Cô: Chọn dùng / dùng có điều kiện / chưa dùng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nói rõ vì sao.",
          "tone": "action",
          "note": "Thầy/Cô: Nói rõ vì sao."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 0,
      "id": "07-13",
      "title": "Làm mẫu: dùng AI dịch câu",
      "note": {
        "activity": "Khám phá 2.2 Lựa chọn nên dùng hay không",
        "purpose": "Phân tích lợi ích, hạn chế và quyết định có điều kiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
        "assessment": "Đạt ít nhất 3/4 quyết định có lí do phù hợp. Chấp nhận cách lựa chọn khác nhau nếu xử lí rủi ro rõ.",
        "answers": [
          "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem một tình huống trước khi tự chọn cách dùng.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Có ích: gợi ý nghĩa.\n2. Nói dễ hiểu: Hạn chế: có thể dịch chưa phù hợp.\n3. Điều cần nhớ: Điều kiện: có nguồn để kiểm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “học xong phần cần thiết thì làm gì?”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Có ích: gợi ý nghĩa.",
        "Hạn chế: có thể dịch chưa phù hợp.",
        "Điều kiện: có nguồn để kiểm."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Em xem một tình huống trước khi tự chọn cách dùng.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Có ích: gợi ý nghĩa.",
        "Hạn chế: có thể dịch chưa phù hợp.",
        "Điều kiện: có nguồn để kiểm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Có ích: gợi ý nghĩa.",
          "tone": "key",
          "note": "Thầy/Cô: Có ích: gợi ý nghĩa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Hạn chế: có thể dịch chưa phù hợp.",
          "tone": "explain",
          "note": "Thầy/Cô: Hạn chế: có thể dịch chưa phù hợp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Điều kiện: có nguồn để kiểm.",
          "tone": "action",
          "note": "Thầy/Cô: Điều kiện: có nguồn để kiểm."
        }
      ]
    },
    {
      "id": "07-v7-watch",
      "type": "guide",
      "title": "Học xong phần cần thiết thì làm gì?",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Video học đã trả lời câu hỏi của em.",
        "Gợi ý xem tiếp có thể kéo dài thời gian.",
        "Dừng xem; quay lại hoàn thành bài."
      ],
      "scene": "video",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dừng xem và quay lại bài làm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Video học đã trả lời câu hỏi của em. / Gợi ý xem tiếp có thể kéo dài thời gian. / Dừng xem; quay lại hoàn thành bài."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Học xong phần cần thiết thì làm gì?.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Video học đã trả lời câu hỏi của em.\n2. Nói dễ hiểu: Gợi ý xem tiếp có thể kéo dài thời gian.\n3. Điều cần nhớ: Dừng xem; quay lại hoàn thành bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Video học đã trả lời câu hỏi của em. / Gợi ý xem tiếp có thể kéo dài thời gian. / Dừng xem; quay lại hoàn thành bài.",
          "closing": "Thầy/Cô chốt: Dừng xem; quay lại hoàn thành bài.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "number": 18,
      "originalTeachingPoints": [
        "Video học đã trả lời câu hỏi của em.",
        "Gợi ý xem tiếp có thể kéo dài thời gian.",
        "Dừng xem; quay lại hoàn thành bài."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Video học đã trả lời câu hỏi của em.",
          "tone": "key",
          "note": "Thầy/Cô: Video học đã trả lời câu hỏi của em."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Gợi ý xem tiếp có thể kéo dài thời gian.",
          "tone": "explain",
          "note": "Thầy/Cô: Gợi ý xem tiếp có thể kéo dài thời gian."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Dừng xem; quay lại hoàn thành bài.",
          "tone": "action",
          "note": "Thầy/Cô: Dừng xem; quay lại hoàn thành bài."
        }
      ]
    },
    {
      "id": "07-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu một lựa chọn có điều kiện",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "video",
      "worked": {
        "title": "Mẫu một lựa chọn có điều kiện",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Lợi ích",
          "Hạn chế",
          "Lựa chọn",
          "Điều kiện",
          "Việc khi hết mục tiêu"
        ],
        "values": [
          "Tìm được video cần cho bài",
          "Dễ xem tiếp nội dung không liên quan",
          "Chỉ dùng để tìm bài cần học",
          "Đặt điểm dừng theo nhiệm vụ",
          "Dừng xem và quay lại bài làm"
        ],
        "why": [
          "Nêu cả mặt giúp và mặt cản.",
          "Điều kiện phải làm được ngay.",
          "Không coi mọi video gợi ý đều xấu."
        ],
        "question": "Khi xem đủ phần cần học, em làm gì?",
        "scene": "Video"
      },
      "targetId": "07-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dừng xem và quay lại bài làm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Lợi ích: Tìm được video cần cho bài\nHạn chế: Dễ xem tiếp nội dung không liên quan\nLựa chọn: Chỉ dùng để tìm bài cần học\nĐiều kiện: Đặt điểm dừng theo nhiệm vụ\nViệc khi hết mục tiêu: Dừng xem và quay lại bài làm"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Video học gợi ý thêm nội dung ngoài bài.\n2. Nói dễ hiểu: Dừng ở mục tiêu bài học, không theo mọi gợi ý.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Lợi ích: Tìm được video cần cho bài\nHạn chế: Dễ xem tiếp nội dung không liên quan\nLựa chọn: Chỉ dùng để tìm bài cần học\nĐiều kiện: Đặt điểm dừng theo nhiệm vụ\nViệc khi hết mục tiêu: Dừng xem và quay lại bài làm",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Video học gợi ý thêm nội dung ngoài bài.",
          "tone": "key",
          "note": "Thầy/Cô: Video học gợi ý thêm nội dung ngoài bài."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dừng ở mục tiêu bài học, không theo mọi gợi ý.",
          "tone": "explain",
          "note": "Thầy/Cô: Dừng ở mục tiêu bài học, không theo mọi gợi ý."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Khi xem đủ phần cần học, em làm gì? Gợi ý: Dừng xem và quay lại bài làm"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P7.1 Lợi ích và lựa chọn sử dụng",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "1 Có thể dùng có kiểm tra. Giúp hiểu câu, có nguy cơ dịch sai.",
          "2 Có ích tìm nội dung nhưng dễ kéo dài thời gian. Đặt mục tiêu, giới hạn thời gian, chọn nội dung và dừng khi cần.",
          "3 Không tin ngay nhãn sai. Kiểm vật thật và xem dữ liệu/điều kiện, có thể dùng để học kiểm thử có hướng dẫn.",
          "4 Không gửi thông tin không cần. Hỏi mục đích, từ chối quyền không liên quan và nhờ Thầy/Cô. Chấp nhận lựa chọn khác nếu điều kiện/rủi ro được giải thích thỏa đáng."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "AI giúp dịch câu. Có bảng từ và Thầy/Cô để đối chiếu.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Tình huống 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có ích ở điểm nào? Có thể gây khó khăn gì?",
                "key": "07-17-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Tình huống 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai có thể bị ảnh hưởng?",
                "key": "07-17-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Tình huống 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn cách nào?",
                "options": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ],
                "key": "07-17-v3-2",
                "optionLabels": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Tình huống 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ kiểm tra hoặc xử lí thế nào?",
                "key": "07-17-v3-3"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Ứng dụng gợi video học. Sau đó, ứng dụng gợi nhiều video không liên quan.",
            "originalPage": 1,
            "referenceOnly": true
          },
          {
            "title": "Tình huống 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có ích ở điểm nào? Có thể gây khó khăn gì?",
                "key": "07-17-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Tình huống 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai có thể bị ảnh hưởng?",
                "key": "07-17-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Tình huống 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn cách nào?",
                "options": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ],
                "key": "07-17-v3-6",
                "optionLabels": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ]
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Tình huống 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ kiểm tra hoặc xử lí thế nào?",
                "key": "07-17-v3-7"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Mô hình gọi một chiếc cốc là Bút.",
            "originalPage": 2,
            "referenceOnly": true
          },
          {
            "title": "Tình huống 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có ích ở điểm nào? Có thể gây khó khăn gì?",
                "key": "07-17-v3-8"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Tình huống 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai có thể bị ảnh hưởng?",
                "key": "07-17-v3-9"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Tình huống 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn cách nào?",
                "options": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ],
                "key": "07-17-v3-10",
                "optionLabels": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ]
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Tình huống 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ kiểm tra hoặc xử lí thế nào?",
                "key": "07-17-v3-11"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Công cụ hỏi bài yêu cầu địa chỉ nhà, vị trí và số liên hệ.",
            "originalPage": 3,
            "referenceOnly": true
          },
          {
            "title": "Tình huống 4",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có ích ở điểm nào? Có thể gây khó khăn gì?",
                "key": "07-17-v3-12"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Tình huống 4",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai có thể bị ảnh hưởng?",
                "key": "07-17-v3-13"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Tình huống 4",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn cách nào?",
                "options": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ],
                "key": "07-17-v3-14",
                "optionLabels": [
                  "Dùng và kiểm tra kết quả",
                  "Chỉ dùng khi đáp ứng điều kiện",
                  "Tạm không dùng trong tình huống này"
                ]
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Tình huống 4",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ kiểm tra hoặc xử lí thế nào?",
                "key": "07-17-v3-15"
              }
            ],
            "originalPage": 3
          }
        ],
        "displayCode": "Phiếu B",
        "v7PageMap": {
          "0": 0,
          "1": 5,
          "2": 10,
          "3": 15
        }
      },
      "time": 16,
      "id": "07-17",
      "title": "Phiếu B — Quyết định có lí do",
      "note": {
        "activity": "Khám phá 2.2 Lựa chọn nên dùng hay không",
        "purpose": "Hoàn thành bảng quyết định của nhóm theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1 Có thể dùng có kiểm tra. Giúp hiểu câu, có nguy cơ dịch sai.",
          "2 Có ích tìm nội dung nhưng dễ kéo dài thời gian. Đặt mục tiêu, giới hạn thời gian, chọn nội dung và dừng khi cần.",
          "3 Không tin ngay nhãn sai. Kiểm vật thật và xem dữ liệu/điều kiện, có thể dùng để học kiểm thử có hướng dẫn.",
          "4 Không gửi thông tin không cần. Hỏi mục đích, từ chối quyền không liên quan và nhờ Thầy/Cô. Chấp nhận lựa chọn khác nếu điều kiện/rủi ro được giải thích thỏa đáng."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Tình huống giúp việc gì? Có hạn chế hoặc rủi ro nào? Em chọn cách dùng ra sao?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1 Có thể dùng có kiểm tra. Giúp hiểu câu, có nguy cơ dịch sai.\n2 Có ích tìm nội dung nhưng dễ kéo dài thời gian. Đặt mục tiêu, giới hạn thời gian, chọn nội dung và dừng khi cần.\n3 Không tin ngay nhãn sai. Kiểm vật thật và xem dữ liệu/điều kiện, có thể dùng để học kiểm thử có hướng dẫn.\n4 Không gửi thông tin không cần. Hỏi mục đích, từ chối quyền không liên quan và nhờ Thầy/Cô. Chấp nhận lựa chọn khác nếu điều kiện/rủi ro được giải thích thỏa đáng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tình huống giúp việc gì?",
        "Có hạn chế hoặc rủi ro nào?",
        "Em chọn cách dùng ra sao?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "07-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [
        "Tình huống giúp việc gì?",
        "Có hạn chế hoặc rủi ro nào?",
        "Em chọn cách dùng ra sao?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "Phiếu B · Chọn cách dùng"
    },
    {
      "type": "report",
      "id": "07-18",
      "title": "Khác lựa chọn, có khác căn cứ?",
      "note": {
        "activity": "Khám phá 2.2 Lựa chọn nên dùng hay không",
        "purpose": "Phân tích lợi ích, hạn chế và quyết định có điều kiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
        "assessment": "Đạt ít nhất 3/4 quyết định có lí do phù hợp. Chấp nhận cách lựa chọn khác nhau nếu xử lí rủi ro rõ.",
        "answers": [
          "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em muốn đạt mục đích gì?\n2. Nói dễ hiểu: Em kiểm được điều gì?\n3. Điều cần nhớ: Điều kiện nào làm lựa chọn thay đổi?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Em muốn đạt mục đích gì?",
        "Em kiểm được điều gì?",
        "Điều kiện nào làm lựa chọn thay đổi?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 21,
      "v7": true,
      "originalTeachingPoints": [
        "Em muốn đạt mục đích gì?",
        "Em kiểm được điều gì?",
        "Điều kiện nào làm lựa chọn thay đổi?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em muốn đạt mục đích gì?",
          "tone": "key",
          "note": "Thầy/Cô: Em muốn đạt mục đích gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Em kiểm được điều gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Em kiểm được điều gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Điều kiện nào làm lựa chọn thay đổi?",
          "tone": "action",
          "note": "Thầy/Cô: Điều kiện nào làm lựa chọn thay đổi?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "07-20",
      "title": "Luyện tập: nêu lựa chọn có lí do",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Tự đưa ra lựa chọn và giải thích.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tìm hiểu kiến thức cần kiểm chứng; quyết định liên quan an toàn phải có người có chuyên môn.",
        "assessment": "Đánh giá căn cứ, không kiểm tra kiến thức thực vật ngoài bài.",
        "answers": [],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "07-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu tách tìm hiểu và quyết định",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "worked": {
        "title": "Mẫu tách tìm hiểu và quyết định",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Việc AI gợi",
          "Điều em biết",
          "Điều chưa chắc",
          "Cách dùng để tìm hiểu",
          "Quyết định cần tránh"
        ],
        "values": [
          "Một tên lá",
          "Đó là gợi ý từ ảnh",
          "Tên đúng và độ an toàn của lá",
          "Xem nguồn phù hợp, hỏi người có chuyên môn",
          "Không ăn hoặc dùng làm thuốc chỉ vì gợi ý"
        ],
        "why": [
          "Tên gợi ý không bảo đảm an toàn.",
          "Mục đích tìm hiểu khác quyết định sức khỏe.",
          "Em chưa có đủ căn cứ để dùng lá."
        ],
        "question": "Em không nên quyết định gì từ gợi ý này?",
        "scene": "Decision"
      },
      "targetId": "07-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không ăn hoặc dùng làm thuốc chỉ vì gợi ý",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Việc AI gợi: Một tên lá\nĐiều em biết: Đó là gợi ý từ ảnh\nĐiều chưa chắc: Tên đúng và độ an toàn của lá\nCách dùng để tìm hiểu: Xem nguồn phù hợp, hỏi người có chuyên môn\nQuyết định cần tránh: Không ăn hoặc dùng làm thuốc chỉ vì gợi ý"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI gợi tên lá; em chưa biết có an toàn.\n2. Nói dễ hiểu: Tên lá gợi ý chưa chứng minh lá ăn được.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Việc AI gợi: Một tên lá\nĐiều em biết: Đó là gợi ý từ ảnh\nĐiều chưa chắc: Tên đúng và độ an toàn của lá\nCách dùng để tìm hiểu: Xem nguồn phù hợp, hỏi người có chuyên môn\nQuyết định cần tránh: Không ăn hoặc dùng làm thuốc chỉ vì gợi ý",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI gợi tên lá; em chưa biết có an toàn.",
          "tone": "key",
          "note": "Thầy/Cô: AI gợi tên lá; em chưa biết có an toàn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tên lá gợi ý chưa chứng minh lá ăn được.",
          "tone": "explain",
          "note": "Thầy/Cô: Tên lá gợi ý chưa chứng minh lá ăn được."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em không nên quyết định gì từ gợi ý này? Gợi ý: Không ăn hoặc dùng làm thuốc chỉ vì gợi ý"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P7.3 Quy tắc có thể thực hiện",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "1. Sai: một cách dùng AI có thể vừa có lợi ích vừa có hạn chế.",
          "2. Sai: cần xem dữ liệu có phù hợp, đa dạng và ai có thể bị ảnh hưởng. Nhiều dữ liệu không tự bảo đảm công bằng.",
          "3. Đúng: cần xét mục đích và cách kiểm tra.",
          "4. Không dựa vào nhãn ảnh để quyết định ăn lá. Nhận dạng có thể sai.",
          "5. Nếu muốn tìm hiểu tên cây, xem sách/tài liệu phù hợp hoặc hỏi Thầy/Cô. Tìm được tên chưa xác nhận cây ăn được."
        ],
        "pages": [
          {
            "title": "Đúng hay sai? Vì sao?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“AI có lợi thì không có hạn chế.”",
                "key": "07-21-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đúng hay sai? Vì sao?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“Càng nhiều dữ liệu thì kết quả luôn công bằng.”",
                "key": "07-21-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đúng hay sai? Vì sao?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“Trước khi dùng, cần xét mục đích và cách kiểm tra.”",
                "key": "07-21-v3-2"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Phân biệt tìm hiểu với quyết định an toàn",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có nên dựa vào gợi ý đó để quyết định ăn lá không? Vì sao?",
                "key": "07-21-v3-3"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Phân biệt tìm hiểu với quyết định an toàn",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nếu chỉ muốn tìm hiểu tên cây, em có thể kiểm tra thêm bằng gì?",
                "key": "07-21-v3-4"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 3
        }
      },
      "time": 4,
      "id": "07-21",
      "title": "P7.3A — Tự cân nhắc trước khi dùng",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành tự đưa ra lựa chọn theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tìm hiểu kiến thức cần kiểm chứng; quyết định liên quan an toàn phải có người có chuyên môn.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1. Sai: một cách dùng AI có thể vừa có lợi ích vừa có hạn chế.",
          "2. Sai: cần xem dữ liệu có phù hợp, đa dạng và ai có thể bị ảnh hưởng. Nhiều dữ liệu không tự bảo đảm công bằng.",
          "3. Đúng: cần xét mục đích và cách kiểm tra.",
          "4. Không dựa vào nhãn ảnh để quyết định ăn lá. Nhận dạng có thể sai.",
          "5. Nếu muốn tìm hiểu tên cây, xem sách/tài liệu phù hợp hoặc hỏi Thầy/Cô. Tìm được tên chưa xác nhận cây ăn được."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Nhận dạng tên lá có thể phục vụ tìm hiểu. Không dùng riêng gợi ý ảnh để quyết định ăn, uống hoặc dùng làm thuốc. Tình huống chỉ yêu cầu giải thích giới hạn quyết định.\nÝ cần giảng rõ: Sửa ý nói quá chắc chắn. Phân biệt tìm hiểu và quyết định an toàn. Nêu cách kiểm phù hợp.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1. Sai: một cách dùng AI có thể vừa có lợi ích vừa có hạn chế.\n2. Sai: cần xem dữ liệu có phù hợp, đa dạng và ai có thể bị ảnh hưởng. Nhiều dữ liệu không tự bảo đảm công bằng.\n3. Đúng: cần xét mục đích và cách kiểm tra.\n4. Không dựa vào nhãn ảnh để quyết định ăn lá. Nhận dạng có thể sai.\n5. Nếu muốn tìm hiểu tên cây, xem sách/tài liệu phù hợp hoặc hỏi Thầy/Cô. Tìm được tên chưa xác nhận cây ăn được.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Sửa ý nói quá chắc chắn.",
        "Phân biệt tìm hiểu và quyết định an toàn.",
        "Nêu cách kiểm phù hợp."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "07-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [
        "Sửa ý nói quá chắc chắn.",
        "Phân biệt tìm hiểu và quyết định an toàn.",
        "Nêu cách kiểm phù hợp."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P7.3A · Em tự làm"
    },
    {
      "type": "recap",
      "id": "07-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Lựa chọn nên dùng hay không",
        "purpose": "Phân tích lợi ích, hạn chế và quyết định có điều kiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
        "assessment": "Đạt ít nhất 3/4 quyết định có lí do phù hợp. Chấp nhận cách lựa chọn khác nhau nếu xử lí rủi ro rõ.",
        "answers": [
          "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Cân nhắc lợi ích và hạn chế cùng lúc.\n2. Nói dễ hiểu: Dữ liệu đa dạng vẫn cần được kiểm thử.\n3. Điều cần nhớ: Chọn cách dùng theo mục đích và điều kiện.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Quyết định phù hợp gắn với nhu cầu, bằng chứng, quyền riêng tư và khả năng kiểm tra của con người.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Cân nhắc lợi ích và hạn chế cùng lúc.",
        "Dữ liệu đa dạng vẫn cần được kiểm thử.",
        "Chọn cách dùng theo mục đích và điều kiện."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "decision",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [
        "Cân nhắc lợi ích và hạn chế cùng lúc.",
        "Dữ liệu đa dạng vẫn cần được kiểm thử.",
        "Chọn cách dùng theo mục đích và điều kiện."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Cân nhắc lợi ích và hạn chế cùng lúc.",
          "tone": "key",
          "note": "Thầy/Cô: Cân nhắc lợi ích và hạn chế cùng lúc."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dữ liệu đa dạng vẫn cần được kiểm thử.",
          "tone": "explain",
          "note": "Thầy/Cô: Dữ liệu đa dạng vẫn cần được kiểm thử."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chọn cách dùng theo mục đích và điều kiện.",
          "tone": "action",
          "note": "Thầy/Cô: Chọn cách dùng theo mục đích và điều kiện."
        }
      ]
    },
    {
      "type": "divider",
      "id": "07-22",
      "title": "Vận dụng: quy tắc của em",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Viết quy tắc sử dụng AI có thể thực hiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quy tắc có ích khi chỉ ra việc cần làm và khi nào làm.",
        "assessment": "Kết hợp bảng tình huống và thẻ cá nhân để nhận xét năng lực đánh giá, không suy từ sản phẩm nhóm.",
        "answers": [],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "decision",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "07-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu biến khẩu hiệu thành hành động",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "video",
      "worked": {
        "title": "Mẫu biến khẩu hiệu thành hành động",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Lời chung chung",
          "Tình huống",
          "Hành động",
          "Lúc thực hiện",
          "Cách biết đã làm"
        ],
        "values": [
          "Dùng AI có trách nhiệm",
          "AI gợi nhiều video xem tiếp",
          "Chọn video đúng câu hỏi bài học",
          "Dừng khi đã tìm đủ phần cần học",
          "Em quay lại hoàn thành bài đang làm"
        ],
        "why": [
          "Quy tắc phải nói việc em làm.",
          "Nêu lúc dừng để dễ thực hiện.",
          "Không chỉ viết một lời hứa chung."
        ],
        "question": "Em nhận ra đã làm đúng bằng dấu hiệu nào?",
        "scene": "Video"
      },
      "targetId": "07-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Em quay lại hoàn thành bài đang làm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Lời chung chung: Dùng AI có trách nhiệm\nTình huống: AI gợi nhiều video xem tiếp\nHành động: Chọn video đúng câu hỏi bài học\nLúc thực hiện: Dừng khi đã tìm đủ phần cần học\nCách biết đã làm: Em quay lại hoàn thành bài đang làm"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em cần video trả lời một câu hỏi bài học.\n2. Nói dễ hiểu: Một quy tắc cần nói rõ lúc làm và cách làm.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Lời chung chung: Dùng AI có trách nhiệm\nTình huống: AI gợi nhiều video xem tiếp\nHành động: Chọn video đúng câu hỏi bài học\nLúc thực hiện: Dừng khi đã tìm đủ phần cần học\nCách biết đã làm: Em quay lại hoàn thành bài đang làm",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em cần video trả lời một câu hỏi bài học.",
          "tone": "key",
          "note": "Thầy/Cô: Em cần video trả lời một câu hỏi bài học."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Một quy tắc cần nói rõ lúc làm và cách làm.",
          "tone": "explain",
          "note": "Thầy/Cô: Một quy tắc cần nói rõ lúc làm và cách làm."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em nhận ra đã làm đúng bằng dấu hiệu nào? Gợi ý: Em quay lại hoàn thành bài đang làm"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P7.3 Quy tắc có thể thực hiện",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "B Ví dụ: kiểm hai chi tiết bằng nguồn. Bỏ trường địa chỉ trước chia sẻ. Dừng xem khi hết thời gian đã định. Không chỉ viết dùng AI có trách nhiệm."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Ví dụ: Em kiểm từ chưa hiểu bằng bảng từ trước khi dùng bản dịch.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Viết ba quy tắc cụ thể",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Quy tắc kiểm tra kết quả",
                "key": "07-23-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Viết ba quy tắc cụ thể",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Quy tắc bảo vệ thông tin cá nhân",
                "key": "07-23-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Viết ba quy tắc cụ thể",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Quy tắc quản lí thời gian hoặc lựa chọn nội dung",
                "key": "07-23-v3-2"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Viết ba quy tắc cụ thể",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em ưu tiên quy tắc nào cho dự án? Vì sao?",
                "key": "07-23-v3-3"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 3,
      "id": "07-23",
      "title": "P7.3B — Ba quy tắc làm được",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Hoàn thành ba quy tắc có thể thực hiện theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quy tắc có ích khi chỉ ra việc cần làm và khi nào làm.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "B Ví dụ: kiểm hai chi tiết bằng nguồn. Bỏ trường địa chỉ trước chia sẻ. Dừng xem khi hết thời gian đã định. Không chỉ viết dùng AI có trách nhiệm."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Mỗi quy tắc nêu một hành động. Nói rõ lúc nào thực hiện. Tránh khẩu hiệu chung chung.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "B Ví dụ: kiểm hai chi tiết bằng nguồn. Bỏ trường địa chỉ trước chia sẻ. Dừng xem khi hết thời gian đã định. Không chỉ viết dùng AI có trách nhiệm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mỗi quy tắc nêu một hành động.",
        "Nói rõ lúc nào thực hiện.",
        "Tránh khẩu hiệu chung chung."
      ],
      "phase": "Vận dụng",
      "scene": "decision",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "07-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [
        "Mỗi quy tắc nêu một hành động.",
        "Nói rõ lúc nào thực hiện.",
        "Tránh khẩu hiệu chung chung."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P7.3B · Em tự làm"
    },
    {
      "type": "home",
      "id": "07-24",
      "title": "Mang tới một nhu cầu gần gũi",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Viết quy tắc sử dụng AI có thể thực hiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Quy tắc có ích khi chỉ ra việc cần làm và khi nào làm.",
        "assessment": "Kết hợp bảng tình huống và thẻ cá nhân để nhận xét năng lực đánh giá, không suy từ sản phẩm nhóm.",
        "answers": [
          "Quy tắc có ích khi chỉ ra việc cần làm và khi nào làm."
        ],
        "source": "Bài 11 AI quanh ta và tác động thực tế, trang in 81–82 và mục Lợi ích, khó khăn; Bài 12 Đạo đức AI quyền riêng tư và công bằng, rủi ro và dữ liệu thiên lệch, trang in 91, 94.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ai cần giúp?\n2. Nói dễ hiểu: AI hỗ trợ việc gì?\n3. Điều cần nhớ: Có giới hạn nào cần lưu ý?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Quy tắc có ích khi chỉ ra việc cần làm và khi nào làm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ai cần giúp?",
        "AI hỗ trợ việc gì?",
        "Có giới hạn nào cần lưu ý?"
      ],
      "phase": "Vận dụng",
      "scene": "decision",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [
        "Ai cần giúp?",
        "AI hỗ trợ việc gì?",
        "Có giới hạn nào cần lưu ý?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ai cần giúp?",
          "tone": "key",
          "note": "Thầy/Cô: Ai cần giúp?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI hỗ trợ việc gì?",
          "tone": "explain",
          "note": "Thầy/Cô: AI hỗ trợ việc gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Có giới hạn nào cần lưu ý?",
          "tone": "action",
          "note": "Thầy/Cô: Có giới hạn nào cần lưu ý?"
        }
      ]
    }
  ],
  "rubric": [],
  "evidence": [
    [
      "Phân tích tình huống",
      "6.3.TC1b",
      "Tóm tắt lợi ích, hạn chế và ảnh hưởng.",
      "P7.1, P7.3A",
      "Có hai mặt và người chịu ảnh hưởng; dùng ví dụ cụ thể."
    ],
    [
      "Quyết định và quy tắc",
      "6.2.TC1c",
      "Cân nhắc an toàn, đạo đức và riêng tư.",
      "Lí do lựa chọn và P7.3B",
      "Nêu điều kiện thực hiện được; hỏi bổ sung nếu chỉ viết nên cẩn thận."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
