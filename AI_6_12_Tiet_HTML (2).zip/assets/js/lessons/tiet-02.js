window.AI6_LESSON={
  "id": 2,
  "title": "Bài 2. Con người tạo và điều khiển AI",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 32,
  "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do GV thiết kế.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 2,
    "title": "AI: What is Machine Learning?",
    "start": 120,
    "end": 150,
    "poster": "frame_2_135.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/5EavZqgaf5cKZ9dKyk9m2h/7e2c2c2c3fdd5224a8171accaf272d85/ai-02-machine-learning.mp4",
    "question": "Tìm phần việc con người làm trước khi máy đưa ra dự đoán. Ví dụ dùng để học khác đầu vào mới ra sao?",
    "local": "code-2.mp4"
  },
  "outcome": "Hai sơ đồ và bảng con người làm việc gì.",
  "slides": [
    {
      "type": "cover",
      "id": "02-01",
      "title": "Bài 2. Con người tạo và điều khiển AI",
      "note": {
        "activity": "Khởi động",
        "purpose": "Xác định vai trò con người qua một kết quả AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người tạo, triển khai và quyết định cách dùng AI; công cụ có thể vận hành tự động trong phạm vi thiết kế.",
        "assessment": "Không chấp nhận giải thích AI tự sinh ra hoặc luôn có người bấm từng bước. Hỏi lại bằng ví dụ cụ thể.",
        "answers": [
          "Con người tạo, triển khai và quyết định cách dùng AI. Công cụ có thể vận hành tự động trong phạm vi thiết kế."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Con người tạo, triển khai và quyết định cách dùng AI. Công cụ có thể vận hành tự động trong phạm vi thiết kế.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "learn-use",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "02-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Xác định vai trò con người qua một kết quả AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người tạo, triển khai và quyết định cách dùng AI; công cụ có thể vận hành tự động trong phạm vi thiết kế.",
        "assessment": "Không chấp nhận giải thích AI tự sinh ra hoặc luôn có người bấm từng bước. Hỏi lại bằng ví dụ cụ thể.",
        "answers": [
          "Con người tạo, triển khai và quyết định cách dùng AI. Công cụ có thể vận hành tự động trong phạm vi thiết kế."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nêu việc con người làm khi tạo AI.\n2. Nói dễ hiểu: Phân biệt dữ liệu, thuật toán, mô hình, dự đoán.\n3. Điều cần nhớ: Vẽ quy trình tạo và dùng mô hình.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Con người tạo, triển khai và quyết định cách dùng AI. Công cụ có thể vận hành tự động trong phạm vi thiết kế.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nêu việc con người làm khi tạo AI.",
        "Phân biệt dữ liệu, thuật toán, mô hình, dự đoán.",
        "Vẽ quy trình tạo và dùng mô hình."
      ],
      "phase": "Khởi động",
      "scene": "learn-use",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Nêu việc con người làm khi tạo AI.",
        "Phân biệt dữ liệu, thuật toán, mô hình, dự đoán.",
        "Vẽ quy trình tạo và dùng mô hình."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nêu việc con người làm khi tạo AI.",
          "tone": "key",
          "note": "Thầy/Cô: Nêu việc con người làm khi tạo AI."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Phân biệt dữ liệu, thuật toán, mô hình, dự đoán.",
          "tone": "explain",
          "note": "Thầy/Cô: Phân biệt dữ liệu, thuật toán, mô hình, dự đoán."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Vẽ quy trình tạo và dùng mô hình.",
          "tone": "action",
          "note": "Thầy/Cô: Vẽ quy trình tạo và dùng mô hình."
        }
      ]
    },
    {
      "type": "divider",
      "id": "02-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Xác định vai trò con người qua một kết quả AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người tạo, triển khai và quyết định cách dùng AI; công cụ có thể vận hành tự động trong phạm vi thiết kế.",
        "assessment": "Không chấp nhận giải thích AI tự sinh ra hoặc luôn có người bấm từng bước. Hỏi lại bằng ví dụ cụ thể.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "learn-use",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "02-04",
      "title": "Ai giúp máy nhận ra cốc?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Xác định vai trò con người qua một kết quả AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người tạo, triển khai và quyết định cách dùng AI; công cụ có thể vận hành tự động trong phạm vi thiết kế.",
        "assessment": "Không chấp nhận giải thích AI tự sinh ra hoặc luôn có người bấm từng bước. Hỏi lại bằng ví dụ cụ thể.",
        "answers": [
          "Con người tạo, triển khai và quyết định cách dùng AI. Công cụ có thể vận hành tự động trong phạm vi thiết kế."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ai chọn nhiệm vụ?\n2. Nói dễ hiểu: Ai chuẩn bị ảnh?\n3. Điều cần nhớ: Ai kiểm tra kết quả?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Con người tạo, triển khai và quyết định cách dùng AI. Công cụ có thể vận hành tự động trong phạm vi thiết kế.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ai chọn nhiệm vụ?",
        "Ai chuẩn bị ảnh?",
        "Ai kiểm tra kết quả?"
      ],
      "phase": "Khởi động",
      "scene": "learn-use",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Ai chọn nhiệm vụ?",
        "Ai chuẩn bị ảnh?",
        "Ai kiểm tra kết quả?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ai chọn nhiệm vụ?",
          "tone": "key",
          "note": "Thầy/Cô: Ai chọn nhiệm vụ?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ai chuẩn bị ảnh?",
          "tone": "explain",
          "note": "Thầy/Cô: Ai chuẩn bị ảnh?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ai kiểm tra kết quả?",
          "tone": "action",
          "note": "Thầy/Cô: Ai kiểm tra kết quả?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "02-05",
      "title": "Khám phá: máy học từ ví dụ",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và cách máy học",
        "purpose": "Giải thích đơn giản dữ liệu, thuật toán, mô hình và dự đoán.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán.",
        "assessment": "Đạt khi ghép đúng ít nhất 3/4 khái niệm và tách được hai quá trình. Dùng thẻ màu/vị trí để hỗ trợ các em còn nhầm.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "learn-use",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_2_135.jpg",
      "id": "02-06",
      "title": "Trước dự đoán, cần có gì?",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và cách máy học",
        "purpose": "Giải thích đơn giản dữ liệu, thuật toán, mô hình và dự đoán.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán.",
        "assessment": "Đạt khi ghép đúng ít nhất 3/4 khái niệm và tách được hai quá trình. Dùng thẻ màu/vị trí để hỗ trợ các em còn nhầm.",
        "answers": [
          "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Con người chuẩn bị những ví dụ nào?\n2. Nói dễ hiểu: Ảnh dùng để học khác ảnh mới ở đâu?\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Con người chuẩn bị những ví dụ nào?",
        "Ảnh dùng để học khác ảnh mới ở đâu?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "Con người chuẩn bị những ví dụ nào?",
        "Ảnh dùng để học khác ảnh mới ở đâu?",
        "Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Con người chuẩn bị những ví dụ nào?",
          "tone": "key",
          "note": "Thầy/Cô: Con người chuẩn bị những ví dụ nào?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh dùng để học khác ảnh mới ở đâu?",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh dùng để học khác ảnh mới ở đâu?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán."
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 2,
        "title": "AI: What is Machine Learning?",
        "start": 120,
        "end": 150,
        "poster": "frame_2_135.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/5EavZqgaf5cKZ9dKyk9m2h/7e2c2c2c3fdd5224a8171accaf272d85/ai-02-machine-learning.mp4",
        "question": "Con người chuẩn bị gì cho máy học?",
        "local": "code-2.mp4"
      },
      "id": "02-07",
      "title": "Máy học từ ví dụ",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và cách máy học",
        "purpose": "Giải thích đơn giản dữ liệu, thuật toán, mô hình và dự đoán.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán.",
        "assessment": "Đạt khi ghép đúng ít nhất 3/4 khái niệm và tách được hai quá trình. Dùng thẻ màu/vị trí để hỗ trợ các em còn nhầm.",
        "answers": [
          "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: Tìm dữ liệu con người chuẩn bị. Tìm lúc máy xử lí đầu vào mới.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tìm dữ liệu con người chuẩn bị.",
        "Tìm lúc máy xử lí đầu vào mới."
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 30 giây, em ghi một ví dụ vào vở."
      ],
      "fallback": "Con người chọn việc và chuẩn bị ví dụ. Máy học từ ví dụ để gợi ý kết quả cho dữ liệu mới.",
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm dữ liệu con người chuẩn bị.",
        "Tìm lúc máy xử lí đầu vào mới."
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "type": "concept",
      "id": "02-08",
      "title": "Dữ liệu, thuật toán và mô hình",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và cách máy học",
        "purpose": "Giải thích đơn giản dữ liệu, thuật toán, mô hình và dự đoán.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán.",
        "assessment": "Đạt khi ghép đúng ít nhất 3/4 khái niệm và tách được hai quá trình. Dùng thẻ màu/vị trí để hỗ trợ các em còn nhầm.",
        "answers": [
          "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em có ảnh Bút/Cốc với tên vật đúng.\n2. Nói dễ hiểu: Ảnh là dữ liệu; máy học để tạo cách phân biệt.\n3. Điều cần nhớ: Ảnh mới → AI gợi tên → em kiểm vật thật.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Có mô hình rồi, em phân biệt tạo và dùng."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dữ liệu: ảnh ví dụ có nhãn.",
        "Thuật toán học: cách học từ ví dụ.",
        "Mô hình: kết quả của quá trình học."
      ],
      "phase": "Khám phá",
      "scene": "learn-use",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Dữ liệu: ảnh ví dụ có nhãn.",
        "Thuật toán học: cách học từ ví dụ.",
        "Mô hình: kết quả của quá trình học."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em có ảnh Bút/Cốc với tên vật đúng.",
          "tone": "key",
          "note": "Thầy/Cô: Em có ảnh Bút/Cốc với tên vật đúng."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh là dữ liệu; máy học để tạo cách phân biệt.",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh là dữ liệu; máy học để tạo cách phân biệt."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ảnh mới → AI gợi tên → em kiểm vật thật.",
          "tone": "action",
          "note": "Thầy/Cô: Ảnh mới → AI gợi tên → em kiểm vật thật."
        }
      ]
    },
    {
      "type": "dualprocess",
      "id": "02-09",
      "title": "Tạo AI · 1. Chọn việc cần giúp",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và cách máy học",
        "purpose": "Giải thích đơn giản dữ liệu, thuật toán, mô hình và dự đoán.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán.",
        "assessment": "Đạt khi ghép đúng ít nhất 3/4 khái niệm và tách được hai quá trình. Dùng thẻ màu/vị trí để hỗ trợ các em còn nhầm.",
        "answers": [
          "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Có mô hình rồi, em phân biệt tạo và dùng.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Phân loại vỏ lon và giấy vụn ở trường.\n2. Nói dễ hiểu: Con người chọn hai nhóm cần phân biệt.\n3. Điều cần nhớ: Con người quyết định việc AI sẽ hỗ trợ.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu là ví dụ. Thuật toán là cách học. Dạy AI tạo mô hình. Mô hình xử lí đầu vào mới để dự đoán.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “tạo ai · 2. chuẩn bị ảnh”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Phân loại vỏ lon và giấy vụn ở trường.",
        "Con người chọn hai nhóm cần phân biệt.",
        "Con người quyết định việc AI sẽ hỗ trợ."
      ],
      "phase": "Khám phá",
      "scene": "learn-use",
      "taskLines": [
        "Trong 30 giây, em lần theo hai sơ đồ trên slide."
      ],
      "connector": "Có mô hình rồi, em phân biệt tạo và dùng.",
      "number": 9,
      "realImage": "frame_2_20.jpg",
      "v7": true,
      "originalTeachingPoints": [
        "Phân loại vỏ lon và giấy vụn ở trường.",
        "Con người chọn hai nhóm cần phân biệt.",
        "Con người quyết định việc AI sẽ hỗ trợ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Phân loại vỏ lon và giấy vụn ở trường.",
          "tone": "key",
          "note": "Thầy/Cô: Phân loại vỏ lon và giấy vụn ở trường."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Con người chọn hai nhóm cần phân biệt.",
          "tone": "explain",
          "note": "Thầy/Cô: Con người chọn hai nhóm cần phân biệt."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Con người quyết định việc AI sẽ hỗ trợ.",
          "tone": "action",
          "note": "Thầy/Cô: Con người quyết định việc AI sẽ hỗ trợ."
        }
      ]
    },
    {
      "id": "02-v7-data",
      "type": "guide",
      "title": "Tạo AI · 2. Chuẩn bị ảnh",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Ai chụp ảnh vỏ lon và giấy vụn?",
        "Con người chụp ảnh, ghi tên đúng từng vật.",
        "Máy không tự có sẵn bộ ảnh phù hợp."
      ],
      "scene": "recycle",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người so với vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Ai chụp ảnh vỏ lon và giấy vụn? / Con người chụp ảnh, ghi tên đúng từng vật. / Máy không tự có sẵn bộ ảnh phù hợp."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Tạo AI · 2. Chuẩn bị ảnh.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ai chụp ảnh vỏ lon và giấy vụn?\n2. Nói dễ hiểu: Con người chụp ảnh, ghi tên đúng từng vật.\n3. Điều cần nhớ: Máy không tự có sẵn bộ ảnh phù hợp.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ai chụp ảnh vỏ lon và giấy vụn? / Con người chụp ảnh, ghi tên đúng từng vật. / Máy không tự có sẵn bộ ảnh phù hợp.",
          "closing": "Thầy/Cô chốt: Máy không tự có sẵn bộ ảnh phù hợp.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “tạo ai · 3. máy học từ ảnh”."
        }
      },
      "realImage": "frame_2_135.jpg",
      "number": 10,
      "originalTeachingPoints": [
        "Ai chụp ảnh vỏ lon và giấy vụn?",
        "Con người chụp ảnh, ghi tên đúng từng vật.",
        "Máy không tự có sẵn bộ ảnh phù hợp."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ai chụp ảnh vỏ lon và giấy vụn?",
          "tone": "key",
          "note": "Thầy/Cô: Ai chụp ảnh vỏ lon và giấy vụn?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Con người chụp ảnh, ghi tên đúng từng vật.",
          "tone": "explain",
          "note": "Thầy/Cô: Con người chụp ảnh, ghi tên đúng từng vật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Máy không tự có sẵn bộ ảnh phù hợp.",
          "tone": "action",
          "note": "Thầy/Cô: Máy không tự có sẵn bộ ảnh phù hợp."
        }
      ]
    },
    {
      "id": "02-v7-learn",
      "type": "guide",
      "title": "Tạo AI · 3. Máy học từ ảnh",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Máy xử lí những ảnh đã có tên.",
        "Máy tìm đặc điểm để phân biệt hai nhóm.",
        "Máy tính hỗ trợ học nhanh từ các ảnh."
      ],
      "scene": "recycle",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người so với vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Máy xử lí những ảnh đã có tên. / Máy tìm đặc điểm để phân biệt hai nhóm. / Máy tính hỗ trợ học nhanh từ các ảnh."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Tạo AI · 3. Máy học từ ảnh.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Máy xử lí những ảnh đã có tên.\n2. Nói dễ hiểu: Máy tìm đặc điểm để phân biệt hai nhóm.\n3. Điều cần nhớ: Máy tính hỗ trợ học nhanh từ các ảnh.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Máy xử lí những ảnh đã có tên. / Máy tìm đặc điểm để phân biệt hai nhóm. / Máy tính hỗ trợ học nhanh từ các ảnh.",
          "closing": "Thầy/Cô chốt: Máy tính hỗ trợ học nhanh từ các ảnh.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “tạo ai · 4. con người thử lại”."
        }
      },
      "realImage": "frame_2_135.jpg",
      "number": 11,
      "originalTeachingPoints": [
        "Máy xử lí những ảnh đã có tên.",
        "Máy tìm đặc điểm để phân biệt hai nhóm.",
        "Máy tính hỗ trợ học nhanh từ các ảnh."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Máy xử lí những ảnh đã có tên.",
          "tone": "key",
          "note": "Thầy/Cô: Máy xử lí những ảnh đã có tên."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Máy tìm đặc điểm để phân biệt hai nhóm.",
          "tone": "explain",
          "note": "Thầy/Cô: Máy tìm đặc điểm để phân biệt hai nhóm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Máy tính hỗ trợ học nhanh từ các ảnh.",
          "tone": "action",
          "note": "Thầy/Cô: Máy tính hỗ trợ học nhanh từ các ảnh."
        }
      ]
    },
    {
      "id": "02-v7-check",
      "type": "guide",
      "title": "Tạo AI · 4. Con người thử lại",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Đưa ảnh mới; đọc tên máy gợi ý.",
        "So tên đó với vỏ lon hoặc giấy thật.",
        "Con người quyết định có dùng kết quả không."
      ],
      "scene": "recycle",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người so với vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Đưa ảnh mới; đọc tên máy gợi ý. / So tên đó với vỏ lon hoặc giấy thật. / Con người quyết định có dùng kết quả không."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Tạo AI · 4. Con người thử lại.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đưa ảnh mới; đọc tên máy gợi ý.\n2. Nói dễ hiểu: So tên đó với vỏ lon hoặc giấy thật.\n3. Điều cần nhớ: Con người quyết định có dùng kết quả không.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Đưa ảnh mới; đọc tên máy gợi ý. / So tên đó với vỏ lon hoặc giấy thật. / Con người quyết định có dùng kết quả không.",
          "closing": "Thầy/Cô chốt: Con người quyết định có dùng kết quả không.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "realImage": "frame_5_20.jpg",
      "number": 12,
      "originalTeachingPoints": [
        "Đưa ảnh mới; đọc tên máy gợi ý.",
        "So tên đó với vỏ lon hoặc giấy thật.",
        "Con người quyết định có dùng kết quả không."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đưa ảnh mới; đọc tên máy gợi ý.",
          "tone": "key",
          "note": "Thầy/Cô: Đưa ảnh mới; đọc tên máy gợi ý."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So tên đó với vỏ lon hoặc giấy thật.",
          "tone": "explain",
          "note": "Thầy/Cô: So tên đó với vỏ lon hoặc giấy thật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Con người quyết định có dùng kết quả không.",
          "tone": "action",
          "note": "Thầy/Cô: Con người quyết định có dùng kết quả không."
        }
      ]
    },
    {
      "id": "02-10-mau",
      "type": "worked",
      "v6": true,
      "title": "Ghép thử một quá trình học",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "recycle",
      "worked": {
        "title": "Ghép thử một quá trình học",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Dữ liệu mẫu",
          "Cách máy học",
          "Kết quả học",
          "Dùng với ảnh mới",
          "Ai đối chiếu?"
        ],
        "values": [
          "Ảnh giấy và nhựa có tên đúng",
          "Máy tìm đặc điểm từ ảnh mẫu",
          "Một mô hình phân biệt giấy/nhựa",
          "AI đưa tên gợi ý",
          "Con người so với vật thật"
        ],
        "why": [
          "Con người ghi tên đúng cho ảnh.",
          "Ảnh mới chưa dùng để dạy AI.",
          "Tên gợi ý vẫn cần người kiểm."
        ],
        "question": "Ai cần đối chiếu tên gợi ý?",
        "scene": "Recycle"
      },
      "targetId": "02-10",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người so với vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Dữ liệu mẫu: Ảnh giấy và nhựa có tên đúng\nCách máy học: Máy tìm đặc điểm từ ảnh mẫu\nKết quả học: Một mô hình phân biệt giấy/nhựa\nDùng với ảnh mới: AI đưa tên gợi ý\nAi đối chiếu?: Con người so với vật thật"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dạy AI phân biệt ảnh giấy và nhựa.\n2. Nói dễ hiểu: Ảnh có tên đúng giúp máy học cách phân biệt.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Dữ liệu mẫu: Ảnh giấy và nhựa có tên đúng\nCách máy học: Máy tìm đặc điểm từ ảnh mẫu\nKết quả học: Một mô hình phân biệt giấy/nhựa\nDùng với ảnh mới: AI đưa tên gợi ý\nAi đối chiếu?: Con người so với vật thật",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dạy AI phân biệt ảnh giấy và nhựa.",
          "tone": "key",
          "note": "Thầy/Cô: Dạy AI phân biệt ảnh giấy và nhựa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh có tên đúng giúp máy học cách phân biệt.",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh có tên đúng giúp máy học cách phân biệt."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Ai cần đối chiếu tên gợi ý? Gợi ý: Con người so với vật thật"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P2.1 Dữ liệu và khái niệm",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Dữ liệu → c. Thuật toán học → d. Mô hình → a. Dự đoán → b.",
          "A1–A3 thuộc Cốc. A4–A6 thuộc Bút. A7–A8 để thử với ví dụ mới.",
          "Trò chơi quy tắc không chạy thuật toán học. Học máy thật dùng thuật toán và dữ liệu tạo mô hình."
        ],
        "pages": [
          {
            "title": "Ghép bốn khái niệm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn nghĩa của dữ liệu.",
                "options": [
                  "a",
                  "b",
                  "c",
                  "d"
                ],
                "key": "02-10-v3-0",
                "optionLabels": [
                  "A · Cách phân biệt sau khi máy học",
                  "B · Tên AI gợi cho ảnh mới",
                  "C · Ảnh ví dụ có tên vật đúng",
                  "D · Cách máy học đặc điểm từ ảnh"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghép bốn khái niệm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn nghĩa của thuật toán học.",
                "options": [
                  "a",
                  "b",
                  "c",
                  "d"
                ],
                "key": "02-10-v3-1",
                "optionLabels": [
                  "A · Cách phân biệt sau khi máy học",
                  "B · Tên AI gợi cho ảnh mới",
                  "C · Ảnh ví dụ có tên vật đúng",
                  "D · Cách máy học đặc điểm từ ảnh"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghép bốn khái niệm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn nghĩa của mô hình.",
                "options": [
                  "a",
                  "b",
                  "c",
                  "d"
                ],
                "key": "02-10-v3-2",
                "optionLabels": [
                  "A · Cách phân biệt sau khi máy học",
                  "B · Tên AI gợi cho ảnh mới",
                  "C · Ảnh ví dụ có tên vật đúng",
                  "D · Cách máy học đặc điểm từ ảnh"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ghép bốn khái niệm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn nghĩa của dự đoán.",
                "options": [
                  "a",
                  "b",
                  "c",
                  "d"
                ],
                "key": "02-10-v3-3",
                "optionLabels": [
                  "A · Cách phân biệt sau khi máy học",
                  "B · Tên AI gợi cho ảnh mới",
                  "C · Ảnh ví dụ có tên vật đúng",
                  "D · Cách máy học đặc điểm từ ảnh"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "A1: cốc trắng. A2: cốc màu. A3: cốc có quai. A4: bút bi. A5: bút chì. A6: bút dạ.",
            "originalPage": 1,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "A7: một cốc khác. A8: một bút khác.",
            "originalPage": 1,
            "referenceOnly": true
          },
          {
            "title": "Phân biệt ảnh dùng để học và ảnh dùng để thử",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Những thẻ thuộc nhóm Cốc là thẻ nào?",
                "key": "02-10-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Phân biệt ảnh dùng để học và ảnh dùng để thử",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Những thẻ thuộc nhóm Bút là thẻ nào?",
                "key": "02-10-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Phân biệt ảnh dùng để học và ảnh dùng để thử",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vì sao giữ riêng A7–A8 để thử?",
                "key": "02-10-v3-6"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4
        }
      },
      "time": 5,
      "id": "02-10",
      "title": "P2.1 — Ghép tên với đúng phần",
      "note": {
        "activity": "Khám phá 2.1 Dữ liệu và cách máy học",
        "purpose": "Hoàn thành ghép khái niệm với ví dụ theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu là ví dụ; thuật toán là cách học; huấn luyện tạo mô hình; mô hình xử lí đầu vào mới để dự đoán.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Dữ liệu → c. Thuật toán học → d. Mô hình → a. Dự đoán → b.",
          "A1–A3 thuộc Cốc. A4–A6 thuộc Bút. A7–A8 để thử với ví dụ mới.",
          "Trò chơi quy tắc không chạy thuật toán học. Học máy thật dùng thuật toán và dữ liệu tạo mô hình."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Ghép bốn khái niệm với a–d. Chọn ảnh dùng để học. Giữ ảnh mới để thử.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Dữ liệu → c. Thuật toán học → d. Mô hình → a. Dự đoán → b.\nA1–A3 thuộc Cốc. A4–A6 thuộc Bút. A7–A8 để thử với ví dụ mới.\nTrò chơi quy tắc không chạy thuật toán học. Học máy thật dùng thuật toán và dữ liệu tạo mô hình.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghép bốn khái niệm với a–d.",
        "Chọn ảnh dùng để học.",
        "Giữ ảnh mới để thử."
      ],
      "phase": "Khám phá",
      "scene": "learn-use",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "02-10-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [
        "Ghép bốn khái niệm với a–d.",
        "Chọn ảnh dùng để học.",
        "Giữ ảnh mới để thử."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P2.1 · Ghép đúng phần"
    },
    {
      "type": "divider",
      "id": "02-11",
      "title": "Thực hành: đóng bốn vai",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "02-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Bốn bước phân loại rác ở trường",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "recycle",
      "worked": {
        "title": "Bốn bước phân loại rác ở trường",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "1. Chọn việc",
          "2. Chuẩn bị ảnh",
          "3. Học từ ảnh",
          "4. Kiểm thử",
          "Nếu AI nhầm"
        ],
        "values": [
          "Con người chọn vỏ lon và giấy vụn",
          "Con người chụp ảnh, ghi tên đúng",
          "Máy tạo cách phân biệt hai nhóm",
          "Con người thử ảnh mới, so vật thật",
          "Con người sửa dữ liệu rồi thử lại"
        ],
        "why": [
          "Máy không tự chọn mục tiêu của lớp.",
          "Con người biết tên vật để gắn nhãn.",
          "Một lần đúng chưa đủ bảo đảm."
        ],
        "question": "Nếu AI nhầm, ai cần kiểm và sửa?",
        "scene": "Recycle"
      },
      "targetId": "02-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con người sửa dữ liệu rồi thử lại",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "1. Chọn việc: Con người chọn vỏ lon và giấy vụn\n2. Chuẩn bị ảnh: Con người chụp ảnh, ghi tên đúng\n3. Học từ ảnh: Máy tạo cách phân biệt hai nhóm\n4. Kiểm thử: Con người thử ảnh mới, so vật thật\nNếu AI nhầm: Con người sửa dữ liệu rồi thử lại"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dạy AI phân biệt vỏ lon và giấy vụn.\n2. Nói dễ hiểu: Con người chọn việc, chuẩn bị ảnh và kiểm tên.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "1. Chọn việc: Con người chọn vỏ lon và giấy vụn\n2. Chuẩn bị ảnh: Con người chụp ảnh, ghi tên đúng\n3. Học từ ảnh: Máy tạo cách phân biệt hai nhóm\n4. Kiểm thử: Con người thử ảnh mới, so vật thật\nNếu AI nhầm: Con người sửa dữ liệu rồi thử lại",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dạy AI phân biệt vỏ lon và giấy vụn.",
          "tone": "key",
          "note": "Thầy/Cô: Dạy AI phân biệt vỏ lon và giấy vụn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Con người chọn việc, chuẩn bị ảnh và kiểm tên.",
          "tone": "explain",
          "note": "Thầy/Cô: Con người chọn việc, chuẩn bị ảnh và kiểm tên."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Nếu AI nhầm, ai cần kiểm và sửa? Gợi ý: Con người sửa dữ liệu rồi thử lại"
        }
      ]
    },
    {
      "type": "task",
      "id": "02-12",
      "title": "Bốn vai trong trò chơi quy tắc",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chọn nhiệm vụ.\n2. Nói dễ hiểu: Chuẩn bị thẻ.\n3. Điều cần nhớ: Đóng vai hệ thống và kiểm tra.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.\nTheo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.\nHọc máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước hết, em chọn rõ đồ vật cần phân biệt."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn nhiệm vụ.",
        "Chuẩn bị thẻ.",
        "Đóng vai hệ thống và kiểm tra."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 11 phút, em thử quy tắc với thẻ tại bàn."
      ],
      "sampleId": "02-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn nhiệm vụ.",
        "Chuẩn bị thẻ.",
        "Đóng vai hệ thống và kiểm tra."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chọn nhiệm vụ.",
          "tone": "key",
          "note": "Thầy/Cô: Chọn nhiệm vụ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chuẩn bị thẻ.",
          "tone": "explain",
          "note": "Thầy/Cô: Chuẩn bị thẻ."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đóng vai hệ thống và kiểm tra.",
          "tone": "action",
          "note": "Thầy/Cô: Đóng vai hệ thống và kiểm tra."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 0,
      "id": "02-13",
      "title": "Bước 1 — Chọn đúng nhiệm vụ",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước hết, em chọn rõ đồ vật cần phân biệt.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Phân biệt Bút và Cốc.\n2. Nói dễ hiểu: Người kiểm tra biết tên vật thật.\n3. Điều cần nhớ: Trò chơi dùng quy tắc; AI thật học từ ảnh.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.\nTheo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.\nHọc máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Có nhiệm vụ rồi, em chuẩn bị ví dụ đúng tên."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Phân biệt Bút và Cốc.",
        "Người kiểm tra biết tên vật thật."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 1 phút, em làm bước này với thẻ tại bàn."
      ],
      "connector": "Trước hết, em chọn rõ đồ vật cần phân biệt.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Phân biệt Bút và Cốc.",
        "Người kiểm tra biết tên vật thật.",
        "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Phân biệt Bút và Cốc.",
          "tone": "key",
          "note": "Thầy/Cô: Phân biệt Bút và Cốc."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Người kiểm tra biết tên vật thật.",
          "tone": "explain",
          "note": "Thầy/Cô: Người kiểm tra biết tên vật thật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Trò chơi dùng quy tắc; AI thật học từ ảnh.",
          "tone": "action",
          "note": "Thầy/Cô: Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần."
        }
      ]
    },
    {
      "type": "step",
      "step": 2,
      "time": 0,
      "id": "02-14",
      "title": "Bước 2 — Chuẩn bị thẻ",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Có nhiệm vụ rồi, em chuẩn bị ví dụ đúng tên.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: A1–A6: ví dụ có nhãn.\n2. Nói dễ hiểu: A7–A8: giữ lại để thử.\n3. Điều cần nhớ: Đây là thẻ chữ mô phỏng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.\nTheo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.\nHọc máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Ví dụ đã sẵn sàng. Em đọc quy tắc trước khi thử."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "A1–A6: ví dụ có nhãn.",
        "A7–A8: giữ lại để thử.",
        "Đây là thẻ chữ mô phỏng."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "pencil-ruler",
      "taskLines": [
        "Trong 1 phút, em làm bước này với thẻ tại bàn."
      ],
      "connector": "Có nhiệm vụ rồi, em chuẩn bị ví dụ đúng tên.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "A1–A6: ví dụ có nhãn.",
        "A7–A8: giữ lại để thử.",
        "Đây là thẻ chữ mô phỏng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "A1–A6: ví dụ có nhãn.",
          "tone": "key",
          "note": "Thầy/Cô: A1–A6: ví dụ có nhãn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "A7–A8: giữ lại để thử.",
          "tone": "explain",
          "note": "Thầy/Cô: A7–A8: giữ lại để thử."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đây là thẻ chữ mô phỏng.",
          "tone": "action",
          "note": "Thầy/Cô: Đây là thẻ chữ mô phỏng."
        }
      ]
    },
    {
      "type": "step",
      "step": 3,
      "time": 0,
      "id": "02-15",
      "title": "Bước 3 — Làm theo quy tắc",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Ví dụ đã sẵn sàng. Em đọc quy tắc trước khi thử.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Có ngòi bút → Bút.\n2. Nói dễ hiểu: Có thân chứa và miệng cốc → Cốc.\n3. Điều cần nhớ: Không khớp → Chưa xác định.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.\nTheo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.\nHọc máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Quy tắc đã rõ. Em thử vật ngoài hai nhóm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Có ngòi bút → Bút.",
        "Có thân chứa và miệng cốc → Cốc.",
        "Không khớp → Chưa xác định."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "spoon",
      "taskLines": [
        "Trong 1 phút, em làm bước này với thẻ tại bàn."
      ],
      "connector": "Ví dụ đã sẵn sàng. Em đọc quy tắc trước khi thử.",
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [
        "Có ngòi bút → Bút.",
        "Có thân chứa và miệng cốc → Cốc.",
        "Không khớp → Chưa xác định."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Có ngòi bút → Bút.",
          "tone": "key",
          "note": "Thầy/Cô: Có ngòi bút → Bút."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Có thân chứa và miệng cốc → Cốc.",
          "tone": "explain",
          "note": "Thầy/Cô: Có thân chứa và miệng cốc → Cốc."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không khớp → Chưa xác định.",
          "tone": "action",
          "note": "Thầy/Cô: Không khớp → Chưa xác định."
        }
      ]
    },
    {
      "type": "step",
      "step": 4,
      "time": 0,
      "id": "02-16",
      "title": "Bước 4 — Thử chiếc thìa",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Quy tắc đã rõ. Em thử vật ngoài hai nhóm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Thìa có khớp quy tắc không?\n2. Nói dễ hiểu: So kết quả với vật thật.\n3. Điều cần nhớ: Không đổi tên vật theo dự đoán.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.\nTheo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.\nHọc máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Thìa có khớp quy tắc không?",
        "So kết quả với vật thật.",
        "Không đổi tên vật theo dự đoán."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "spoon",
      "taskLines": [
        "Trong 1 phút, em làm bước này với thẻ tại bàn."
      ],
      "connector": "Quy tắc đã rõ. Em thử vật ngoài hai nhóm.",
      "number": 21,
      "v7": true,
      "originalTeachingPoints": [
        "Thìa có khớp quy tắc không?",
        "So kết quả với vật thật.",
        "Không đổi tên vật theo dự đoán."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Thìa có khớp quy tắc không?",
          "tone": "key",
          "note": "Thầy/Cô: Thìa có khớp quy tắc không?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So kết quả với vật thật.",
          "tone": "explain",
          "note": "Thầy/Cô: So kết quả với vật thật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không đổi tên vật theo dự đoán.",
          "tone": "action",
          "note": "Thầy/Cô: Không đổi tên vật theo dự đoán."
        }
      ]
    },
    {
      "id": "02-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Điền mẫu: ai làm việc gì?",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "roles",
      "worked": {
        "title": "Điền mẫu: ai làm việc gì?",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Chọn hai nhóm",
          "Chụp, ghi tên",
          "Học từ ảnh",
          "Kiểm ảnh mới",
          "Ai quyết định?"
        ],
        "values": [
          "Con người: chọn việc cần giúp",
          "Con người: biết vật thật là gì",
          "Máy tính: xử lí các ảnh đã gắn tên",
          "Con người: so tên gợi ý với vật thật",
          "Con người quyết định dùng hay sửa"
        ],
        "why": [
          "Chọn việc giúp cả lớp hiểu mục đích.",
          "Trò chơi dùng quy tắc, chưa học từ ảnh.",
          "Người kiểm biết tên vật thật."
        ],
        "question": "Ai quyết định dùng hay sửa kết quả?",
        "scene": "Roles"
      },
      "targetId": "02-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Em D so kết quả với vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Chọn hai nhóm: Con người: chọn việc cần giúp\nChụp, ghi tên: Con người: biết vật thật là gì\nHọc từ ảnh: Máy tính: xử lí các ảnh đã gắn tên\nKiểm ảnh mới: Con người: so tên gợi ý với vật thật\nAi quyết định?: Con người quyết định dùng hay sửa"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ai chọn, chụp ảnh, học và kiểm?\n2. Nói dễ hiểu: Máy học từ ảnh; con người chọn và kiểm.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Chọn hai nhóm: Con người: chọn việc cần giúp\nChụp, ghi tên: Con người: biết vật thật là gì\nHọc từ ảnh: Máy tính: xử lí các ảnh đã gắn tên\nKiểm ảnh mới: Con người: so tên gợi ý với vật thật\nAi quyết định?: Con người quyết định dùng hay sửa",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ai chọn, chụp ảnh, học và kiểm?",
          "tone": "key",
          "note": "Thầy/Cô: Ai chọn, chụp ảnh, học và kiểm?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Máy học từ ảnh; con người chọn và kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: Máy học từ ảnh; con người chọn và kiểm."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Ai quyết định dùng hay sửa kết quả? Gợi ý: Con người quyết định dùng hay sửa"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P2.2 Hai sơ đồ và phân vai",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "pages": [
          {
            "title": "Phân bốn vai",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vai",
              "Việc cần làm",
              "Em đề xuất ai?"
            ],
            "rows": [
              [
                "Chọn nhiệm vụ",
                "Chỉ phân biệt Bút và Cốc.",
                {
                  "label": "Người chọn nhiệm vụ",
                  "key": "02-17-v3-0"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Phân bốn vai",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vai",
              "Việc cần làm",
              "Em đề xuất ai?"
            ],
            "rows": [
              [
                "Chuẩn bị ví dụ",
                "Gắn tên đúng cho thẻ.",
                {
                  "label": "Người chuẩn bị ví dụ",
                  "key": "02-17-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Phân bốn vai",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vai",
              "Việc cần làm",
              "Em đề xuất ai?"
            ],
            "rows": [
              [
                "Đóng vai hệ thống",
                "Làm theo quy tắc đã cho.",
                {
                  "label": "Người đóng vai hệ thống",
                  "key": "02-17-v3-2"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Phân bốn vai",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vai",
              "Việc cần làm",
              "Em đề xuất ai?"
            ],
            "rows": [
              [
                "Kiểm tra",
                "So kết quả với vật thật.",
                {
                  "label": "Người kiểm tra",
                  "key": "02-17-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Vẽ hai sơ đồ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Quá trình tạo mô hình",
                "key": "02-17-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Vẽ hai sơ đồ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Quá trình dùng mô hình",
                "key": "02-17-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Quy tắc trò chơi: bút có ngòi → Bút. Cốc có thân chứa và miệng → Cốc.",
            "originalPage": 2,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Vật khác → Chưa xác định.",
            "originalPage": 2,
            "referenceOnly": true
          },
          {
            "title": "Thử quy tắc với ba đồ vật",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vật được đưa vào",
              "Kết quả theo quy tắc",
              "Người kiểm tra nhận xét"
            ],
            "rows": [
              [
                "A7: cốc mới",
                {
                  "label": "Kết quả với A7",
                  "key": "02-17-v3-6"
                },
                {
                  "label": "Nhận xét với A7",
                  "key": "02-17-v3-7"
                }
              ]
            ],
            "originalPage": 2
          },
          {
            "title": "Thử quy tắc với ba đồ vật",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vật được đưa vào",
              "Kết quả theo quy tắc",
              "Người kiểm tra nhận xét"
            ],
            "rows": [
              [
                "A8: bút mới",
                {
                  "label": "Kết quả với A8",
                  "key": "02-17-v3-8"
                },
                {
                  "label": "Nhận xét với A8",
                  "key": "02-17-v3-9"
                }
              ]
            ],
            "originalPage": 2
          },
          {
            "title": "Thử quy tắc với ba đồ vật",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Vật được đưa vào",
              "Kết quả theo quy tắc",
              "Người kiểm tra nhận xét"
            ],
            "rows": [
              [
                "Chiếc thìa",
                {
                  "label": "Kết quả với thìa",
                  "key": "02-17-v3-10"
                },
                {
                  "label": "Nhận xét với thìa",
                  "key": "02-17-v3-11"
                }
              ]
            ],
            "originalPage": 2
          },
          {
            "title": "Nêu điểm khác với học máy",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai đã viết quy tắc cho trò chơi này?",
                "key": "02-17-v3-12"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Nêu điểm khác với học máy",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Máy học tạo mô hình từ đâu?",
                "key": "02-17-v3-13"
              }
            ],
            "originalPage": 3
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4,
          "2": 6,
          "3": 11
        }
      },
      "time": 16,
      "id": "02-17",
      "title": "P2.2 — Ghi vai, thử và so sánh",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Hoàn thành hai sơ đồ và phân vai theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Ghi bốn vai. Vẽ hai sơ đồ. Thử ba vật và nêu điểm khác học máy.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.\nTheo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.\nHọc máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi bốn vai.",
        "Vẽ hai sơ đồ.",
        "Thử ba vật và nêu điểm khác học máy."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "02-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi bốn vai.",
        "Vẽ hai sơ đồ.",
        "Thử ba vật và nêu điểm khác học máy."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P2.2 · Ghi vai và thử"
    },
    {
      "type": "report",
      "id": "02-18",
      "title": "Ai chịu trách nhiệm kiểm tra?",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [
          "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.",
          "Theo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.",
          "Học máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em làm theo quy tắc nào?\n2. Nói dễ hiểu: Kết quả có phù hợp không?\n3. Điều cần nhớ: Ai đã đối chiếu?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tạo mô hình: Chuẩn bị dữ liệu → dạy AI → Kiểm thử. Dùng mô hình: Ảnh mới → Mô hình xử lí → Dự đoán → Con người kiểm tra.\nTheo quy tắc của trò chơi: A7 là Cốc. A8 là Bút. Thìa không thuộc hai mô tả nên Chưa xác định. Đây là người làm theo quy tắc viết sẵn, không phải máy học từ dữ liệu.\nHọc máy thật dùng thuật toán và dữ liệu để tạo mô hình. Con người không viết sẵn từng đáp án cho từng ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Em làm theo quy tắc nào?",
        "Kết quả có phù hợp không?",
        "Ai đã đối chiếu?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [
        "Em làm theo quy tắc nào?",
        "Kết quả có phù hợp không?",
        "Ai đã đối chiếu?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em làm theo quy tắc nào?",
          "tone": "key",
          "note": "Thầy/Cô: Em làm theo quy tắc nào?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Kết quả có phù hợp không?",
          "tone": "explain",
          "note": "Thầy/Cô: Kết quả có phù hợp không?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ai đã đối chiếu?",
          "tone": "action",
          "note": "Thầy/Cô: Ai đã đối chiếu?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "02-20",
      "title": "Luyện tập: tạo hay dùng mô hình?",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Phân biệt huấn luyện và dự đoán.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Huấn luyện và sử dụng mô hình có quan hệ nhưng là hai giai đoạn khác nhau.",
        "assessment": "Đạt khi đúng ít nhất 3/4 việc và không giao trách nhiệm cuối cùng cho AI.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "02-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu xếp một việc đúng chỗ",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "recycle",
      "worked": {
        "title": "Mẫu xếp một việc đúng chỗ",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Việc đang xét",
          "Thời điểm",
          "Thuộc quá trình",
          "Người làm",
          "Căn cứ"
        ],
        "values": [
          "Thêm ảnh giấy vào bộ mẫu",
          "Trước khi máy học",
          "Tạo mô hình",
          "Con người chuẩn bị ảnh",
          "Chưa dùng AI đoán một ảnh mới"
        ],
        "why": [
          "Xét việc làm, không chỉ nhìn tên ảnh.",
          "Thêm ảnh khác với thử ảnh.",
          "Em nói rõ trước hay sau học."
        ],
        "question": "Vì sao việc này thuộc tạo mô hình?",
        "scene": "Recycle"
      },
      "targetId": "02-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chưa dùng AI đoán một ảnh mới",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Việc đang xét: Thêm ảnh giấy vào bộ mẫu\nThời điểm: Trước khi máy học\nThuộc quá trình: Tạo mô hình\nNgười làm: Con người chuẩn bị ảnh\nCăn cứ: Chưa dùng AI đoán một ảnh mới"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Con người thêm ảnh giấy trước khi máy học.\n2. Nói dễ hiểu: Thêm ảnh là chuẩn bị trước khi dùng AI.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Việc đang xét: Thêm ảnh giấy vào bộ mẫu\nThời điểm: Trước khi máy học\nThuộc quá trình: Tạo mô hình\nNgười làm: Con người chuẩn bị ảnh\nCăn cứ: Chưa dùng AI đoán một ảnh mới",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Con người thêm ảnh giấy trước khi máy học.",
          "tone": "key",
          "note": "Thầy/Cô: Con người thêm ảnh giấy trước khi máy học."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thêm ảnh là chuẩn bị trước khi dùng AI.",
          "tone": "explain",
          "note": "Thầy/Cô: Thêm ảnh là chuẩn bị trước khi dùng AI."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Vì sao việc này thuộc tạo mô hình? Gợi ý: Chưa dùng AI đoán một ảnh mới"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P2.3 Củng cố và quyết định",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "1: Chuẩn bị dữ liệu. 2: dạy AI. 3: Sử dụng mô hình. 4: Kiểm tra kết quả.",
          "AI được con người xây dựng. Người dùng vẫn cần kiểm tra và chịu trách nhiệm với cách sử dụng kết quả."
        ],
        "pages": [
          {
            "title": "Tạo mô hình hay dùng mô hình?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Gắn nhãn cho ảnh mẫu",
                "options": [
                  "Chuẩn bị dữ liệu",
                  "Sử dụng mô hình"
                ],
                "key": "02-21-v3-0",
                "optionLabels": [
                  "Chuẩn bị dữ liệu",
                  "Sử dụng mô hình"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Tạo mô hình hay dùng mô hình?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Cho công cụ học từ ảnh mẫu",
                "options": [
                  "Huấn luyện",
                  "Sử dụng mô hình"
                ],
                "key": "02-21-v3-1",
                "optionLabels": [
                  "Dạy AI",
                  "Sử dụng mô hình"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Tạo mô hình hay dùng mô hình?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Đưa một ảnh cốc mới vào mô hình",
                "options": [
                  "Chuẩn bị dữ liệu",
                  "Sử dụng mô hình"
                ],
                "key": "02-21-v3-2",
                "optionLabels": [
                  "Chuẩn bị dữ liệu",
                  "Sử dụng mô hình"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Tạo mô hình hay dùng mô hình?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "So kết quả với đồ vật thật",
                "options": [
                  "Huấn luyện",
                  "Kiểm tra kết quả"
                ],
                "key": "02-21-v3-3",
                "optionLabels": [
                  "Dạy AI",
                  "Kiểm tra kết quả"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ai có trách nhiệm?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“AI tự xuất hiện, không cần con người tạo ra.”",
                "key": "02-21-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Ai có trách nhiệm?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“AI trả lời rồi thì người dùng không cần kiểm tra.”",
                "key": "02-21-v3-5"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4
        }
      },
      "time": 4,
      "id": "02-21",
      "title": "P2.3A — Đang tạo hay đang dùng?",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành huấn luyện hay sử dụng? theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Huấn luyện và sử dụng mô hình có quan hệ nhưng là hai giai đoạn khác nhau.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1: Chuẩn bị dữ liệu. 2: dạy AI. 3: Sử dụng mô hình. 4: Kiểm tra kết quả.",
          "AI được con người xây dựng. Người dùng vẫn cần kiểm tra và chịu trách nhiệm với cách sử dụng kết quả."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Xếp việc vào hai quá trình. Sửa câu nói thiếu trách nhiệm kiểm tra.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1: Chuẩn bị dữ liệu. 2: dạy AI. 3: Sử dụng mô hình. 4: Kiểm tra kết quả.\nAI được con người xây dựng. Người dùng vẫn cần kiểm tra và chịu trách nhiệm với cách sử dụng kết quả.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Xếp việc vào hai quá trình.",
        "Sửa câu nói thiếu trách nhiệm kiểm tra."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "02-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [
        "Xếp việc vào hai quá trình.",
        "Sửa câu nói thiếu trách nhiệm kiểm tra."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P2.3A · Em tự làm"
    },
    {
      "type": "recap",
      "id": "02-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Mô phỏng vai trò con người",
        "purpose": "Mô tả được đầu vào–xử lí–đầu ra và vai trò kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu; trong mô phỏng này ta dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
        "assessment": "Thu sơ đồ và hỏi một em bất kì nêu phần việc của con người. Chưa suy ra các em đã dạy mô hình AI thật.",
        "answers": [
          "Ở mô hình thật, công cụ thực hiện học từ dữ liệu. Trong mô phỏng này em dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Con người chọn việc, chuẩn bị và kiểm tra.\n2. Nói dễ hiểu: Học từ dữ liệu tạo ra mô hình.\n3. Điều cần nhớ: Trò chơi quy tắc chưa phải AI học từ ảnh.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ở mô hình thật, công cụ thực hiện học từ dữ liệu. Trong mô phỏng này em dùng quy tắc viết sẵn để nhìn rõ vai trò từng phần.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Con người chọn việc, chuẩn bị và kiểm tra.",
        "Học từ dữ liệu tạo ra mô hình.",
        "Trò chơi quy tắc chưa phải AI học từ ảnh."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "learn-use",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [
        "Con người chọn việc, chuẩn bị và kiểm tra.",
        "Học từ dữ liệu tạo ra mô hình.",
        "Trò chơi quy tắc chưa phải AI học từ ảnh."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Con người chọn việc, chuẩn bị và kiểm tra.",
          "tone": "key",
          "note": "Thầy/Cô: Con người chọn việc, chuẩn bị và kiểm tra."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Học từ dữ liệu tạo ra mô hình.",
          "tone": "explain",
          "note": "Thầy/Cô: Học từ dữ liệu tạo ra mô hình."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Trò chơi quy tắc chưa phải AI học từ ảnh.",
          "tone": "action",
          "note": "Thầy/Cô: Trò chơi quy tắc chưa phải AI học từ ảnh."
        }
      ]
    },
    {
      "type": "divider",
      "id": "02-22",
      "title": "Vận dụng: khi dự đoán chưa phù hợp",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Giải thích con người quyết định trong một tình huống.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không giao quyết định cuối cùng cho nhãn dự đoán; người dùng phải xét phạm vi và bằng chứng.",
        "assessment": "Đối chiếu mục tiêu 6.A1.2. Các em cần có hành động cụ thể, không chỉ nói dùng AI cẩn thận.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "learn-use",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "02-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu xử lí vật ngoài hai nhóm",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "recycle",
      "worked": {
        "title": "Mẫu xử lí vật ngoài hai nhóm",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Vật mới",
          "Tên AI gợi ý",
          "Tên vật thật",
          "Nhận xét",
          "Việc tiếp theo"
        ],
        "values": [
          "Một chiếc lá",
          "Giấy",
          "Lá cây",
          "Tên gợi ý không khớp vật thật",
          "Chưa dùng nhãn đó, hỏi cách thử thêm"
        ],
        "why": [
          "Đây là kết quả minh họa.",
          "Không đổi tên vật theo AI.",
          "Em cần người kiểm tên thật."
        ],
        "question": "Em có dùng ngay nhãn Giấy không?",
        "scene": "Recycle"
      },
      "targetId": "02-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chưa dùng nhãn đó, hỏi cách thử thêm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Vật mới: Một chiếc lá\nTên AI gợi ý: Giấy\nTên vật thật: Lá cây\nNhận xét: Tên gợi ý không khớp vật thật\nViệc tiếp theo: Chưa dùng nhãn đó, hỏi cách thử thêm"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI chỉ biết giấy/nhựa, nhưng ảnh là lá cây.\n2. Nói dễ hiểu: Vật ngoài hai nhóm có thể vẫn bị gán tên sai.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Vật mới: Một chiếc lá\nTên AI gợi ý: Giấy\nTên vật thật: Lá cây\nNhận xét: Tên gợi ý không khớp vật thật\nViệc tiếp theo: Chưa dùng nhãn đó, hỏi cách thử thêm",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 30,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI chỉ biết giấy/nhựa, nhưng ảnh là lá cây.",
          "tone": "key",
          "note": "Thầy/Cô: AI chỉ biết giấy/nhựa, nhưng ảnh là lá cây."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Vật ngoài hai nhóm có thể vẫn bị gán tên sai.",
          "tone": "explain",
          "note": "Thầy/Cô: Vật ngoài hai nhóm có thể vẫn bị gán tên sai."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em có dùng ngay nhãn Giấy không? Gợi ý: Chưa dùng nhãn đó, hỏi cách thử thêm"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P2.3 Củng cố và quyết định",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "B Đối chiếu vật thật, không dùng nhãn sai. Báo phạm vi thiếu nhãn, đề xuất điều chỉnh thiết kế/dữ liệu nếu nhiệm vụ cần nhận thìa."
        ],
        "pages": [
          {
            "title": "Khi mô hình gọi thìa là bút",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em kiểm tra kết quả bằng gì?",
                "key": "02-23-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Khi mô hình gọi thìa là bút",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em có dùng nhãn Bút cho chiếc thìa không? Vì sao?",
                "key": "02-23-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Khi mô hình gọi thìa là bút",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Muốn nhận cả thìa, cần xem lại điều gì trong nhiệm vụ và dữ liệu?",
                "key": "02-23-v3-2"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 3,
      "id": "02-23",
      "title": "P2.3B — Thìa bị gọi là bút",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Hoàn thành xử lí nhãn chưa phù hợp theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không giao quyết định cuối cùng cho nhãn dự đoán; người dùng phải xét phạm vi và bằng chứng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "B Đối chiếu vật thật, không dùng nhãn sai. Báo phạm vi thiếu nhãn, đề xuất điều chỉnh thiết kế/dữ liệu nếu nhiệm vụ cần nhận thìa."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Mô hình chỉ có hai nhãn: Bút/Cốc. Vật thật là chiếc thìa. Em sẽ nói và làm gì?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "B Đối chiếu vật thật, không dùng nhãn sai. Báo phạm vi thiếu nhãn, đề xuất điều chỉnh thiết kế/dữ liệu nếu nhiệm vụ cần nhận thìa.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mô hình chỉ có hai nhãn: Bút/Cốc.",
        "Vật thật là chiếc thìa.",
        "Em sẽ nói và làm gì?"
      ],
      "phase": "Vận dụng",
      "scene": "learn-use",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "02-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 31,
      "v7": true,
      "originalTeachingPoints": [
        "Mô hình chỉ có hai nhãn: Bút/Cốc.",
        "Vật thật là chiếc thìa.",
        "Em sẽ nói và làm gì?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P2.3B · Em tự làm"
    },
    {
      "type": "home",
      "id": "02-24",
      "title": "Chuẩn bị để dạy AI thật",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Giải thích con người quyết định trong một tình huống.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không giao quyết định cuối cùng cho nhãn dự đoán; người dùng phải xét phạm vi và bằng chứng.",
        "assessment": "Đối chiếu mục tiêu 6.A1.2. Các em cần có hành động cụ thể, không chỉ nói dùng AI cẩn thận.",
        "answers": [
          "Không giao quyết định cuối cùng cho nhãn dự đoán. Người dùng phải xét phạm vi và bằng chứng."
        ],
        "source": "Bài 1 Giới thiệu AI; Bài 2 Dạy máy học, mục Quy trình học máy hoạt động, trang in 11. Sơ đồ mô phỏng trong bài dạy do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mang bút và cốc an toàn.\n2. Nói dễ hiểu: Vẽ lại hai sơ đồ.\n3. Điều cần nhớ: Không cần mua đồ mới.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Không giao quyết định cuối cùng cho nhãn dự đoán. Người dùng phải xét phạm vi và bằng chứng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mang bút và cốc an toàn.",
        "Vẽ lại hai sơ đồ.",
        "Không cần mua đồ mới."
      ],
      "phase": "Vận dụng",
      "scene": "spoon",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 32,
      "v7": true,
      "originalTeachingPoints": [
        "Mang bút và cốc an toàn.",
        "Vẽ lại hai sơ đồ.",
        "Không cần mua đồ mới."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mang bút và cốc an toàn.",
          "tone": "key",
          "note": "Thầy/Cô: Mang bút và cốc an toàn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Vẽ lại hai sơ đồ.",
          "tone": "explain",
          "note": "Thầy/Cô: Vẽ lại hai sơ đồ."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không cần mua đồ mới.",
          "tone": "action",
          "note": "Thầy/Cô: Không cần mua đồ mới."
        }
      ]
    }
  ],
  "rubric": [],
  "evidence": [
    [
      "Hai sơ đồ",
      "6.1.TC1a",
      "Mô tả đầu vào, xử lí và kết quả qua ví dụ.",
      "P2.2 và lời giải thích cá nhân",
      "Phân biệt được quá trình huấn luyện và sử dụng."
    ],
    [
      "Ghép khái niệm",
      "6.1.TC1b",
      "Diễn giải dữ liệu, huấn luyện, mô hình, kết quả.",
      "P2.1, P2.3A",
      "Đúng ít nhất 3/4 khái niệm, có ví dụ; bổ sung khái niệm còn thiếu."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
