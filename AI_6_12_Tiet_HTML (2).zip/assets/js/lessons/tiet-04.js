window.AI6_LESSON={
  "id": 4,
  "title": "Bài 4. Kiểm thử và cải tiến mô hình AI",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 32,
  "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do GV thiết kế.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 3,
    "title": "AI: Training Data & Bias",
    "start": 120,
    "end": 150,
    "poster": "frame_3_135.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/RDlu9sZfdQPEojHL9IgOc/2d98d959793bf7358272ab0d95a5b8ae/ai-03-training-data.mp4",
    "question": "Nếu ảnh học đều cùng góc và ánh sáng, cần bổ sung điều kiện nào để kiểm tra với ảnh mới?",
    "local": "code-3.mp4"
  },
  "outcome": "Bảng so sáu ảnh trước và sau khi dạy thêm.",
  "slides": [
    {
      "type": "cover",
      "id": "04-01",
      "title": "Bài 4. Kiểm thử và cải tiến mô hình AI",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra cần bằng chứng mới khi đánh giá mô hình.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới.",
        "assessment": "Nếu các em chỉ đề nghị xem phần trăm cao, yêu cầu nêu phép đối chiếu đúng/sai.",
        "answers": [
          "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "test",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "04-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra cần bằng chứng mới khi đánh giá mô hình.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới.",
        "assessment": "Nếu các em chỉ đề nghị xem phần trăm cao, yêu cầu nêu phép đối chiếu đúng/sai.",
        "answers": [
          "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Giữ riêng sáu ảnh để kiểm thử.\n2. Nói dễ hiểu: So kết quả trước và sau cải tiến.\n3. Điều cần nhớ: Nêu giới hạn của kết luận.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Giữ riêng sáu ảnh để kiểm thử.",
        "So kết quả trước và sau cải tiến.",
        "Nêu giới hạn của kết luận."
      ],
      "phase": "Khởi động",
      "scene": "test",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Giữ riêng sáu ảnh để kiểm thử.",
        "So kết quả trước và sau cải tiến.",
        "Nêu giới hạn của kết luận."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Giữ riêng sáu ảnh để kiểm thử.",
          "tone": "key",
          "note": "Thầy/Cô: Giữ riêng sáu ảnh để kiểm thử."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So kết quả trước và sau cải tiến.",
          "tone": "explain",
          "note": "Thầy/Cô: So kết quả trước và sau cải tiến."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nêu giới hạn của kết luận.",
          "tone": "action",
          "note": "Thầy/Cô: Nêu giới hạn của kết luận."
        }
      ]
    },
    {
      "type": "divider",
      "id": "04-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra cần bằng chứng mới khi đánh giá mô hình.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới.",
        "assessment": "Nếu các em chỉ đề nghị xem phần trăm cao, yêu cầu nêu phép đối chiếu đúng/sai.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "test",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "04-04",
      "title": "Đúng ảnh quen, đã đủ chưa?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra cần bằng chứng mới khi đánh giá mô hình.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới.",
        "assessment": "Nếu các em chỉ đề nghị xem phần trăm cao, yêu cầu nêu phép đối chiếu đúng/sai.",
        "answers": [
          "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mô hình nhận đúng ảnh đã thấy.\n2. Nói dễ hiểu: Điều đó chứng minh được gì?\n3. Điều cần nhớ: Cần thử thêm ảnh nào?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Kết quả trên ảnh quen chưa cho biết khả năng với đầu vào mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mô hình nhận đúng ảnh đã thấy.",
        "Điều đó chứng minh được gì?",
        "Cần thử thêm ảnh nào?"
      ],
      "phase": "Khởi động",
      "scene": "test",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Mô hình nhận đúng ảnh đã thấy.",
        "Điều đó chứng minh được gì?",
        "Cần thử thêm ảnh nào?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mô hình nhận đúng ảnh đã thấy.",
          "tone": "key",
          "note": "Thầy/Cô: Mô hình nhận đúng ảnh đã thấy."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Điều đó chứng minh được gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Điều đó chứng minh được gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Cần thử thêm ảnh nào?",
          "tone": "action",
          "note": "Thầy/Cô: Cần thử thêm ảnh nào?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "04-05",
      "title": "Khám phá: giữ riêng ảnh thử",
      "note": {
        "activity": "Khám phá 2.1 Lập và thực hiện bộ kiểm thử",
        "purpose": "Thu được kết quả sáu trường hợp chưa dùng huấn luyện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá dựa trên nhãn thực và đầu ra quan sát; không chỉ dựa vào độ tự tin.",
        "assessment": "Đạt khi đủ sáu dòng và đối chiếu đúng. Không yêu cầu phải có lỗi mới đạt.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "test",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_3_135.jpg",
      "id": "04-06",
      "title": "Bộ ảnh có thể đang thiếu gì?",
      "note": {
        "activity": "Khám phá 2.1 Lập và thực hiện bộ kiểm thử",
        "purpose": "Thu được kết quả sáu trường hợp chưa dùng huấn luyện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá dựa trên nhãn thực và đầu ra quan sát; không chỉ dựa vào độ tự tin.",
        "assessment": "Đạt khi đủ sáu dòng và đối chiếu đúng. Không yêu cầu phải có lỗi mới đạt.",
        "answers": [
          "Có thể nhận kém ở góc khác nếu ảnh học chưa bao quát điều kiện đó. Chỉ từ mô tả chưa biết chắc đúng hay sai.",
          "Thêm ảnh học phù hợp và thử bằng ảnh mới có tên đúng để đối chiếu. Không dùng chính dự đoán làm đáp án."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chỉ học ảnh chụp chính diện.\n2. Nói dễ hiểu: Đổi góc, kết quả có chắc đúng không?\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Có thể nhận kém ở góc khác nếu ảnh học chưa bao quát điều kiện đó. Chỉ từ mô tả chưa biết chắc đúng hay sai.\nThêm ảnh học phù hợp và thử bằng ảnh mới có tên đúng để đối chiếu. Không dùng chính dự đoán làm đáp án.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chỉ học ảnh chụp chính diện.",
        "Đổi góc, kết quả có chắc đúng không?",
        "Cần thử thế nào để biết?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "Chỉ học ảnh chụp chính diện.",
        "Đổi góc, kết quả có chắc đúng không?",
        "Cần thử thế nào để biết?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chỉ học ảnh chụp chính diện.",
          "tone": "key",
          "note": "Thầy/Cô: Chỉ học ảnh chụp chính diện."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đổi góc, kết quả có chắc đúng không?",
          "tone": "explain",
          "note": "Thầy/Cô: Đổi góc, kết quả có chắc đúng không?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Cần thử thế nào để biết?"
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 3,
        "title": "AI: Training Data & Bias",
        "start": 120,
        "end": 150,
        "poster": "frame_3_135.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/RDlu9sZfdQPEojHL9IgOc/2d98d959793bf7358272ab0d95a5b8ae/ai-03-training-data.mp4",
        "question": "Bộ ảnh đang thiếu trường hợp nào?",
        "local": "code-3.mp4"
      },
      "id": "04-07",
      "title": "Dữ liệu cần đa dạng vì sao?",
      "note": {
        "activity": "Khám phá 2.1 Lập và thực hiện bộ kiểm thử",
        "purpose": "Thu được kết quả sáu trường hợp chưa dùng huấn luyện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá dựa trên nhãn thực và đầu ra quan sát; không chỉ dựa vào độ tự tin.",
        "assessment": "Đạt khi đủ sáu dòng và đối chiếu đúng. Không yêu cầu phải có lỗi mới đạt.",
        "answers": [
          "Có thể nhận kém ở góc khác nếu ảnh học chưa bao quát điều kiện đó. Chỉ từ mô tả chưa biết chắc đúng hay sai.",
          "Thêm ảnh học phù hợp và thử bằng ảnh mới có tên đúng để đối chiếu. Không dùng chính dự đoán làm đáp án."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: Tìm một điều kiện dữ liệu còn thiếu. Nêu việc cần kiểm tra thêm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "Có thể nhận kém ở góc khác nếu ảnh học chưa bao quát điều kiện đó. Chỉ từ mô tả chưa biết chắc đúng hay sai.\nThêm ảnh học phù hợp và thử bằng ảnh mới có tên đúng để đối chiếu. Không dùng chính dự đoán làm đáp án.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "fallback": "Ảnh dạy chưa bao quát có thể khiến máy đoán nhầm. Bổ sung ảnh phù hợp rồi thử lại để biết có thay đổi.",
      "v6": true,
      "screen": [
        "Tìm một điều kiện dữ liệu còn thiếu.",
        "Nêu việc cần kiểm tra thêm."
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 30 giây, em ghi một ví dụ vào vở."
      ],
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm một điều kiện dữ liệu còn thiếu.",
        "Nêu việc cần kiểm tra thêm."
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "type": "concept",
      "id": "04-08",
      "title": "Giữ ảnh thử ngoài ảnh học",
      "note": {
        "activity": "Khám phá 2.1 Lập và thực hiện bộ kiểm thử",
        "purpose": "Thu được kết quả sáu trường hợp chưa dùng huấn luyện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá dựa trên nhãn thực và đầu ra quan sát; không chỉ dựa vào độ tự tin.",
        "assessment": "Đạt khi đủ sáu dòng và đối chiếu đúng. Không yêu cầu phải có lỗi mới đạt.",
        "answers": [
          "Đánh giá dựa trên nhãn thực và đầu ra quan sát. Không chỉ dựa vào độ tự tin."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em có ảnh dùng dạy và ảnh T1–T6.\n2. Nói dễ hiểu: T1–T6 phải mới với AI để kiểm cách đoán.\n3. Điều cần nhớ: Giữ T1–T6 riêng; không thêm vào ảnh dạy.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Đánh giá dựa trên nhãn thực và đầu ra quan sát. Không chỉ dựa vào độ tự tin.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ảnh học: dùng để dạy AI.",
        "Ảnh thử T1–T6: chưa dùng để học.",
        "Tên vật thật: căn cứ đối chiếu."
      ],
      "phase": "Khám phá",
      "scene": "test",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Ảnh học: dùng để dạy AI.",
        "Ảnh thử T1–T6: chưa dùng để học.",
        "Tên vật thật: căn cứ đối chiếu."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em có ảnh dùng dạy và ảnh T1–T6.",
          "tone": "key",
          "note": "Thầy/Cô: Em có ảnh dùng dạy và ảnh T1–T6."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "T1–T6 phải mới với AI để kiểm cách đoán.",
          "tone": "explain",
          "note": "Thầy/Cô: T1–T6 phải mới với AI để kiểm cách đoán."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Giữ T1–T6 riêng; không thêm vào ảnh dạy.",
          "tone": "action",
          "note": "Thầy/Cô: Giữ T1–T6 riêng; không thêm vào ảnh dạy."
        }
      ]
    },
    {
      "id": "04-09-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu giữ ảnh để kiểm thử",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "folders",
      "worked": {
        "title": "Mẫu giữ ảnh để kiểm thử",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Mã ảnh",
          "Tên vật thật",
          "Điều kiện chụp",
          "Chỗ lưu",
          "Điều phải tránh"
        ],
        "values": [
          "T1",
          "Bút",
          "Góc nghiêng, nhìn rõ vật",
          "Thư mục Ảnh thử",
          "Không thêm T1 vào ảnh dạy AI"
        ],
        "why": [
          "Mã giúp em dùng lại đúng tệp.",
          "Tên thật là căn cứ kiểm dự đoán.",
          "Tách ảnh giúp phép thử có ý nghĩa."
        ],
        "question": "Em không được đưa T1 vào đâu?",
        "scene": "Folders"
      },
      "targetId": "04-09",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không thêm T1 vào ảnh dạy AI",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Mã ảnh: T1\nTên vật thật: Bút\nĐiều kiện chụp: Góc nghiêng, nhìn rõ vật\nChỗ lưu: Thư mục Ảnh thử\nĐiều phải tránh: Không thêm T1 vào ảnh dạy AI"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Giữ ảnh T1 ngoài ảnh dạy AI.\n2. Nói dễ hiểu: Ảnh dùng để thử không được đưa vào dạy AI.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Mã ảnh: T1\nTên vật thật: Bút\nĐiều kiện chụp: Góc nghiêng, nhìn rõ vật\nChỗ lưu: Thư mục Ảnh thử\nĐiều phải tránh: Không thêm T1 vào ảnh dạy AI",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 9,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Giữ ảnh T1 ngoài ảnh dạy AI.",
          "tone": "key",
          "note": "Thầy/Cô: Giữ ảnh T1 ngoài ảnh dạy AI."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh dùng để thử không được đưa vào dạy AI.",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh dùng để thử không được đưa vào dạy AI."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em không được đưa T1 vào đâu? Gợi ý: Không thêm T1 vào ảnh dạy AI"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P4.1 Bộ kiểm thử mới",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Không có sẵn nhãn dự đoán đúng cho mọi nhóm. Các em ghi kết quả thật và so với Bút/Cốc. Không xác định được tính chưa đúng trong phép đếm này.",
          "Nhãn thật là thông tin đối chiếu, không lấy từ dự đoán của chính mô hình. Nếu chỉ dùng bảng mẫu Thầy/Cô cung cấp, ghi là phân tích dữ liệu dự phòng."
        ],
        "pages": [
          {
            "title": "Thử các ảnh T1–T3",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh và vật thật",
              "AI gọi tên gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "T1: Bút, góc chính diện, nền trơn",
                {
                  "label": "Dự đoán ảnh T1",
                  "key": "04-09-v3-0"
                },
                {
                  "label": "Nhận xét ảnh T1",
                  "options": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ],
                  "key": "04-09-v3-1",
                  "optionLabels": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ]
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Thử các ảnh T1–T3",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh và vật thật",
              "AI gọi tên gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "T2: Bút, chụp nghiêng",
                {
                  "label": "Dự đoán ảnh T2",
                  "key": "04-09-v3-2"
                },
                {
                  "label": "Nhận xét ảnh T2",
                  "options": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ],
                  "key": "04-09-v3-3",
                  "optionLabels": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ]
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Thử các ảnh T1–T3",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh và vật thật",
              "AI gọi tên gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "T3: Bút, đổi nền nhưng không che vật",
                {
                  "label": "Dự đoán ảnh T3",
                  "key": "04-09-v3-4"
                },
                {
                  "label": "Nhận xét ảnh T3",
                  "options": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ],
                  "key": "04-09-v3-5",
                  "optionLabels": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ]
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Thử các ảnh T4–T6",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh và vật thật",
              "AI gọi tên gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "T4: Cốc, đủ sáng",
                {
                  "label": "Dự đoán ảnh T4",
                  "key": "04-09-v3-6"
                },
                {
                  "label": "Nhận xét ảnh T4",
                  "options": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ],
                  "key": "04-09-v3-7",
                  "optionLabels": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ]
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Thử các ảnh T4–T6",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh và vật thật",
              "AI gọi tên gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "T5: Cốc, đổi góc chụp",
                {
                  "label": "Dự đoán ảnh T5",
                  "key": "04-09-v3-8"
                },
                {
                  "label": "Nhận xét ảnh T5",
                  "options": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ],
                  "key": "04-09-v3-9",
                  "optionLabels": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ]
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Thử các ảnh T4–T6",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh và vật thật",
              "AI gọi tên gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "T6: Cốc, đổi ánh sáng vừa phải",
                {
                  "label": "Dự đoán ảnh T6",
                  "key": "04-09-v3-10"
                },
                {
                  "label": "Nhận xét ảnh T6",
                  "options": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ],
                  "key": "04-09-v3-11",
                  "optionLabels": [
                    "Đúng",
                    "Chưa đúng",
                    "Không có kết quả rõ"
                  ]
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Đọc kết quả lần đầu",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Mô hình nhận đúng bao nhiêu ảnh trong sáu ảnh?",
                "key": "04-09-v3-12"
              }
            ],
            "originalPage": 2,
            "headers": []
          },
          {
            "title": "Đọc kết quả lần đầu",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ảnh nào cần xem lại? Vì sao?",
                "key": "04-09-v3-13"
              }
            ],
            "originalPage": 2,
            "headers": []
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 3,
          "2": 6
        }
      },
      "time": 5,
      "id": "04-09",
      "title": "P4.1 — Thử sáu ảnh đã lưu",
      "note": {
        "activity": "Khám phá 2.1 Lập và thực hiện bộ kiểm thử",
        "purpose": "Hoàn thành sáu trường hợp t1–t6 theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá dựa trên nhãn thực và đầu ra quan sát; không chỉ dựa vào độ tự tin.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Không có sẵn nhãn dự đoán đúng cho mọi nhóm. Các em ghi kết quả thật và so với Bút/Cốc. Không xác định được tính chưa đúng trong phép đếm này.",
          "Nhãn thật là thông tin đối chiếu, không lấy từ dự đoán của chính mô hình. Nếu chỉ dùng bảng mẫu Thầy/Cô cung cấp, ghi là phân tích dữ liệu dự phòng."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Lưu riêng T1–T6. Thử từng tệp trong Preview. Ghi dự đoán và đối chiếu.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Không có sẵn nhãn dự đoán đúng cho mọi nhóm. Các em ghi kết quả thật và so với Bút/Cốc. Không xác định được tính chưa đúng trong phép đếm này.\nNhãn thật là thông tin đối chiếu, không lấy từ dự đoán của chính mô hình. Nếu chỉ dùng bảng mẫu Thầy/Cô cung cấp, ghi là phân tích dữ liệu dự phòng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em so kết quả để rút ra điều có căn cứ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Lưu riêng T1–T6.",
        "Thử từng tệp trong Preview.",
        "Ghi dự đoán và đối chiếu."
      ],
      "phase": "Khám phá",
      "scene": "test",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "04-09-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 10,
      "v7": true,
      "originalTeachingPoints": [
        "Lưu riêng T1–T6.",
        "Thử từng tệp trong Preview.",
        "Ghi dự đoán và đối chiếu."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P4.1 · Thử sáu ảnh"
    },
    {
      "type": "conclusion",
      "id": "04-10",
      "title": "Đối chiếu với tên vật thật",
      "note": {
        "activity": "Khám phá 2.1 Lập và thực hiện bộ kiểm thử",
        "purpose": "Thu được kết quả sáu trường hợp chưa dùng huấn luyện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đánh giá dựa trên nhãn thực và đầu ra quan sát; không chỉ dựa vào độ tự tin.",
        "assessment": "Đạt khi đủ sáu dòng và đối chiếu đúng. Không yêu cầu phải có lỗi mới đạt.",
        "answers": [
          "Đánh giá dựa trên nhãn thực và đầu ra quan sát. Không chỉ dựa vào độ tự tin."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em so kết quả để rút ra điều có căn cứ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tên thật khác với dự đoán.\n2. Nói dễ hiểu: So hai tên để đếm đúng.\n3. Điều cần nhớ: Điểm dự đoán không thay việc kiểm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Đánh giá dựa trên nhãn thực và đầu ra quan sát. Không chỉ dựa vào độ tự tin.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tên thật khác với dự đoán.",
        "So hai tên để đếm đúng.",
        "Điểm dự đoán không thay việc kiểm."
      ],
      "phase": "Khám phá",
      "scene": "test",
      "taskLines": [
        "Trong 30 giây, em nêu một căn cứ tại chỗ."
      ],
      "connector": "Em so kết quả để rút ra điều có căn cứ.",
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [
        "Tên thật khác với dự đoán.",
        "So hai tên để đếm đúng.",
        "Điểm dự đoán không thay việc kiểm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tên thật khác với dự đoán.",
          "tone": "key",
          "note": "Thầy/Cô: Tên thật khác với dự đoán."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So hai tên để đếm đúng.",
          "tone": "explain",
          "note": "Thầy/Cô: So hai tên để đếm đúng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Điểm dự đoán không thay việc kiểm.",
          "tone": "action",
          "note": "Thầy/Cô: Điểm dự đoán không thay việc kiểm."
        }
      ]
    },
    {
      "type": "divider",
      "id": "04-11",
      "title": "Thực hành: cải tiến rồi so sánh",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “vì sao ảnh nghiêng dễ bị nhầm?”."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "04-v7-angle",
      "type": "guide",
      "title": "Vì sao ảnh nghiêng dễ bị nhầm?",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Một ảnh cốc nghiêng bị gọi là Bút.",
        "Có thể bộ ảnh dạy thiếu góc nghiêng.",
        "Xem lại bộ ảnh; bổ sung ảnh mới đúng tên."
      ],
      "scene": "cups",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dạy lại rồi thử cùng sáu tệp",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Một ảnh cốc nghiêng bị gọi là Bút. / Có thể bộ ảnh dạy thiếu góc nghiêng. / Xem lại bộ ảnh; bổ sung ảnh mới đúng tên."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Vì sao ảnh nghiêng dễ bị nhầm?.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Một ảnh cốc nghiêng bị gọi là Bút.\n2. Nói dễ hiểu: Có thể bộ ảnh dạy thiếu góc nghiêng.\n3. Điều cần nhớ: Xem lại bộ ảnh; bổ sung ảnh mới đúng tên.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Một ảnh cốc nghiêng bị gọi là Bút. / Có thể bộ ảnh dạy thiếu góc nghiêng. / Xem lại bộ ảnh; bổ sung ảnh mới đúng tên.",
          "closing": "Thầy/Cô chốt: Xem lại bộ ảnh; bổ sung ảnh mới đúng tên.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "realImage": "cup_dark.png",
      "number": 13,
      "originalTeachingPoints": [
        "Một ảnh cốc nghiêng bị gọi là Bút.",
        "Có thể bộ ảnh dạy thiếu góc nghiêng.",
        "Xem lại bộ ảnh; bổ sung ảnh mới đúng tên."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Một ảnh cốc nghiêng bị gọi là Bút.",
          "tone": "key",
          "note": "Thầy/Cô: Một ảnh cốc nghiêng bị gọi là Bút."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Có thể bộ ảnh dạy thiếu góc nghiêng.",
          "tone": "explain",
          "note": "Thầy/Cô: Có thể bộ ảnh dạy thiếu góc nghiêng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Xem lại bộ ảnh; bổ sung ảnh mới đúng tên.",
          "tone": "action",
          "note": "Thầy/Cô: Xem lại bộ ảnh; bổ sung ảnh mới đúng tên."
        }
      ]
    },
    {
      "id": "04-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu chọn một điều cần sửa",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "folders",
      "worked": {
        "title": "Mẫu chọn một điều cần sửa",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Dấu hiệu",
          "Điều có thể còn thiếu",
          "Việc bổ sung",
          "Việc giữ nguyên",
          "Cách biết có thay đổi"
        ],
        "values": [
          "Một số ảnh nghiêng bị gọi sai",
          "Xem lại: có thể ít ảnh cốc nghiêng",
          "Chụp ảnh cốc nghiêng mới, đúng tên",
          "Giữ nguyên T1–T6 để so hai lượt",
          "Dạy lại rồi thử cùng sáu tệp"
        ],
        "why": [
          "Nêu căn cứ thay vì đoán nguyên nhân chắc chắn.",
          "Ảnh bổ sung khác ảnh giữ để thử.",
          "Kết quả có thể tăng, bằng hoặc giảm."
        ],
        "question": "Em cần làm gì để biết thay đổi có ích?",
        "scene": "Folders"
      },
      "targetId": "04-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dạy lại rồi thử cùng sáu tệp",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Dấu hiệu: Một số ảnh nghiêng bị gọi sai\nĐiều có thể còn thiếu: Xem lại: có thể ít ảnh cốc nghiêng\nViệc bổ sung: Chụp ảnh cốc nghiêng mới, đúng tên\nViệc giữ nguyên: Giữ nguyên T1–T6 để so hai lượt\nCách biết có thay đổi: Dạy lại rồi thử cùng sáu tệp"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Một số ảnh cốc nghiêng bị gọi sai.\n2. Nói dễ hiểu: Có thể thiếu góc nghiêng; cần xem ảnh trước khi sửa.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Dấu hiệu: Một số ảnh nghiêng bị gọi sai\nĐiều có thể còn thiếu: Xem lại: có thể ít ảnh cốc nghiêng\nViệc bổ sung: Chụp ảnh cốc nghiêng mới, đúng tên\nViệc giữ nguyên: Giữ nguyên T1–T6 để so hai lượt\nCách biết có thay đổi: Dạy lại rồi thử cùng sáu tệp",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Một số ảnh cốc nghiêng bị gọi sai.",
          "tone": "key",
          "note": "Thầy/Cô: Một số ảnh cốc nghiêng bị gọi sai."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Có thể thiếu góc nghiêng; cần xem ảnh trước khi sửa.",
          "tone": "explain",
          "note": "Thầy/Cô: Có thể thiếu góc nghiêng; cần xem ảnh trước khi sửa."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em cần làm gì để biết thay đổi có ích? Gợi ý: Dạy lại rồi thử cùng sáu tệp"
        }
      ]
    },
    {
      "type": "task",
      "id": "04-12",
      "title": "Thay đổi một điểm, rồi thử lại",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [
          "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chọn điểm cần bổ sung.\n2. Nói dễ hiểu: Thêm ảnh học mới và dạy AI lại.\n3. Điều cần nhớ: Thử lại đúng T1–T6.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Bảng thử giúp em chọn điều cần bổ sung."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn điểm cần bổ sung.",
        "Thêm ảnh học mới và dạy AI lại.",
        "Thử lại đúng T1–T6."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "taskLines": [
        "Trong 11 phút, em dạy thêm ảnh rồi thử lại trên máy."
      ],
      "sampleId": "04-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn điểm cần bổ sung.",
        "Thêm ảnh học mới và dạy AI lại.",
        "Thử lại đúng T1–T6."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chọn điểm cần bổ sung.",
          "tone": "key",
          "note": "Thầy/Cô: Chọn điểm cần bổ sung."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thêm ảnh học mới và dạy AI lại.",
          "tone": "explain",
          "note": "Thầy/Cô: Thêm ảnh học mới và dạy AI lại."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Thử lại đúng T1–T6.",
          "tone": "action",
          "note": "Thầy/Cô: Thử lại đúng T1–T6."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 0,
      "id": "04-13",
      "title": "Bước 1 — Chọn điều cần cải tiến",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [
          "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Bảng thử giúp em chọn điều cần bổ sung.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Xem lượt thử chưa phù hợp.\n2. Nói dễ hiểu: Tìm điều kiện ảnh học còn thiếu.\n3. Điều cần nhớ: Nếu đều đúng, nêu điều kiện chưa thử.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã chọn điều cần sửa. Giờ em thêm ảnh mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Xem lượt thử chưa phù hợp.",
        "Tìm điều kiện ảnh học còn thiếu.",
        "Nếu đều đúng, nêu điều kiện chưa thử."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "folders",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Bảng thử giúp em chọn điều cần bổ sung.",
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [
        "Xem lượt thử chưa phù hợp.",
        "Tìm điều kiện ảnh học còn thiếu.",
        "Nếu đều đúng, nêu điều kiện chưa thử."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Xem lượt thử chưa phù hợp.",
          "tone": "key",
          "note": "Thầy/Cô: Xem lượt thử chưa phù hợp."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tìm điều kiện ảnh học còn thiếu.",
          "tone": "explain",
          "note": "Thầy/Cô: Tìm điều kiện ảnh học còn thiếu."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nếu đều đúng, nêu điều kiện chưa thử.",
          "tone": "action",
          "note": "Thầy/Cô: Nếu đều đúng, nêu điều kiện chưa thử."
        }
      ]
    },
    {
      "type": "step",
      "step": 2,
      "time": 0,
      "id": "04-14",
      "title": "Bước 2 — Thêm ảnh học mới",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [
          "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã chọn điều cần sửa. Giờ em thêm ảnh mới.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chụp ảnh khác T1–T6.\n2. Nói dễ hiểu: Đặt đúng nhãn Bút/Cốc.\n3. Điều cần nhớ: Ghi số ảnh thêm và lí do.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Ảnh mẫu đã đổi. Em cần dạy AI lại."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chụp ảnh khác T1–T6.",
        "Đặt đúng nhãn Bút/Cốc.",
        "Ghi số ảnh thêm và lí do."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "folders",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Em đã chọn điều cần sửa. Giờ em thêm ảnh mới.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Chụp ảnh khác T1–T6.",
        "Đặt đúng nhãn Bút/Cốc.",
        "Ghi số ảnh thêm và lí do."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chụp ảnh khác T1–T6.",
          "tone": "key",
          "note": "Thầy/Cô: Chụp ảnh khác T1–T6."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đặt đúng nhãn Bút/Cốc.",
          "tone": "explain",
          "note": "Thầy/Cô: Đặt đúng nhãn Bút/Cốc."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi số ảnh thêm và lí do.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi số ảnh thêm và lí do."
        }
      ]
    },
    {
      "type": "step",
      "step": 3,
      "time": 0,
      "id": "04-15",
      "title": "Bước 3 — dạy AI lại",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [
          "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Ảnh mẫu đã đổi. Em cần dạy AI lại.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Giữ hai nhãn Bút/Cốc.\n2. Nói dễ hiểu: Dùng bộ ảnh đã bổ sung.\n3. Điều cần nhớ: Chưa kết luận kết quả sẽ tốt hơn.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: AI đã học lại. Em thử đúng sáu tệp cũ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Giữ hai nhãn Bút/Cốc.",
        "Dùng bộ ảnh đã bổ sung.",
        "Chưa kết luận kết quả sẽ tốt hơn."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "folders",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Ảnh mẫu đã đổi. Em cần dạy AI lại.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Giữ hai nhãn Bút/Cốc.",
        "Dùng bộ ảnh đã bổ sung.",
        "Chưa kết luận kết quả sẽ tốt hơn."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Giữ hai nhãn Bút/Cốc.",
          "tone": "key",
          "note": "Thầy/Cô: Giữ hai nhãn Bút/Cốc."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dùng bộ ảnh đã bổ sung.",
          "tone": "explain",
          "note": "Thầy/Cô: Dùng bộ ảnh đã bổ sung."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chưa kết luận kết quả sẽ tốt hơn.",
          "tone": "action",
          "note": "Thầy/Cô: Chưa kết luận kết quả sẽ tốt hơn."
        }
      ]
    },
    {
      "type": "step",
      "step": 4,
      "time": 0,
      "id": "04-16",
      "title": "Bước 4 — Thử lại cùng bộ ảnh",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [
          "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: AI đã học lại. Em thử đúng sáu tệp cũ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Thử đúng T1–T6.\n2. Nói dễ hiểu: So số ảnh đúng trước–sau.\n3. Điều cần nhớ: Tăng, bằng hoặc giảm đều ghi thật.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “mẫu · ba lượt trước khi sửa”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Thử đúng T1–T6.",
        "So số ảnh đúng trước–sau.",
        "Tăng, bằng hoặc giảm đều ghi thật."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "before-after",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "AI đã học lại. Em thử đúng sáu tệp cũ.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "Thử đúng T1–T6.",
        "So số ảnh đúng trước–sau.",
        "Tăng, bằng hoặc giảm đều ghi thật."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Thử đúng T1–T6.",
          "tone": "key",
          "note": "Thầy/Cô: Thử đúng T1–T6."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So số ảnh đúng trước–sau.",
          "tone": "explain",
          "note": "Thầy/Cô: So số ảnh đúng trước–sau."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Tăng, bằng hoặc giảm đều ghi thật.",
          "tone": "action",
          "note": "Thầy/Cô: Tăng, bằng hoặc giảm đều ghi thật."
        }
      ]
    },
    {
      "id": "04-v7-before",
      "type": "guide",
      "title": "Mẫu · Ba lượt trước khi sửa",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Ghi từng tên máy đưa ra, không sửa hộ máy.",
        "So mỗi tên với vật thật trong ảnh.",
        "Khoanh lượt sai để chọn điều cần kiểm thêm."
      ],
      "scene": "before-after",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở T4, AI hết nhầm sau lần sửa này",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Ghi từng tên máy đưa ra, không sửa hộ máy. / So mỗi tên với vật thật trong ảnh. / Khoanh lượt sai để chọn điều cần kiểm thêm."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Mẫu · Ba lượt trước khi sửa.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ghi từng tên máy đưa ra, không sửa hộ máy.\n2. Nói dễ hiểu: So mỗi tên với vật thật trong ảnh.\n3. Điều cần nhớ: Khoanh lượt sai để chọn điều cần kiểm thêm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ghi từng tên máy đưa ra, không sửa hộ máy. / So mỗi tên với vật thật trong ảnh. / Khoanh lượt sai để chọn điều cần kiểm thêm.",
          "closing": "Thầy/Cô chốt: Khoanh lượt sai để chọn điều cần kiểm thêm.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “mẫu · ba lượt sau khi dạy thêm”."
        }
      },
      "guideTable": {
        "headers": [
          "Ảnh giữ riêng",
          "Máy gọi",
          "So vật thật"
        ],
        "rows": [
          [
            "T1 · Bút thẳng",
            "Bút",
            "Đúng"
          ],
          [
            "T2 · Cốc nghiêng",
            "Bút",
            "Sai"
          ],
          [
            "T3 · Cốc xa",
            "Bút",
            "Sai"
          ]
        ],
        "label": "Kết quả tạo sẵn để học cách ghi."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 20,
      "originalTeachingPoints": [
        "Ghi từng tên máy đưa ra, không sửa hộ máy.",
        "So mỗi tên với vật thật trong ảnh.",
        "Khoanh lượt sai để chọn điều cần kiểm thêm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ghi từng tên máy đưa ra, không sửa hộ máy.",
          "tone": "key",
          "note": "Thầy/Cô: Ghi từng tên máy đưa ra, không sửa hộ máy."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So mỗi tên với vật thật trong ảnh.",
          "tone": "explain",
          "note": "Thầy/Cô: So mỗi tên với vật thật trong ảnh."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Khoanh lượt sai để chọn điều cần kiểm thêm.",
          "tone": "action",
          "note": "Thầy/Cô: Khoanh lượt sai để chọn điều cần kiểm thêm."
        }
      ]
    },
    {
      "id": "04-v7-after",
      "type": "guide",
      "title": "Mẫu · Ba lượt sau khi dạy thêm",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Chụp thêm ảnh học; giữ nguyên ảnh thử.",
        "Dạy lại rồi dùng đúng T1, T2, T3.",
        "Chỉ kết luận về các ảnh đã thử."
      ],
      "scene": "before-after",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở T4, AI hết nhầm sau lần sửa này",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Chụp thêm ảnh học; giữ nguyên ảnh thử. / Dạy lại rồi dùng đúng T1, T2, T3. / Chỉ kết luận về các ảnh đã thử."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Mẫu · Ba lượt sau khi dạy thêm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chụp thêm ảnh học; giữ nguyên ảnh thử.\n2. Nói dễ hiểu: Dạy lại rồi dùng đúng T1, T2, T3.\n3. Điều cần nhớ: Chỉ kết luận về các ảnh đã thử.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Chụp thêm ảnh học; giữ nguyên ảnh thử. / Dạy lại rồi dùng đúng T1, T2, T3. / Chỉ kết luận về các ảnh đã thử.",
          "closing": "Thầy/Cô chốt: Chỉ kết luận về các ảnh đã thử.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "guideTable": {
        "headers": [
          "Cùng ảnh thử",
          "Máy gọi sau sửa",
          "So vật thật"
        ],
        "rows": [
          [
            "T1 · Bút thẳng",
            "Bút",
            "Đúng"
          ],
          [
            "T2 · Cốc nghiêng",
            "Cốc",
            "Đúng"
          ],
          [
            "T3 · Cốc xa",
            "Bút",
            "Sai"
          ]
        ],
        "label": "Mẫu: đúng 1/3 → 2/3; chưa đúng mọi ảnh."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 21,
      "originalTeachingPoints": [
        "Chụp thêm ảnh học; giữ nguyên ảnh thử.",
        "Dạy lại rồi dùng đúng T1, T2, T3.",
        "Chỉ kết luận về các ảnh đã thử."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chụp thêm ảnh học; giữ nguyên ảnh thử.",
          "tone": "key",
          "note": "Thầy/Cô: Chụp thêm ảnh học; giữ nguyên ảnh thử."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dạy lại rồi dùng đúng T1, T2, T3.",
          "tone": "explain",
          "note": "Thầy/Cô: Dạy lại rồi dùng đúng T1, T2, T3."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chỉ kết luận về các ảnh đã thử.",
          "tone": "action",
          "note": "Thầy/Cô: Chỉ kết luận về các ảnh đã thử."
        }
      ]
    },
    {
      "id": "04-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu so kết quả trước và sau",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "before-after",
      "worked": {
        "title": "Mẫu so kết quả trước và sau",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Ảnh T4",
          "Trước bổ sung",
          "Việc đã làm",
          "Sau bổ sung",
          "Câu kết luận"
        ],
        "values": [
          "Cốc nghiêng. Giữ cùng một tệp",
          "AI gọi Bút: chưa đúng",
          "Thêm ảnh cốc nghiêng khác T4",
          "AI gọi Cốc: đúng với ảnh này",
          "Ở T4, AI hết nhầm sau lần sửa này"
        ],
        "why": [
          "Cùng tệp giúp so hai lượt rõ hơn.",
          "Ảnh học mới không lấy từ bộ thử.",
          "Không suy ra AI đúng mọi ảnh nghiêng."
        ],
        "question": "Em nên điền kết luận nào cho ảnh T4?",
        "scene": "Before-after"
      },
      "targetId": "04-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ở T4, AI hết nhầm sau lần sửa này",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Ảnh T4: Cốc nghiêng. Giữ cùng một tệp\nTrước bổ sung: AI gọi Bút: chưa đúng\nViệc đã làm: Thêm ảnh cốc nghiêng khác T4\nSau bổ sung: AI gọi Cốc: đúng với ảnh này\nCâu kết luận: Ở T4, AI hết nhầm sau lần sửa này"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Cùng ảnh T4, so hai lần thử.\n2. Nói dễ hiểu: Giữ cùng tệp để so kết quả trước và sau.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Ảnh T4: Cốc nghiêng. Giữ cùng một tệp\nTrước bổ sung: AI gọi Bút: chưa đúng\nViệc đã làm: Thêm ảnh cốc nghiêng khác T4\nSau bổ sung: AI gọi Cốc: đúng với ảnh này\nCâu kết luận: Ở T4, AI hết nhầm sau lần sửa này",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Cùng ảnh T4, so hai lần thử.",
          "tone": "key",
          "note": "Thầy/Cô: Cùng ảnh T4, so hai lần thử."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Giữ cùng tệp để so kết quả trước và sau.",
          "tone": "explain",
          "note": "Thầy/Cô: Giữ cùng tệp để so kết quả trước và sau."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em nên điền kết luận nào cho ảnh T4? Gợi ý: Ở T4, AI hết nhầm sau lần sửa này"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P4.2 Điều chỉnh và so sánh",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "So sánh đúng sáu ảnh đã lưu trước và sau. Không trộn những ảnh đó vào ảnh học.",
          "Kết quả có thể tăng, giữ nguyên hoặc giảm. Cần nêu ảnh bổ sung, lí do và số ảnh nhận đúng.",
          "Vì đã dùng bộ T để xem xét điều chỉnh, kết quả trên T không phải đánh giá độc lập cho mọi ảnh mới. Muốn đánh giá tiếp, chuẩn bị thêm ảnh chưa dùng trong quá trình này."
        ],
        "pages": [
          {
            "title": "So sánh ảnh T1–T3",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh",
              "Kết quả trước",
              "Kết quả sau"
            ],
            "rows": [
              [
                "T1: Bút",
                {
                  "label": "Trước, ảnh T1",
                  "key": "04-17-v3-0"
                },
                {
                  "label": "Sau, ảnh T1",
                  "key": "04-17-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "So sánh ảnh T1–T3",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh",
              "Kết quả trước",
              "Kết quả sau"
            ],
            "rows": [
              [
                "T2: Bút",
                {
                  "label": "Trước, ảnh T2",
                  "key": "04-17-v3-2"
                },
                {
                  "label": "Sau, ảnh T2",
                  "key": "04-17-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "So sánh ảnh T1–T3",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh",
              "Kết quả trước",
              "Kết quả sau"
            ],
            "rows": [
              [
                "T3: Bút",
                {
                  "label": "Trước, ảnh T3",
                  "key": "04-17-v3-4"
                },
                {
                  "label": "Sau, ảnh T3",
                  "key": "04-17-v3-5"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "So sánh ảnh T4–T6",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh",
              "Kết quả trước",
              "Kết quả sau"
            ],
            "rows": [
              [
                "T4: Cốc",
                {
                  "label": "Trước, ảnh T4",
                  "key": "04-17-v3-6"
                },
                {
                  "label": "Sau, ảnh T4",
                  "key": "04-17-v3-7"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "So sánh ảnh T4–T6",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh",
              "Kết quả trước",
              "Kết quả sau"
            ],
            "rows": [
              [
                "T5: Cốc",
                {
                  "label": "Trước, ảnh T5",
                  "key": "04-17-v3-8"
                },
                {
                  "label": "Sau, ảnh T5",
                  "key": "04-17-v3-9"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "So sánh ảnh T4–T6",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh",
              "Kết quả trước",
              "Kết quả sau"
            ],
            "rows": [
              [
                "T6: Cốc",
                {
                  "label": "Trước, ảnh T6",
                  "key": "04-17-v3-10"
                },
                {
                  "label": "Sau, ảnh T6",
                  "key": "04-17-v3-11"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi điều em đã thay đổi",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em thêm ảnh nào? Có bao nhiêu ảnh?",
                "key": "04-17-v3-12"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Ghi điều em đã thay đổi",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vì sao chọn bổ sung những ảnh đó?",
                "key": "04-17-v3-13"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Ghi điều em đã thay đổi",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em giữ nguyên điều kiện nào khi so sánh?",
                "key": "04-17-v3-14"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Kết luận trước–sau",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Số ảnh đúng trước và sau là bao nhiêu?",
                "key": "04-17-v3-15"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Kết luận trước–sau",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Trong sáu ảnh này, kết quả thay đổi thế nào?",
                "key": "04-17-v3-16"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Kết luận trước–sau",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Muốn biết mô hình nhận các ảnh khác ra sao, em cần làm gì tiếp?",
                "key": "04-17-v3-17"
              }
            ],
            "originalPage": 3
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 3,
          "2": 6,
          "3": 9
        }
      },
      "time": 16,
      "id": "04-17",
      "title": "P4.2 — So sánh hai lượt thử",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Hoàn thành so sánh trước–sau theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "So sánh đúng sáu ảnh đã lưu trước và sau. Không trộn những ảnh đó vào ảnh học.",
          "Kết quả có thể tăng, giữ nguyên hoặc giảm. Cần nêu ảnh bổ sung, lí do và số ảnh nhận đúng.",
          "Vì đã dùng bộ T để xem xét điều chỉnh, kết quả trên T không phải đánh giá độc lập cho mọi ảnh mới. Muốn đánh giá tiếp, chuẩn bị thêm ảnh chưa dùng trong quá trình này."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Ghi kết quả sau cải tiến. Ghi dữ liệu đã thay đổi. Kết luận trong phạm vi sáu ảnh.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "So sánh đúng sáu ảnh đã lưu trước và sau. Không trộn những ảnh đó vào ảnh học.\nKết quả có thể tăng, giữ nguyên hoặc giảm. Cần nêu ảnh bổ sung, lí do và số ảnh nhận đúng.\nVì đã dùng bộ T để xem xét điều chỉnh, kết quả trên T không phải đánh giá độc lập cho mọi ảnh mới. Muốn đánh giá tiếp, chuẩn bị thêm ảnh chưa dùng trong quá trình này.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi kết quả sau cải tiến.",
        "Ghi dữ liệu đã thay đổi.",
        "Kết luận trong phạm vi sáu ảnh."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "04-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi kết quả sau cải tiến.",
        "Ghi dữ liệu đã thay đổi.",
        "Kết luận trong phạm vi sáu ảnh."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P4.2 · So hai lượt thử"
    },
    {
      "type": "report",
      "id": "04-18",
      "title": "Kết quả cho phép nói đến đâu?",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [
          "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em đã thay đổi gì?\n2. Nói dễ hiểu: Số đúng thay đổi ra sao?\n3. Điều cần nhớ: Điều gì chưa được kiểm tra?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Em đã thay đổi gì?",
        "Số đúng thay đổi ra sao?",
        "Điều gì chưa được kiểm tra?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [
        "Em đã thay đổi gì?",
        "Số đúng thay đổi ra sao?",
        "Điều gì chưa được kiểm tra?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em đã thay đổi gì?",
          "tone": "key",
          "note": "Thầy/Cô: Em đã thay đổi gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Số đúng thay đổi ra sao?",
          "tone": "explain",
          "note": "Thầy/Cô: Số đúng thay đổi ra sao?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Điều gì chưa được kiểm tra?",
          "tone": "action",
          "note": "Thầy/Cô: Điều gì chưa được kiểm tra?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "04-20",
      "title": "Luyện tập: kết luận vừa đủ",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Phát hiện kết luận vượt quá bằng chứng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thử nghiệm nhỏ giúp phát hiện vấn đề, không chứng minh mô hình hoàn hảo.",
        "assessment": "Đạt khi sửa đúng ít nhất 2/3 và không dùng ảnh kiểm thử để tự chứng minh tiến bộ.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "04-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu sửa một câu nói quá chắc",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "worked": {
        "title": "Mẫu sửa một câu nói quá chắc",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Câu gốc",
          "Điều đã đo",
          "Điều chưa đo",
          "Câu sửa",
          "Cách kiểm thêm"
        ],
        "values": [
          "AI sẽ luôn nhận đúng",
          "Đúng hai ảnh đã thử",
          "Các ảnh và điều kiện khác",
          "AI đúng hai ảnh này, cần thử thêm",
          "Dùng ảnh mới và so vật thật"
        ],
        "why": [
          "Chỉ kết luận trong phần đã thử.",
          "Đừng biến kết quả nhỏ thành bảo đảm.",
          "Em nêu thêm cách kiểm."
        ],
        "question": "Em kiểm thêm bằng ảnh nào?",
        "scene": "Test"
      },
      "targetId": "04-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dùng ảnh mới và so vật thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Câu gốc: AI sẽ luôn nhận đúng\nĐiều đã đo: Đúng hai ảnh đã thử\nĐiều chưa đo: Các ảnh và điều kiện khác\nCâu sửa: AI đúng hai ảnh này, cần thử thêm\nCách kiểm thêm: Dùng ảnh mới và so vật thật"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đúng hai ảnh có nghĩa luôn đúng không?\n2. Nói dễ hiểu: Hai ảnh đúng chưa nói được về mọi ảnh.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Câu gốc: AI sẽ luôn nhận đúng\nĐiều đã đo: Đúng hai ảnh đã thử\nĐiều chưa đo: Các ảnh và điều kiện khác\nCâu sửa: AI đúng hai ảnh này, cần thử thêm\nCách kiểm thêm: Dùng ảnh mới và so vật thật",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đúng hai ảnh có nghĩa luôn đúng không?",
          "tone": "key",
          "note": "Thầy/Cô: Đúng hai ảnh có nghĩa luôn đúng không?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Hai ảnh đúng chưa nói được về mọi ảnh.",
          "tone": "explain",
          "note": "Thầy/Cô: Hai ảnh đúng chưa nói được về mọi ảnh."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em kiểm thêm bằng ảnh nào? Gợi ý: Dùng ảnh mới và so vật thật"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P4.3 Kết luận có căn cứ",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "1. Mô hình nhận đúng sáu ảnh này trong điều kiện đã ghi. Cần thử thêm ảnh mới.",
          "2. Ảnh đã học không đủ chứng minh khả năng với ảnh mới. Giữ ảnh thử ngoài ảnh học.",
          "3. 99% là điểm mô hình hiển thị cho dự đoán ở ảnh này. Không bảo đảm tên vật đúng. Vẫn so với vật thật và thử thêm ảnh mới."
        ],
        "pages": [
          {
            "title": "Sửa kết luận quá mức",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“Đúng cả sáu ảnh nghĩa là mô hình luôn đúng.”",
                "key": "04-21-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Sửa kết luận quá mức",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“Dùng ảnh đã học để thử là đủ biết mô hình nhận tốt ảnh mới.”",
                "key": "04-21-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Có thể chỉ nhìn phần trăm không?",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Điểm 99% đã bảo đảm tên vật đúng chưa?",
                "key": "04-21-v3-2"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2
        }
      },
      "time": 4,
      "id": "04-21",
      "title": "P4.3A — Sửa kết luận quá mức",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành sửa kết luận thiếu căn cứ theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thử nghiệm nhỏ giúp phát hiện vấn đề, không chứng minh mô hình hoàn hảo.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1. Mô hình nhận đúng sáu ảnh này trong điều kiện đã ghi. Cần thử thêm ảnh mới.",
          "2. Ảnh đã học không đủ chứng minh khả năng với ảnh mới. Giữ ảnh thử ngoài ảnh học.",
          "3. 99% là điểm mô hình hiển thị cho dự đoán ở ảnh này. Không bảo đảm tên vật đúng. Vẫn so với vật thật và thử thêm ảnh mới."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "99% trên một dự đoán là điểm mô hình hiển thị, không phải chứng nhận nhãn đúng hay độ chính xác trên mọi ảnh. Luôn đối chiếu tên vật thật.\nÝ cần giảng rõ: Đúng sáu ảnh ≠ đúng mọi ảnh. Ảnh đã học chưa đủ để kiểm tra. 99% vẫn cần đối chiếu.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1. Mô hình nhận đúng sáu ảnh này trong điều kiện đã ghi. Cần thử thêm ảnh mới.\n2. Ảnh đã học không đủ chứng minh khả năng với ảnh mới. Giữ ảnh thử ngoài ảnh học.\n3. 99% là điểm mô hình hiển thị cho dự đoán ở ảnh này. Không bảo đảm tên vật đúng. Vẫn so với vật thật và thử thêm ảnh mới.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đúng sáu ảnh ≠ đúng mọi ảnh.",
        "Ảnh đã học chưa đủ để kiểm tra.",
        "99% vẫn cần đối chiếu."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "04-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [
        "Đúng sáu ảnh ≠ đúng mọi ảnh.",
        "Ảnh đã học chưa đủ để kiểm tra.",
        "99% vẫn cần đối chiếu."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P4.3A · Em tự làm"
    },
    {
      "type": "recap",
      "id": "04-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Cải tiến và so sánh",
        "purpose": "Thực hiện điều chỉnh có lí do và nhận xét trước–sau.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Cải tiến cần được kiểm chứng. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm; kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
        "assessment": "Đánh giá quy trình và bằng chứng, không thưởng riêng cho mức tăng. Thiếu kiểm thử sau thì chưa đủ kết luận cải tiến.",
        "answers": [
          "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Giữ ảnh thử riêng với ảnh học.\n2. Nói dễ hiểu: So cùng bộ ảnh trước và sau thay đổi.\n3. Điều cần nhớ: Đúng sáu ảnh chưa chứng minh đúng mọi ảnh.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Cải tiến cần được kiểm tra. Số lượt đúng có thể tăng, giữ nguyên hoặc giảm. Kết luận chỉ trong bộ thử nhỏ và điều kiện đã ghi.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Giữ ảnh thử riêng với ảnh học.",
        "So cùng bộ ảnh trước và sau thay đổi.",
        "Đúng sáu ảnh chưa chứng minh đúng mọi ảnh."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "test",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [
        "Giữ ảnh thử riêng với ảnh học.",
        "So cùng bộ ảnh trước và sau thay đổi.",
        "Đúng sáu ảnh chưa chứng minh đúng mọi ảnh."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Giữ ảnh thử riêng với ảnh học.",
          "tone": "key",
          "note": "Thầy/Cô: Giữ ảnh thử riêng với ảnh học."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "So cùng bộ ảnh trước và sau thay đổi.",
          "tone": "explain",
          "note": "Thầy/Cô: So cùng bộ ảnh trước và sau thay đổi."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đúng sáu ảnh chưa chứng minh đúng mọi ảnh.",
          "tone": "action",
          "note": "Thầy/Cô: Đúng sáu ảnh chưa chứng minh đúng mọi ảnh."
        }
      ]
    },
    {
      "type": "divider",
      "id": "04-22",
      "title": "Vận dụng: kiểm tra điều còn thiếu",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Đề xuất thử nghiệm tiếp theo có kiểm soát.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thử có mục đích giúp tìm nguyên nhân rõ hơn thử ngẫu nhiên.",
        "assessment": "Nhận xét 6.D2.1 qua đề xuất và lí do, không chỉ dựa vào thao tác máy.",
        "answers": [],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "test",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "04-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu lập phép thử tiếp theo",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "cups",
      "worked": {
        "title": "Mẫu lập phép thử tiếp theo",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Điều còn thiếu",
          "Ảnh cần tạo",
          "Tên thật",
          "Chỗ lưu",
          "Việc sau khi thử"
        ],
        "values": [
          "Góc chụp từ trên",
          "Ảnh cốc mới, nhìn rõ miệng cốc",
          "Cốc",
          "Để riêng khỏi ảnh dạy AI",
          "Ghi dự đoán rồi so với cốc thật"
        ],
        "why": [
          "Chọn một điều chưa kiểm.",
          "Lưu ảnh trước để dùng đúng tệp.",
          "Chưa ghi trước AI sẽ đúng."
        ],
        "question": "Sau khi AI đoán, em làm gì?",
        "scene": "Cups"
      },
      "targetId": "04-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ghi dự đoán rồi so với cốc thật",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Điều còn thiếu: Góc chụp từ trên\nẢnh cần tạo: Ảnh cốc mới, nhìn rõ miệng cốc\nTên thật: Cốc\nChỗ lưu: Để riêng khỏi ảnh dạy AI\nViệc sau khi thử: Ghi dự đoán rồi so với cốc thật"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Bộ thử còn thiếu ảnh chụp từ trên.\n2. Nói dễ hiểu: Chụp ảnh mới từ góc chưa thử, rồi so vật thật.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Điều còn thiếu: Góc chụp từ trên\nẢnh cần tạo: Ảnh cốc mới, nhìn rõ miệng cốc\nTên thật: Cốc\nChỗ lưu: Để riêng khỏi ảnh dạy AI\nViệc sau khi thử: Ghi dự đoán rồi so với cốc thật",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 30,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Bộ thử còn thiếu ảnh chụp từ trên.",
          "tone": "key",
          "note": "Thầy/Cô: Bộ thử còn thiếu ảnh chụp từ trên."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chụp ảnh mới từ góc chưa thử, rồi so vật thật.",
          "tone": "explain",
          "note": "Thầy/Cô: Chụp ảnh mới từ góc chưa thử, rồi so vật thật."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Sau khi AI đoán, em làm gì? Gợi ý: Ghi dự đoán rồi so với cốc thật"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P4.3 Kết luận có căn cứ",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "B Chấp nhận thử thêm kiểu cốc, góc hoặc nền. Chỉ ra biến đổi và nhãn thật."
        ],
        "pages": [
          {
            "title": "Đề xuất cách thử tiếp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em muốn thử vật hoặc điều kiện nào?",
                "key": "04-23-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đề xuất cách thử tiếp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em thay đổi gì và giữ nguyên gì?",
                "key": "04-23-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đề xuất cách thử tiếp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em so kết quả với tên đúng nào của đồ vật?",
                "key": "04-23-v3-2"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 3,
      "id": "04-23",
      "title": "P4.3B — Thiết kế lần thử tiếp",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Hoàn thành thiết kế phép thử tiếp theo theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thử có mục đích giúp tìm nguyên nhân rõ hơn thử ngẫu nhiên.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "B Chấp nhận thử thêm kiểu cốc, góc hoặc nền. Chỉ ra biến đổi và nhãn thật."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Chọn điều kiện chưa thử. Chuẩn bị ảnh mới. Nêu cách đối chiếu kết quả.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "B Chấp nhận thử thêm kiểu cốc, góc hoặc nền. Chỉ ra biến đổi và nhãn thật.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn điều kiện chưa thử.",
        "Chuẩn bị ảnh mới.",
        "Nêu cách đối chiếu kết quả."
      ],
      "phase": "Vận dụng",
      "scene": "test",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "04-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 31,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn điều kiện chưa thử.",
        "Chuẩn bị ảnh mới.",
        "Nêu cách đối chiếu kết quả."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P4.3B · Em tự làm"
    },
    {
      "type": "home",
      "id": "04-24",
      "title": "Lưu kết quả, nêu giới hạn",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Đề xuất thử nghiệm tiếp theo có kiểm soát.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thử có mục đích giúp tìm nguyên nhân rõ hơn thử ngẫu nhiên.",
        "assessment": "Nhận xét 6.D2.1 qua đề xuất và lí do, không chỉ dựa vào thao tác máy.",
        "answers": [
          "Thử có mục đích giúp tìm nguyên nhân rõ hơn thử ngẫu nhiên."
        ],
        "source": "Bài 2 Dạy máy học, quy trình thử nghiệm; Bài 3 Nhận dạng hình ảnh, chất lượng ảnh, trang in 20. Bảng thử nghiệm sáu mẫu do Thầy/Cô thiết kế.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đã thay đổi gì?\n2. Nói dễ hiểu: Đã quan sát được gì?\n3. Điều cần nhớ: Chưa thể khẳng định điều gì?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Thử có mục đích giúp tìm nguyên nhân rõ hơn thử ngẫu nhiên.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đã thay đổi gì?",
        "Đã quan sát được gì?",
        "Chưa thể khẳng định điều gì?"
      ],
      "phase": "Vận dụng",
      "scene": "test",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 32,
      "v7": true,
      "originalTeachingPoints": [
        "Đã thay đổi gì?",
        "Đã quan sát được gì?",
        "Chưa thể khẳng định điều gì?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đã thay đổi gì?",
          "tone": "key",
          "note": "Thầy/Cô: Đã thay đổi gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đã quan sát được gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Đã quan sát được gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chưa thể khẳng định điều gì?",
          "tone": "action",
          "note": "Thầy/Cô: Chưa thể khẳng định điều gì?"
        }
      ]
    }
  ],
  "rubric": [],
  "evidence": [
    [
      "Đọc kết quả và lí giải",
      "6.3.TC1a",
      "Mô tả mô hình và nguyên nhân có thể gây sai.",
      "P4.1, P4.3 cá nhân",
      "Dẫn được một dòng dữ liệu; không khẳng định nguyên nhân khi chưa đủ bằng chứng."
    ],
    [
      "Điều chỉnh và thử lại",
      "6.2.TC1b",
      "Bổ sung dữ liệu đúng nhãn, huấn luyện lại.",
      "P4.2 và quan sát thao tác",
      "Có thử lại ngoài tập huấn luyện; kết quả không tăng vẫn được ghi nhận đúng quy trình."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
