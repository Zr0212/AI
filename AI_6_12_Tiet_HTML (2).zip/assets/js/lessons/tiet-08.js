window.AI6_LESSON={
  "id": 8,
  "title": "Bài 8. Con người kết hợp với AI - hình thành ý tưởng dự án",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 32,
  "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 5,
    "title": "AI: How Computer Vision Works",
    "start": 15,
    "end": 40,
    "poster": "frame_5_20.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/5LHEqBfj39mMaxu0jlpFBQ/e8c81cbd51865522b439643e03a24d53/videoplayback.mp4",
    "question": "Quan sát ứng dụng trên cánh đồng. Ai đặt mục tiêu, ai kiểm tra và can thiệp khi cần?",
    "local": "code-5.mp4"
  },
  "outcome": "Một ý tưởng, bản phác thảo và phiếu tóm tắt nhiệm vụ.",
  "slides": [
    {
      "type": "cover",
      "id": "08-01",
      "title": "Bài 8. Con người kết hợp với AI - hình thành ý tưởng dự án",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận diện một vấn đề cụ thể thay cho ý tưởng quá rộng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Hai HS đọc vấn đề đã thu hẹp.",
        "conclusion": "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra.",
        "assessment": "Quan sát các em có nêu kết quả cụ thể. Hỗ trợ bằng câu Ai cần làm việc gì?",
        "answers": [
          "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "idea",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "08-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận diện một vấn đề cụ thể thay cho ý tưởng quá rộng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai HS đọc vấn đề đã thu hẹp.",
        "conclusion": "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra.",
        "assessment": "Quan sát các em có nêu kết quả cụ thể. Hỗ trợ bằng câu Ai cần làm việc gì?",
        "answers": [
          "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: So hai ý tưởng, chọn một ý vừa sức.\n2. Nói dễ hiểu: Chia rõ việc AI và người kiểm tra.\n3. Điều cần nhớ: Phác thảo sản phẩm, đọc tiêu chí dự án.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "So hai ý tưởng, chọn một ý vừa sức.",
        "Chia rõ việc AI và người kiểm tra.",
        "Phác thảo sản phẩm, đọc tiêu chí dự án."
      ],
      "phase": "Khởi động",
      "scene": "idea",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "So hai ý tưởng, chọn một ý vừa sức.",
        "Chia rõ việc AI và người kiểm tra.",
        "Phác thảo sản phẩm, đọc tiêu chí dự án."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "So hai ý tưởng, chọn một ý vừa sức.",
          "tone": "key",
          "note": "Thầy/Cô: So hai ý tưởng, chọn một ý vừa sức."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chia rõ việc AI và người kiểm tra.",
          "tone": "explain",
          "note": "Thầy/Cô: Chia rõ việc AI và người kiểm tra."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Phác thảo sản phẩm, đọc tiêu chí dự án.",
          "tone": "action",
          "note": "Thầy/Cô: Phác thảo sản phẩm, đọc tiêu chí dự án."
        }
      ]
    },
    {
      "type": "divider",
      "id": "08-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận diện một vấn đề cụ thể thay cho ý tưởng quá rộng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Hai HS đọc vấn đề đã thu hẹp.",
        "conclusion": "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra.",
        "assessment": "Quan sát các em có nêu kết quả cụ thể. Hỗ trợ bằng câu Ai cần làm việc gì?",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "idea",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "08-04",
      "title": "Ý tưởng nào dễ bắt đầu hơn?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận diện một vấn đề cụ thể thay cho ý tưởng quá rộng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai HS đọc vấn đề đã thu hẹp.",
        "conclusion": "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra.",
        "assessment": "Quan sát các em có nêu kết quả cụ thể. Hỗ trợ bằng câu Ai cần làm việc gì?",
        "answers": [
          "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: A: Làm AI giúp mọi người.\n2. Nói dễ hiểu: B: Giúp em cùng nhóm hiểu ba từ, có bảng từ để kiểm.\n3. Điều cần nhớ: Vì sao B dễ lập kế hoạch hơn?",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dự án nhỏ cần nhu cầu, người dùng và mục tiêu có thể kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "A: Làm AI giúp mọi người.",
        "B: Giúp em cùng nhóm hiểu ba từ, có bảng từ để kiểm.",
        "Vì sao B dễ lập kế hoạch hơn?"
      ],
      "phase": "Khởi động",
      "scene": "idea",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "A: Làm AI giúp mọi người.",
        "B: Giúp em cùng nhóm hiểu ba từ, có bảng từ để kiểm.",
        "Vì sao B dễ lập kế hoạch hơn?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "A: Làm AI giúp mọi người.",
          "tone": "key",
          "note": "Thầy/Cô: A: Làm AI giúp mọi người."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "B: Giúp em cùng nhóm hiểu ba từ, có bảng từ để kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: B: Giúp em cùng nhóm hiểu ba từ, có bảng từ để kiểm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Vì sao B dễ lập kế hoạch hơn?",
          "tone": "action",
          "note": "Thầy/Cô: Vì sao B dễ lập kế hoạch hơn?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "08-05",
      "title": "Khám phá: so sánh ý tưởng",
      "note": {
        "activity": "Khám phá 2.1 So sánh và chọn ý tưởng",
        "purpose": "Chọn một ý tưởng theo nhu cầu và khả năng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm nêu một lí do chọn và một lí do bỏ ý còn lại.",
        "conclusion": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp.",
        "assessment": "Đạt khi có hai ý và lựa chọn có căn cứ. Giúp nhóm giảm quy mô nếu đòi công cụ trả phí/lập trình lớn.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "idea",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_5_20.jpg",
      "id": "08-06",
      "title": "Máy làm phần nào? Người làm phần nào?",
      "note": {
        "activity": "Khám phá 2.1 So sánh và chọn ý tưởng",
        "purpose": "Chọn một ý tưởng theo nhu cầu và khả năng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm nêu một lí do chọn và một lí do bỏ ý còn lại.",
        "conclusion": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp.",
        "assessment": "Đạt khi có hai ý và lựa chọn có căn cứ. Giúp nhóm giảm quy mô nếu đòi công cụ trả phí/lập trình lớn.",
        "answers": [
          "Con người xác định nhiệm vụ, kiểm tra và can thiệp khi kết quả chưa phù hợp.",
          "AI xử lí hình ảnh để hỗ trợ nhiệm vụ được thiết kế. Trong dự án nhỏ, cũng cần rõ phần AI làm và ai kiểm tra."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI nhận dữ liệu gì?\n2. Nói dễ hiểu: Con người kiểm tra và quyết định gì?\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Con người xác định nhiệm vụ, kiểm tra và can thiệp khi kết quả chưa phù hợp.\nAI xử lí hình ảnh để hỗ trợ nhiệm vụ được thiết kế. Trong dự án nhỏ, cũng cần rõ phần AI làm và ai kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "AI nhận dữ liệu gì?",
        "Con người kiểm tra và quyết định gì?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "AI nhận dữ liệu gì?",
        "Con người kiểm tra và quyết định gì?",
        "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI nhận dữ liệu gì?",
          "tone": "key",
          "note": "Thầy/Cô: AI nhận dữ liệu gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Con người kiểm tra và quyết định gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Con người kiểm tra và quyết định gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp."
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 5,
        "title": "AI: How Computer Vision Works",
        "start": 15,
        "end": 40,
        "poster": "frame_5_20.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/5LHEqBfj39mMaxu0jlpFBQ/e8c81cbd51865522b439643e03a24d53/videoplayback.mp4",
        "question": "AI giúp phần nào? Con người làm phần nào?",
        "local": "code-5.mp4"
      },
      "id": "08-07",
      "title": "Một ví dụ về người kết hợp với AI",
      "note": {
        "activity": "Khám phá 2.1 So sánh và chọn ý tưởng",
        "purpose": "Chọn một ý tưởng theo nhu cầu và khả năng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Nhóm nêu một lí do chọn và một lí do bỏ ý còn lại.",
        "conclusion": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp.",
        "assessment": "Đạt khi có hai ý và lựa chọn có căn cứ. Giúp nhóm giảm quy mô nếu đòi công cụ trả phí/lập trình lớn.",
        "answers": [
          "Con người xác định nhiệm vụ, kiểm tra và can thiệp khi kết quả chưa phù hợp.",
          "AI xử lí hình ảnh để hỗ trợ nhiệm vụ được thiết kế. Trong dự án nhỏ, cũng cần rõ phần AI làm và ai kiểm tra."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: Quan sát việc máy hỗ trợ. Tìm vai trò con người. Liên hệ một dự án nhỏ trong lớp.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "Con người xác định nhiệm vụ, kiểm tra và can thiệp khi kết quả chưa phù hợp.\nAI xử lí hình ảnh để hỗ trợ nhiệm vụ được thiết kế. Trong dự án nhỏ, cũng cần rõ phần AI làm và ai kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "fallback": "Con người chọn mục tiêu và kiểm kết quả. AI hỗ trợ một phần công việc theo tính năng cụ thể.",
      "v6": true,
      "screen": [
        "Quan sát việc máy hỗ trợ.",
        "Tìm vai trò con người.",
        "Liên hệ một dự án nhỏ trong lớp."
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 25 giây, em ghi một ví dụ vào vở."
      ],
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Quan sát việc máy hỗ trợ.",
        "Tìm vai trò con người.",
        "Liên hệ một dự án nhỏ trong lớp."
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "type": "concept",
      "id": "08-08",
      "title": "Ba điều làm ý tưởng rõ hơn",
      "note": {
        "activity": "Khám phá 2.1 So sánh và chọn ý tưởng",
        "purpose": "Chọn một ý tưởng theo nhu cầu và khả năng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm nêu một lí do chọn và một lí do bỏ ý còn lại.",
        "conclusion": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp.",
        "assessment": "Đạt khi có hai ý và lựa chọn có căn cứ. Giúp nhóm giảm quy mô nếu đòi công cụ trả phí/lập trình lớn.",
        "answers": [
          "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi. Không cần sản phẩm phức tạp."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Giúp học tiếng Anh là ý tưởng còn rộng.\n2. Nói dễ hiểu: Thu nhỏ: giúp em lớp 6 hiểu ba từ.\n3. Điều cần nhớ: Nêu AI giúp gì và nhóm kiểm bằng gì.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi. Không cần sản phẩm phức tạp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “hai ý tưởng để em bắt đầu”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ai cần giúp việc gì?",
        "AI nhận gì, hỗ trợ gì, trả gì?",
        "Con người kiểm tra và xử lí thế nào?"
      ],
      "phase": "Khám phá",
      "scene": "idea",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Ai cần giúp việc gì?",
        "AI nhận gì, hỗ trợ gì, trả gì?",
        "Con người kiểm tra và xử lí thế nào?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Giúp học tiếng Anh là ý tưởng còn rộng.",
          "tone": "key",
          "note": "Thầy/Cô: Giúp học tiếng Anh là ý tưởng còn rộng."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thu nhỏ: giúp em lớp 6 hiểu ba từ.",
          "tone": "explain",
          "note": "Thầy/Cô: Thu nhỏ: giúp em lớp 6 hiểu ba từ."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nêu AI giúp gì và nhóm kiểm bằng gì.",
          "tone": "action",
          "note": "Thầy/Cô: Nêu AI giúp gì và nhóm kiểm bằng gì."
        }
      ]
    },
    {
      "id": "08-v7-ideas1",
      "type": "guide",
      "title": "Hai ý tưởng để em bắt đầu",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Thẻ từ: hiểu ba từ, kiểm bằng bảng từ.",
        "Ảnh đồ vật: phân biệt Bút/Cốc, so vật thật.",
        "Em chọn ý có dữ liệu và cách kiểm."
      ],
      "scene": "topics",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Chọn một ý. Nói người dùng và cách kiểm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Thẻ từ: hiểu ba từ, kiểm bằng bảng từ. / Ảnh đồ vật: phân biệt Bút/Cốc, so vật thật. / Em chọn ý có dữ liệu và cách kiểm."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Hai ý tưởng để em bắt đầu.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Thẻ từ: hiểu ba từ, kiểm bằng bảng từ.\n2. Nói dễ hiểu: Ảnh đồ vật: phân biệt Bút/Cốc, so vật thật.\n3. Điều cần nhớ: Em chọn ý có dữ liệu và cách kiểm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Thẻ từ: hiểu ba từ, kiểm bằng bảng từ. / Ảnh đồ vật: phân biệt Bút/Cốc, so vật thật. / Em chọn ý có dữ liệu và cách kiểm.",
          "closing": "Thầy/Cô chốt: Em chọn ý có dữ liệu và cách kiểm.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “thêm hai ý tưởng vừa sức”."
        }
      },
      "guideTable": {
        "headers": [
          "Ý tưởng",
          "AI giúp",
          "Em kiểm"
        ],
        "rows": [
          [
            "Thẻ ba từ",
            "Gợi nghĩa",
            "So bảng từ"
          ],
          [
            "Bút/Cốc",
            "Gợi tên ảnh",
            "So vật thật"
          ]
        ],
        "label": "Ý tưởng mẫu; chưa chạy hệ thống."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 9,
      "originalTeachingPoints": [
        "Thẻ từ: hiểu ba từ, kiểm bằng bảng từ.",
        "Ảnh đồ vật: phân biệt Bút/Cốc, so vật thật.",
        "Em chọn ý có dữ liệu và cách kiểm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Thẻ từ: hiểu ba từ, kiểm bằng bảng từ.",
          "tone": "key",
          "note": "Thầy/Cô: Thẻ từ: hiểu ba từ, kiểm bằng bảng từ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh đồ vật: phân biệt Bút/Cốc, so vật thật.",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh đồ vật: phân biệt Bút/Cốc, so vật thật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em chọn ý có dữ liệu và cách kiểm.",
          "tone": "action",
          "note": "Thầy/Cô: Em chọn ý có dữ liệu và cách kiểm."
        }
      ]
    },
    {
      "id": "08-v7-ideas2",
      "type": "guide",
      "title": "Thêm hai ý tưởng vừa sức",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Áp phích: phân loại giấy và nhựa.",
        "Kịch bản: tìm lỗi trong câu trả lời Toán.",
        "Em chọn một việc nhỏ, kiểm được kết quả."
      ],
      "scene": "topics",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Chọn một ý. Nói người dùng và cách kiểm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Áp phích: phân loại giấy và nhựa. / Kịch bản: tìm lỗi trong câu trả lời Toán. / Em chọn một việc nhỏ, kiểm được kết quả."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Thêm hai ý tưởng vừa sức.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Áp phích: phân loại giấy và nhựa.\n2. Nói dễ hiểu: Kịch bản: tìm lỗi trong câu trả lời Toán.\n3. Điều cần nhớ: Em chọn một việc nhỏ, kiểm được kết quả.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Áp phích: phân loại giấy và nhựa. / Kịch bản: tìm lỗi trong câu trả lời Toán. / Em chọn một việc nhỏ, kiểm được kết quả.",
          "closing": "Thầy/Cô chốt: Em chọn một việc nhỏ, kiểm được kết quả.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "guideTable": {
        "headers": [
          "Ý tưởng",
          "AI giúp",
          "Em kiểm"
        ],
        "rows": [
          [
            "Giấy/Nhựa",
            "Gợi nhóm từ ảnh",
            "So đồ vật"
          ],
          [
            "Kiểm câu Toán",
            "Gợi lời giải",
            "Tính lại theo quy tắc"
          ]
        ],
        "label": "Ý tưởng mẫu; chưa chạy hệ thống."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 10,
      "originalTeachingPoints": [
        "Áp phích: phân loại giấy và nhựa.",
        "Kịch bản: tìm lỗi trong câu trả lời Toán.",
        "Em chọn một việc nhỏ, kiểm được kết quả."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Áp phích: phân loại giấy và nhựa.",
          "tone": "key",
          "note": "Thầy/Cô: Áp phích: phân loại giấy và nhựa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Kịch bản: tìm lỗi trong câu trả lời Toán.",
          "tone": "explain",
          "note": "Thầy/Cô: Kịch bản: tìm lỗi trong câu trả lời Toán."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em chọn một việc nhỏ, kiểm được kết quả.",
          "tone": "action",
          "note": "Thầy/Cô: Em chọn một việc nhỏ, kiểm được kết quả."
        }
      ]
    },
    {
      "id": "08-09-mau",
      "type": "worked",
      "v6": true,
      "title": "Bốn ý tưởng nhỏ để xem mẫu",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "topics",
      "worked": {
        "title": "Bốn ý tưởng nhỏ để xem mẫu",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Ý 1",
          "Ý 2",
          "Ý 3",
          "Ý 4",
          "Ý em muốn tìm hiểu"
        ],
        "values": [
          "Thẻ từ: giải nghĩa ba từ, có bảng kiểm",
          "Ảnh đồ vật: phân biệt Bút/Cốc",
          "Áp phích: phân loại giấy và nhựa",
          "Kịch bản: kiểm câu trả lời Toán 6",
          "Chọn một ý. Nói người dùng và cách kiểm"
        ],
        "why": [
          "Mỗi ý chỉ giải quyết một việc nhỏ.",
          "Nhóm cần chỉ cách kiểm kết quả.",
          "Chọn theo điều kiện đang có."
        ],
        "question": "Em chọn ý nào và kiểm kết quả bằng gì?",
        "scene": "Topics"
      },
      "targetId": "08-09",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Chọn một ý. Nói người dùng và cách kiểm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Ý 1: Thẻ từ: giải nghĩa ba từ, có bảng kiểm\nÝ 2: Ảnh đồ vật: phân biệt Bút/Cốc\nÝ 3: Áp phích: phân loại giấy và nhựa\nÝ 4: Kịch bản: kiểm câu trả lời Toán 6\nÝ em muốn tìm hiểu: Chọn một ý. Nói người dùng và cách kiểm"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em chọn một ý tưởng nhỏ để bắt đầu.\n2. Nói dễ hiểu: Ý tưởng nhỏ cần có người dùng và cách kiểm.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Ý 1: Thẻ từ: giải nghĩa ba từ, có bảng kiểm\nÝ 2: Ảnh đồ vật: phân biệt Bút/Cốc\nÝ 3: Áp phích: phân loại giấy và nhựa\nÝ 4: Kịch bản: kiểm câu trả lời Toán 6\nÝ em muốn tìm hiểu: Chọn một ý. Nói người dùng và cách kiểm",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em chọn một ý tưởng nhỏ để bắt đầu.",
          "tone": "key",
          "note": "Thầy/Cô: Em chọn một ý tưởng nhỏ để bắt đầu."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ý tưởng nhỏ cần có người dùng và cách kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: Ý tưởng nhỏ cần có người dùng và cách kiểm."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em chọn ý nào và kiểm kết quả bằng gì? Gợi ý: Chọn một ý. Nói người dùng và cách kiểm"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P8.1 So sánh hai ý tưởng",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Đạt khi so sánh hai ý dựa nhu cầu, dữ liệu, khả năng kiểm và điều kiện. Có thể chọn giải pháp chủ yếu dùng công cụ thông thường nếu giải thích rõ phần AI hữu ích. Không bắt ý tưởng phức tạp mới đạt."
        ],
        "pages": [
          {
            "title": "Mở lại hai ý tưởng đã chuẩn bị",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ý tưởng A: giúp ai làm việc gì?",
                "key": "08-09-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Mở lại hai ý tưởng đã chuẩn bị",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ý tưởng B: giúp ai làm việc gì?",
                "key": "08-09-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Mở lại hai ý tưởng đã chuẩn bị",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Thiết bị và thời gian của nhóm",
                "key": "08-09-v4-condition",
                "options": [
                  "Có thiết bị và thời gian phù hợp",
                  "Dùng thiết bị chung, cần chia lượt",
                  "Làm nội dung giấy trước, cần GV hỗ trợ số"
                ],
                "optionLabels": [
                  "Có thiết bị và thời gian phù hợp",
                  "Dùng thiết bị chung, cần chia lượt",
                  "Làm nội dung giấy trước, cần Thầy/Cô hỗ trợ số"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Mở lại hai ý tưởng đã chuẩn bị",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Hình thức có thể thực hiện",
                "key": "08-09-v4-format",
                "options": [
                  "Áp phích",
                  "Vài slide",
                  "Kịch bản hình",
                  "Video",
                  "Mô hình đơn giản"
                ],
                "optionLabels": [
                  "Áp phích",
                  "Vài slide",
                  "Kịch bản hình",
                  "Video",
                  "Mô hình đơn giản"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "So sánh rồi chọn một ý",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm chọn ý nào?",
                "key": "08-09-v4-choice",
                "options": [
                  "A",
                  "B"
                ],
                "optionLabels": [
                  "A",
                  "B"
                ]
              }
            ],
            "originalPage": 1
          },
          {
            "title": "So sánh rồi chọn một ý",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vì sao chọn? Cần thu hẹp gì?",
                "key": "08-09-v4-reason"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "So sánh rồi chọn một ý",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần so sánh",
              "Ý tưởng A",
              "Ý tưởng B"
            ],
            "rows": [
              [
                "AI hỗ trợ gì? Dữ liệu nào?",
                {
                  "label": "AI và dữ liệu — A",
                  "key": "08-09-v4-ad"
                },
                {
                  "label": "AI và dữ liệu — B",
                  "key": "08-09-v4-bd"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "So sánh rồi chọn một ý",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần so sánh",
              "Ý tưởng A",
              "Ý tưởng B"
            ],
            "rows": [
              [
                "Kiểm kết quả bằng gì?",
                {
                  "label": "Cách kiểm — A",
                  "key": "08-09-v3-6"
                },
                {
                  "label": "Cách kiểm — B",
                  "key": "08-09-v3-7"
                }
              ]
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4
        }
      },
      "time": 5,
      "id": "08-09",
      "title": "P8.1 — So hai ý tưởng trước khi chọn",
      "note": {
        "activity": "Khám phá 2.1 So sánh và chọn ý tưởng",
        "purpose": "Hoàn thành đặt hai ý tưởng cạnh nhau theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm nêu một lí do chọn và một lí do bỏ ý còn lại.",
        "conclusion": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Đạt khi so sánh hai ý dựa nhu cầu, dữ liệu, khả năng kiểm và điều kiện. Có thể chọn giải pháp chủ yếu dùng công cụ thông thường nếu giải thích rõ phần AI hữu ích. Không bắt ý tưởng phức tạp mới đạt."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Ghi hai ý và điều kiện nhóm. So chức năng, dữ liệu và cách kiểm. Chọn A hoặc B, nêu lí do.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Đạt khi so sánh hai ý dựa nhu cầu, dữ liệu, khả năng kiểm và điều kiện. Có thể chọn giải pháp chủ yếu dùng công cụ thông thường nếu giải thích rõ phần AI hữu ích. Không bắt ý tưởng phức tạp mới đạt.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em so kết quả để rút ra điều có căn cứ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi hai ý và điều kiện nhóm.",
        "So chức năng, dữ liệu và cách kiểm.",
        "Chọn A hoặc B, nêu lí do."
      ],
      "phase": "Khám phá",
      "scene": "idea",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "08-09-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi hai ý và điều kiện nhóm.",
        "So chức năng, dữ liệu và cách kiểm.",
        "Chọn A hoặc B, nêu lí do."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P8.1 · So hai ý tưởng"
    },
    {
      "type": "conclusion",
      "id": "08-10",
      "title": "Chọn việc nhỏ, kiểm được",
      "note": {
        "activity": "Khám phá 2.1 So sánh và chọn ý tưởng",
        "purpose": "Chọn một ý tưởng theo nhu cầu và khả năng.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm nêu một lí do chọn và một lí do bỏ ý còn lại.",
        "conclusion": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi; không cần sản phẩm phức tạp.",
        "assessment": "Đạt khi có hai ý và lựa chọn có căn cứ. Giúp nhóm giảm quy mô nếu đòi công cụ trả phí/lập trình lớn.",
        "answers": [
          "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi. Không cần sản phẩm phức tạp."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em so kết quả để rút ra điều có căn cứ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nêu rõ người dùng.\n2. Nói dễ hiểu: Giữ phạm vi vừa sức.\n3. Điều cần nhớ: Có cách kiểm tra kết quả.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Giải pháp phù hợp cần làm rõ phần AI và tính khả thi. Không cần sản phẩm phức tạp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nêu rõ người dùng.",
        "Giữ phạm vi vừa sức.",
        "Có cách kiểm tra kết quả."
      ],
      "phase": "Khám phá",
      "scene": "idea",
      "taskLines": [
        "Trong 30 giây, em nêu một căn cứ tại chỗ."
      ],
      "connector": "Em so kết quả để rút ra điều có căn cứ.",
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [
        "Nêu rõ người dùng.",
        "Giữ phạm vi vừa sức.",
        "Có cách kiểm tra kết quả."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nêu rõ người dùng.",
          "tone": "key",
          "note": "Thầy/Cô: Nêu rõ người dùng."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Giữ phạm vi vừa sức.",
          "tone": "explain",
          "note": "Thầy/Cô: Giữ phạm vi vừa sức."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Có cách kiểm tra kết quả.",
          "tone": "action",
          "note": "Thầy/Cô: Có cách kiểm tra kết quả."
        }
      ]
    },
    {
      "type": "divider",
      "id": "08-11",
      "title": "Thực hành: phác thảo dự án",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “viết mục tiêu bằng một câu”."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "08-v7-formula",
      "type": "guide",
      "title": "Viết mục tiêu bằng một câu",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Giúp [ai] giải quyết [việc gì] bằng [AI làm gì].",
        "Giúp em lớp 6 hiểu ba từ bằng gợi nghĩa.",
        "Nhóm em kiểm nghĩa bằng bảng từ."
      ],
      "scene": "topics",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Hỏi Thầy/Cô trước khi dùng nghĩa đó",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Giúp [ai] giải quyết [việc gì] bằng [AI làm gì]. / Giúp em lớp 6 hiểu ba từ bằng gợi nghĩa. / Nhóm em kiểm nghĩa bằng bảng từ."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Viết mục tiêu bằng một câu.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Giúp [ai] giải quyết [việc gì] bằng [AI làm gì].\n2. Nói dễ hiểu: Giúp em lớp 6 hiểu ba từ bằng gợi nghĩa.\n3. Điều cần nhớ: Nhóm em kiểm nghĩa bằng bảng từ.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Giúp [ai] giải quyết [việc gì] bằng [AI làm gì]. / Giúp em lớp 6 hiểu ba từ bằng gợi nghĩa. / Nhóm em kiểm nghĩa bằng bảng từ.",
          "closing": "Thầy/Cô chốt: Nhóm em kiểm nghĩa bằng bảng từ.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "number": 15,
      "originalTeachingPoints": [
        "Giúp [ai] giải quyết [việc gì] bằng [AI làm gì].",
        "Giúp em lớp 6 hiểu ba từ bằng gợi nghĩa.",
        "Nhóm em kiểm nghĩa bằng bảng từ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Giúp [ai] giải quyết [việc gì] bằng [AI làm gì].",
          "tone": "key",
          "note": "Thầy/Cô: Giúp [ai] giải quyết [việc gì] bằng [AI làm gì]."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Giúp em lớp 6 hiểu ba từ bằng gợi nghĩa.",
          "tone": "explain",
          "note": "Thầy/Cô: Giúp em lớp 6 hiểu ba từ bằng gợi nghĩa."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nhóm em kiểm nghĩa bằng bảng từ.",
          "tone": "action",
          "note": "Thầy/Cô: Nhóm em kiểm nghĩa bằng bảng từ."
        }
      ]
    },
    {
      "id": "08-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu một ý tưởng đã điền",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "worked": {
        "title": "Mẫu một ý tưởng đã điền",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Người dùng và mục tiêu",
          "Đầu vào và AI hỗ trợ",
          "Kết quả và người kiểm",
          "Giới hạn và hình thức",
          "Khi chưa rõ nghĩa"
        ],
        "values": [
          "Em lớp 6. Hiểu ba từ trong bài học",
          "Ba từ. AI gợi nghĩa và ví dụ",
          "Thẻ từ. Các em kiểm bằng bảng từ",
          "Áp phích ý tưởng. Không thu tên, địa chỉ",
          "Hỏi Thầy/Cô trước khi dùng nghĩa đó"
        ],
        "why": [
          "Mục tiêu nhỏ giúp biết lúc hoàn thành.",
          "AI gợi ý. Em vẫn kiểm nghĩa.",
          "Áp phích không phải mô hình đã chạy."
        ],
        "question": "Khi bảng từ chưa đủ, nhóm nên làm gì?",
        "scene": "Idea"
      },
      "targetId": "08-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Hỏi Thầy/Cô trước khi dùng nghĩa đó",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Người dùng và mục tiêu: Em lớp 6. Hiểu ba từ trong bài học\nĐầu vào và AI hỗ trợ: Ba từ. AI gợi nghĩa và ví dụ\nKết quả và người kiểm: Thẻ từ. Các em kiểm bằng bảng từ\nGiới hạn và hình thức: Áp phích ý tưởng. Không thu tên, địa chỉ\nKhi chưa rõ nghĩa: Hỏi Thầy/Cô trước khi dùng nghĩa đó"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dự án: Ba từ tiếng Anh mỗi ngày.\n2. Nói dễ hiểu: AI gợi nghĩa; nhóm em đối chiếu bằng bảng từ.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Người dùng và mục tiêu: Em lớp 6. Hiểu ba từ trong bài học\nĐầu vào và AI hỗ trợ: Ba từ. AI gợi nghĩa và ví dụ\nKết quả và người kiểm: Thẻ từ. Các em kiểm bằng bảng từ\nGiới hạn và hình thức: Áp phích ý tưởng. Không thu tên, địa chỉ\nKhi chưa rõ nghĩa: Hỏi Thầy/Cô trước khi dùng nghĩa đó",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dự án: Ba từ tiếng Anh mỗi ngày.",
          "tone": "key",
          "note": "Thầy/Cô: Dự án: Ba từ tiếng Anh mỗi ngày."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI gợi nghĩa; nhóm em đối chiếu bằng bảng từ.",
          "tone": "explain",
          "note": "Thầy/Cô: AI gợi nghĩa; nhóm em đối chiếu bằng bảng từ."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Khi bảng từ chưa đủ, nhóm nên làm gì? Gợi ý: Hỏi Thầy/Cô trước khi dùng nghĩa đó"
        }
      ]
    },
    {
      "type": "task",
      "id": "08-12",
      "title": "Làm rõ ý tưởng đã chọn",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm phần được giao; ghi kết quả thật.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [
          "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dùng lại ý từ P8.1.\n2. Nói dễ hiểu: Bổ sung phần còn thiếu.\n3. Điều cần nhớ: Phác thảo sản phẩm ở P8.2.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em làm phần được giao; ghi kết quả thật.",
          "answer": "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Ý đã chọn cần có người dùng và mục tiêu rõ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dùng lại ý từ P8.1.",
        "Bổ sung phần còn thiếu.",
        "Phác thảo sản phẩm ở P8.2."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 11 phút, nhóm em phác thảo ý tưởng trên phiếu."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "08-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Dùng lại ý từ P8.1.",
        "Bổ sung phần còn thiếu.",
        "Phác thảo sản phẩm ở P8.2."
      ],
      "pupilTask": "Em làm phần được giao; ghi kết quả thật.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dùng lại ý từ P8.1.",
          "tone": "key",
          "note": "Thầy/Cô: Dùng lại ý từ P8.1."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bổ sung phần còn thiếu.",
          "tone": "explain",
          "note": "Thầy/Cô: Bổ sung phần còn thiếu."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Phác thảo sản phẩm ở P8.2.",
          "tone": "action",
          "note": "Thầy/Cô: Phác thảo sản phẩm ở P8.2."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 0,
      "id": "08-13",
      "title": "Bước 1 — Viết mục tiêu cụ thể",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [
          "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Ý đã chọn cần có người dùng và mục tiêu rõ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ai cần giúp?\n2. Nói dễ hiểu: Cần giải quyết việc gì?\n3. Điều cần nhớ: Dấu hiệu nào cho biết đã xong?",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Mục tiêu rõ giúp em chọn dữ liệu cần dùng."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ai cần giúp?",
        "Cần giải quyết việc gì?",
        "Dấu hiệu nào cho biết đã xong?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên phiếu."
      ],
      "connector": "Ý đã chọn cần có người dùng và mục tiêu rõ.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Ai cần giúp?",
        "Cần giải quyết việc gì?",
        "Dấu hiệu nào cho biết đã xong?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ai cần giúp?",
          "tone": "key",
          "note": "Thầy/Cô: Ai cần giúp?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Cần giải quyết việc gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Cần giải quyết việc gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Dấu hiệu nào cho biết đã xong?",
          "tone": "action",
          "note": "Thầy/Cô: Dấu hiệu nào cho biết đã xong?"
        }
      ]
    },
    {
      "type": "step",
      "step": 2,
      "time": 0,
      "id": "08-14",
      "title": "Bước 2 — Chọn dữ liệu cần dùng",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [
          "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Mục tiêu rõ giúp em chọn dữ liệu cần dùng.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dữ liệu đầu vào là gì?\n2. Nói dễ hiểu: AI hỗ trợ thao tác nào?\n3. Điều cần nhớ: Thông tin nào không cần thu?",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Có đầu vào rồi, em xác định đầu ra và người kiểm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dữ liệu đầu vào là gì?",
        "AI hỗ trợ thao tác nào?",
        "Thông tin nào không cần thu?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên phiếu."
      ],
      "connector": "Mục tiêu rõ giúp em chọn dữ liệu cần dùng.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "Dữ liệu đầu vào là gì?",
        "AI hỗ trợ thao tác nào?",
        "Thông tin nào không cần thu?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dữ liệu đầu vào là gì?",
          "tone": "key",
          "note": "Thầy/Cô: Dữ liệu đầu vào là gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI hỗ trợ thao tác nào?",
          "tone": "explain",
          "note": "Thầy/Cô: AI hỗ trợ thao tác nào?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Thông tin nào không cần thu?",
          "tone": "action",
          "note": "Thầy/Cô: Thông tin nào không cần thu?"
        }
      ]
    },
    {
      "type": "step",
      "step": 3,
      "time": 0,
      "id": "08-15",
      "title": "Bước 3 — Xác định cách kiểm",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [
          "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Có đầu vào rồi, em xác định đầu ra và người kiểm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI trả loại kết quả gì?\n2. Nói dễ hiểu: Ai kiểm bằng nguồn nào?\n3. Điều cần nhớ: Nếu chưa phù hợp, làm gì?",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Cách kiểm đã rõ. Em chọn hình thức vừa sức."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "AI trả loại kết quả gì?",
        "Ai kiểm bằng nguồn nào?",
        "Nếu chưa phù hợp, làm gì?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên phiếu."
      ],
      "connector": "Có đầu vào rồi, em xác định đầu ra và người kiểm.",
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [
        "AI trả loại kết quả gì?",
        "Ai kiểm bằng nguồn nào?",
        "Nếu chưa phù hợp, làm gì?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI trả loại kết quả gì?",
          "tone": "key",
          "note": "Thầy/Cô: AI trả loại kết quả gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ai kiểm bằng nguồn nào?",
          "tone": "explain",
          "note": "Thầy/Cô: Ai kiểm bằng nguồn nào?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nếu chưa phù hợp, làm gì?",
          "tone": "action",
          "note": "Thầy/Cô: Nếu chưa phù hợp, làm gì?"
        }
      ]
    },
    {
      "type": "step",
      "step": 4,
      "time": 0,
      "id": "08-16",
      "title": "Bước 4 — Chọn sản phẩm vừa sức",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [
          "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Cách kiểm đã rõ. Em chọn hình thức vừa sức.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Áp phích, slide, kịch bản hoặc mô hình.\n2. Nói dễ hiểu: Chọn theo thời gian và thiết bị.\n3. Điều cần nhớ: Ghi đúng mức đã làm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Áp phích, slide, kịch bản hoặc mô hình.",
        "Chọn theo thời gian và thiết bị.",
        "Ghi đúng mức đã làm."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên phiếu."
      ],
      "connector": "Cách kiểm đã rõ. Em chọn hình thức vừa sức.",
      "number": 21,
      "v7": true,
      "originalTeachingPoints": [
        "Áp phích, slide, kịch bản hoặc mô hình.",
        "Chọn theo thời gian và thiết bị.",
        "Ghi đúng mức đã làm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Áp phích, slide, kịch bản hoặc mô hình.",
          "tone": "key",
          "note": "Thầy/Cô: Áp phích, slide, kịch bản hoặc mô hình."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chọn theo thời gian và thiết bị.",
          "tone": "explain",
          "note": "Thầy/Cô: Chọn theo thời gian và thiết bị."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi đúng mức đã làm.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi đúng mức đã làm."
        }
      ]
    },
    {
      "id": "08-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu đọc một phiếu ý tưởng đủ ý",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "worked": {
        "title": "Mẫu đọc một phiếu ý tưởng đủ ý",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Nhu cầu / người dùng",
          "Mục tiêu / dữ liệu",
          "AI làm / kết quả",
          "Người kiểm / giới hạn",
          "Bố cục và nguồn"
        ],
        "values": [
          "Giúp em lớp 6 hiểu từ trong bài",
          "Ba từ. Chỉ nhận nội dung từ cần hỏi",
          "Gợi nghĩa và câu ví dụ. Tạo thẻ từ",
          "Kiểm bảng từ. Hỏi Thầy/Cô khi chưa rõ",
          "Đặt ví dụ và bảng từ cạnh thẻ. Ghi nguồn"
        ],
        "why": [
          "Mỗi mục trả lời một câu hỏi cụ thể.",
          "Nguồn kiểm phải nằm trong bản thiết kế.",
          "Bài nhóm cần dùng nhu cầu của nhóm."
        ],
        "question": "Em đặt ví dụ và nguồn ở đâu để dễ kiểm?",
        "scene": "Idea"
      },
      "targetId": "08-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Đặt ví dụ và bảng từ cạnh thẻ. Ghi nguồn",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Nhu cầu / người dùng: Giúp em lớp 6 hiểu từ trong bài\nMục tiêu / dữ liệu: Ba từ. Chỉ nhận nội dung từ cần hỏi\nAI làm / kết quả: Gợi nghĩa và câu ví dụ. Tạo thẻ từ\nNgười kiểm / giới hạn: Kiểm bảng từ. Hỏi Thầy/Cô khi chưa rõ\nBố cục và nguồn: Đặt ví dụ và bảng từ cạnh thẻ. Ghi nguồn"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm phác thảo thẻ ba từ, chưa chạy AI.\n2. Nói dễ hiểu: Bản ý tưởng nêu cách làm, chưa phải AI đã chạy.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Nhu cầu / người dùng: Giúp em lớp 6 hiểu từ trong bài\nMục tiêu / dữ liệu: Ba từ. Chỉ nhận nội dung từ cần hỏi\nAI làm / kết quả: Gợi nghĩa và câu ví dụ. Tạo thẻ từ\nNgười kiểm / giới hạn: Kiểm bảng từ. Hỏi Thầy/Cô khi chưa rõ\nBố cục và nguồn: Đặt ví dụ và bảng từ cạnh thẻ. Ghi nguồn",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm phác thảo thẻ ba từ, chưa chạy AI.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm phác thảo thẻ ba từ, chưa chạy AI."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bản ý tưởng nêu cách làm, chưa phải AI đã chạy.",
          "tone": "explain",
          "note": "Thầy/Cô: Bản ý tưởng nêu cách làm, chưa phải AI đã chạy."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em đặt ví dụ và nguồn ở đâu để dễ kiểm? Gợi ý: Đặt ví dụ và bảng từ cạnh thẻ. Ghi nguồn"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P8.2 Phiếu ý tưởng dự án",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Ví dụ: học sinh cần hiểu ba từ hướng dẫn tiếng Anh. AI gợi ý nghĩa. Người đối chiếu bảng từ/SGK và hỏi Thầy/Cô khi chưa chắc. Không thu tên/địa chỉ. Poster mô tả ý tưởng.",
          "Thiếu bước con người kiểm tra hoặc dữ liệu đầu vào không phù hợp thì cần sửa. Không đánh giá mô hình chạy thật nếu chỉ có sơ đồ."
        ],
        "pages": [
          {
            "title": "Làm rõ ý tưởng — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm muốn giải quyết việc gì?",
                "key": "08-17-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Làm rõ ý tưởng — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai sẽ sử dụng?",
                "key": "08-17-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Làm rõ ý tưởng — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Làm được điều gì thì coi là hoàn thành?",
                "key": "08-17-v3-2"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Làm rõ ý tưởng — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Dữ liệu nào được đưa vào?",
                "key": "08-17-v3-3"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Làm rõ ý tưởng — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "AI sẽ hỗ trợ làm gì?",
                "key": "08-17-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Làm rõ ý tưởng — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Người dùng nhận kết quả gì?",
                "key": "08-17-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Làm rõ ý tưởng — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Con người làm và kiểm tra phần nào?",
                "key": "08-17-v3-6"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Làm rõ ý tưởng — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nếu kết quả sai hoặc chưa rõ, sẽ xử lí thế nào?",
                "key": "08-17-v3-7"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Làm rõ ý tưởng — bước 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Những thông tin cá nhân nào không cần thu thập?",
                "key": "08-17-v3-8"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Làm rõ ý tưởng — bước 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm chọn hình thức sản phẩm nào?",
                "key": "08-17-v3-9"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Chọn hình thức phù hợp. Có thể làm áp phích, slide, kịch bản, video hoặc mô hình.",
            "originalPage": 3,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Ghi rõ nếu mới là ý tưởng minh họa.",
            "originalPage": 3,
            "referenceOnly": true
          },
          {
            "title": "Phác thảo sản phẩm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Sơ đồ: dữ liệu → AI → kết quả → người kiểm",
                "key": "08-17-v3-10"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Phác thảo sản phẩm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vị trí ví dụ, nguồn và cách kiểm",
                "key": "08-17-v3-11"
              }
            ],
            "originalPage": 3
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4,
          "2": 8,
          "3": 10
        }
      },
      "time": 16,
      "id": "08-17",
      "title": "P8.2 — Từ ý tưởng đến phác thảo",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Hoàn thành phiếu ý tưởng dự án theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Ví dụ: học sinh cần hiểu ba từ hướng dẫn tiếng Anh. AI gợi ý nghĩa. Người đối chiếu bảng từ/SGK và hỏi Thầy/Cô khi chưa chắc. Không thu tên/địa chỉ. Poster mô tả ý tưởng.",
          "Thiếu bước con người kiểm tra hoặc dữ liệu đầu vào không phù hợp thì cần sửa. Không đánh giá mô hình chạy thật nếu chỉ có sơ đồ."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Bản ý tưởng là bản nháp, có thể dùng lại và chỉnh tiếp. Không yêu cầu các em điền cùng thông tin ở nhiều phiếu như những sản phẩm độc lập.\nÝ cần giảng rõ: Dùng lại dữ liệu đã chọn. Bổ sung đầu vào, đầu ra và cách kiểm. Vẽ bố cục sản phẩm.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Ví dụ: học sinh cần hiểu ba từ hướng dẫn tiếng Anh. AI gợi ý nghĩa. Người đối chiếu bảng từ/SGK và hỏi Thầy/Cô khi chưa chắc. Không thu tên/địa chỉ. Poster mô tả ý tưởng.\nThiếu bước con người kiểm tra hoặc dữ liệu đầu vào không phù hợp thì cần sửa. Không đánh giá mô hình chạy thật nếu chỉ có sơ đồ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "reuseKind": "idea",
      "v6": true,
      "screen": [
        "Dùng lại dữ liệu đã chọn.",
        "Bổ sung đầu vào, đầu ra và cách kiểm.",
        "Vẽ bố cục sản phẩm."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "08-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [
        "Dùng lại dữ liệu đã chọn.",
        "Bổ sung đầu vào, đầu ra và cách kiểm.",
        "Vẽ bố cục sản phẩm."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P8.2 · Phác thảo dự án"
    },
    {
      "type": "report",
      "id": "08-18",
      "title": "Em cùng nhóm có hiểu ý tưởng của nhóm?",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [
          "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em cùng nhóm nghĩ sản phẩm giúp ai?\n2. Nói dễ hiểu: AI làm gì, người kiểm gì?\n3. Điều cần nhớ: Chỗ nào còn chưa rõ?",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Em cùng nhóm nghĩ sản phẩm giúp ai?",
        "AI làm gì, người kiểm gì?",
        "Chỗ nào còn chưa rõ?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [
        "Em cùng nhóm nghĩ sản phẩm giúp ai?",
        "AI làm gì, người kiểm gì?",
        "Chỗ nào còn chưa rõ?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em cùng nhóm nghĩ sản phẩm giúp ai?",
          "tone": "key",
          "note": "Thầy/Cô: Em cùng nhóm nghĩ sản phẩm giúp ai?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI làm gì, người kiểm gì?",
          "tone": "explain",
          "note": "Thầy/Cô: AI làm gì, người kiểm gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chỗ nào còn chưa rõ?",
          "tone": "action",
          "note": "Thầy/Cô: Chỗ nào còn chưa rõ?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "08-20",
      "title": "Luyện tập: tự giải thích dự án",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Kiểm tra mức hiểu của từng thành viên về dự án.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Mời thành viên không phải người báo cáo mô tả một chức năng.",
        "conclusion": "Mỗi thành viên cần giải thích được ý tưởng, không chỉ hoàn thành phần trang trí.",
        "assessment": "Dùng câu trả lời để xác định các em cần hỗ trợ trước giai đoạn 1.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "08-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu một em giải thích dự án",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "worked": {
        "title": "Mẫu một em giải thích dự án",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Giúp ai",
          "Giúp việc gì",
          "AI làm gì",
          "Con người làm gì",
          "Giới hạn"
        ],
        "values": [
          "Em lớp 6",
          "Hiểu ba từ trong bài",
          "Gợi nghĩa và ví dụ",
          "So bảng từ, hỏi Thầy/Cô khi chưa rõ",
          "Chưa bảo đảm đúng mọi câu khác"
        ],
        "why": [
          "Mỗi em hiểu cùng một dự án.",
          "Không chỉ học tên sản phẩm.",
          "Nêu điều sản phẩm chưa chứng minh."
        ],
        "question": "Em sẽ nói giới hạn thế nào?",
        "scene": "Idea"
      },
      "targetId": "08-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Chưa bảo đảm đúng mọi câu khác",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Giúp ai: Em lớp 6\nGiúp việc gì: Hiểu ba từ trong bài\nAI làm gì: Gợi nghĩa và ví dụ\nCon người làm gì: So bảng từ, hỏi Thầy/Cô khi chưa rõ\nGiới hạn: Chưa bảo đảm đúng mọi câu khác"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em giải thích dự án cho người chưa biết.\n2. Nói dễ hiểu: Người nghe cần hiểu cả việc AI và người làm.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Giúp ai: Em lớp 6\nGiúp việc gì: Hiểu ba từ trong bài\nAI làm gì: Gợi nghĩa và ví dụ\nCon người làm gì: So bảng từ, hỏi Thầy/Cô khi chưa rõ\nGiới hạn: Chưa bảo đảm đúng mọi câu khác",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em giải thích dự án cho người chưa biết.",
          "tone": "key",
          "note": "Thầy/Cô: Em giải thích dự án cho người chưa biết."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Người nghe cần hiểu cả việc AI và người làm.",
          "tone": "explain",
          "note": "Thầy/Cô: Người nghe cần hiểu cả việc AI và người làm."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em sẽ nói giới hạn thế nào? Gợi ý: Chưa bảo đảm đúng mọi câu khác"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P8.3 Hiểu ý tưởng và bàn giao",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "A Câu trả lời phải phù hợp P8.2 và thể hiện mức hiểu riêng. Nếu khác nhau, nhóm thống nhất lại chức năng."
        ],
        "pages": [
          {
            "title": "Mỗi thành viên tự giải thích",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Người dùng của dự án là ai?",
                "key": "08-21-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Mỗi thành viên tự giải thích",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "AI nhận dữ liệu gì và hỗ trợ tạo kết quả gì?",
                "key": "08-21-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Mỗi thành viên tự giải thích",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai kiểm tra kết quả và kiểm tra bằng gì?",
                "key": "08-21-v3-2"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 4,
      "id": "08-21",
      "title": "P8.3A — Tự giải thích dự án",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành mỗi thành viên hiểu dự án chưa? theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Mời thành viên không phải người báo cáo mô tả một chức năng.",
        "conclusion": "Mỗi thành viên cần giải thích được ý tưởng, không chỉ hoàn thành phần trang trí.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "A Câu trả lời phải phù hợp P8.2 và thể hiện mức hiểu riêng. Nếu khác nhau, nhóm thống nhất lại chức năng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Dự án giúp ai? AI hỗ trợ phần nào? Con người kiểm ra sao?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "A Câu trả lời phải phù hợp P8.2 và thể hiện mức hiểu riêng. Nếu khác nhau, nhóm thống nhất lại chức năng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dự án giúp ai?",
        "AI hỗ trợ phần nào?",
        "Con người kiểm ra sao?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "08-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [
        "Dự án giúp ai?",
        "AI hỗ trợ phần nào?",
        "Con người kiểm ra sao?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P8.3A · Em tự làm"
    },
    {
      "type": "recap",
      "id": "08-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Thiết kế phiếu ý tưởng dự án",
        "purpose": "Mô tả rõ quan hệ con người và AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Hai nhóm đổi phiếu và nêu một điểm rõ, một câu hỏi cần làm rõ.",
        "conclusion": "AI hỗ trợ một phần công việc; con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
        "assessment": "Kiểm tra đủ vấn đề/người dùng/chức năng/kiểm tra. Thiếu phần con người thì yêu cầu sửa trước khi làm ở nhà.",
        "answers": [
          "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chọn một nhu cầu nhỏ, người dùng rõ.\n2. Nói dễ hiểu: Tách việc AI và việc con người.\n3. Điều cần nhớ: Chọn hình thức vừa sức, ghi đúng mức đã làm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ một phần công việc. Con người xác định mục đích, kiểm tra và quyết định. Sản phẩm mô tả phải ghi là ý tưởng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn một nhu cầu nhỏ, người dùng rõ.",
        "Tách việc AI và việc con người.",
        "Chọn hình thức vừa sức, ghi đúng mức đã làm."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn một nhu cầu nhỏ, người dùng rõ.",
        "Tách việc AI và việc con người.",
        "Chọn hình thức vừa sức, ghi đúng mức đã làm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chọn một nhu cầu nhỏ, người dùng rõ.",
          "tone": "key",
          "note": "Thầy/Cô: Chọn một nhu cầu nhỏ, người dùng rõ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tách việc AI và việc con người.",
          "tone": "explain",
          "note": "Thầy/Cô: Tách việc AI và việc con người."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chọn hình thức vừa sức, ghi đúng mức đã làm.",
          "tone": "action",
          "note": "Thầy/Cô: Chọn hình thức vừa sức, ghi đúng mức đã làm."
        }
      ]
    },
    {
      "type": "divider",
      "id": "08-22",
      "title": "Vận dụng: chuẩn bị dự án tại nhà",
      "note": {
        "activity": "Vận dụng và chuyển giao dự án",
        "purpose": "Hiểu bốn mốc tại nhà và điều kiện nộp.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Đại diện nhắc lại bốn mốc, một HS nêu cách hỏi khi gặp khó.",
        "conclusion": "Tại nhà sẽ hoàn thiện một dự án liên tục; không phải bốn dự án và không có tiết báo cáo thứ 13.",
        "assessment": "Chỉ giao khi nhóm biết đầu ra giai đoạn 1, cách nhận phản hồi và lựa chọn khi thiếu thiết bị.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "idea",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "08-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu đọc bốn giai đoạn dự án",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "roadmap",
      "worked": {
        "title": "Mẫu đọc bốn giai đoạn dự án",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Giai đoạn 1",
          "Giai đoạn 2",
          "Giai đoạn 3",
          "Giai đoạn 4",
          "Trước khi bắt đầu"
        ],
        "values": [
          "Chốt việc và phân công",
          "Tìm nguồn, vẽ cách hoạt động",
          "Làm bản 1, ghi nguồn và việc từng em",
          "Sửa, giới thiệu, kiểm rồi nộp",
          "Đọc tiêu chí, hỏi mốc và kênh nộp"
        ],
        "why": [
          "Không chọn bốn đề tài khác nhau.",
          "Mỗi chặng dùng lại bản trước.",
          "Lịch thật theo Thầy/Cô thông báo."
        ],
        "question": "Nhóm cần xem gì trước khi làm?",
        "scene": "Roadmap"
      },
      "targetId": "08-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Đọc tiêu chí, hỏi mốc và kênh nộp",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Giai đoạn 1: Chốt việc và phân công\nGiai đoạn 2: Tìm nguồn, vẽ cách hoạt động\nGiai đoạn 3: Làm bản 1, ghi nguồn và việc từng em\nGiai đoạn 4: Sửa, giới thiệu, kiểm rồi nộp\nTrước khi bắt đầu: Đọc tiêu chí, hỏi mốc và kênh nộp"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm chuẩn bị dự án qua bốn giai đoạn.\n2. Nói dễ hiểu: Bốn giai đoạn là bốn phần việc nối tiếp nhau.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Giai đoạn 1: Chốt việc và phân công\nGiai đoạn 2: Tìm nguồn, vẽ cách hoạt động\nGiai đoạn 3: Làm bản 1, ghi nguồn và việc từng em\nGiai đoạn 4: Sửa, giới thiệu, kiểm rồi nộp\nTrước khi bắt đầu: Đọc tiêu chí, hỏi mốc và kênh nộp",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 30,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm chuẩn bị dự án qua bốn giai đoạn.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm chuẩn bị dự án qua bốn giai đoạn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bốn giai đoạn là bốn phần việc nối tiếp nhau.",
          "tone": "explain",
          "note": "Thầy/Cô: Bốn giai đoạn là bốn phần việc nối tiếp nhau."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Nhóm cần xem gì trước khi làm? Gợi ý: Đọc tiêu chí, hỏi mốc và kênh nộp"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P8.3 Hiểu ý tưởng và bàn giao",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Thống nhất hình thức có thể làm, cách hỗ trợ và đầu ra giai đoạn 1. Ngày và kênh nộp do Thầy/Cô thông báo.",
          "Bấm Chiếu tiêu chí dự án để đọc đủ năm tiêu chí và mô tả mức 0–2 trước khi làm. Mỗi giai đoạn tiếp tục cùng một dự án."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "1. Chọn vấn đề, lập kế hoạch. 2. Tìm nguồn, vẽ thiết kế. 3. Làm sản phẩm bản đầu. 4.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Nhận góp ý, hoàn thiện và nộp.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Chọn hình thức và cách hỗ trợ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm chọn hình thức sản phẩm nào?",
                "key": "08-23-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn hình thức và cách hỗ trợ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Khi thiếu thiết bị, nhóm sẽ nhờ ai hỗ trợ?",
                "key": "08-23-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Thống nhất phần việc và lịch",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Phần việc đầu tiên của từng thành viên là gì?",
                "key": "08-23-v3-2"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Thống nhất phần việc và lịch",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Lịch và kênh nộp Thầy/Cô đã thông báo là gì?",
                "key": "08-23-v3-3"
              }
            ],
            "originalPage": 1
          }
        ],
        "rubricAccess": true,
        "v7PageMap": {
          "0": 0,
          "1": 4
        }
      },
      "time": 3,
      "id": "08-23",
      "title": "P8.3B — Biết đích trước khi làm",
      "note": {
        "activity": "Vận dụng và chuyển giao dự án",
        "purpose": "Hoàn thành bốn giai đoạn và tiêu chí theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Đại diện nhắc lại bốn mốc, một HS nêu cách hỏi khi gặp khó.",
        "conclusion": "Tại nhà sẽ hoàn thiện một dự án liên tục; không phải bốn dự án và không có tiết báo cáo thứ 13.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Thống nhất hình thức có thể làm, cách hỗ trợ và đầu ra giai đoạn 1. Ngày và kênh nộp do Thầy/Cô thông báo.",
          "Bấm Chiếu tiêu chí dự án để đọc đủ năm tiêu chí và mô tả mức 0–2 trước khi làm. Mỗi giai đoạn tiếp tục cùng một dự án."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Đọc năm tiêu chí. Xem bốn giai đoạn. Thống nhất cách làm và hỗ trợ.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Thống nhất hình thức có thể làm, cách hỗ trợ và đầu ra giai đoạn 1. Ngày và kênh nộp do Thầy/Cô thông báo.\nBấm Chiếu tiêu chí dự án để đọc đủ năm tiêu chí và mô tả mức 0–2 trước khi làm. Mỗi giai đoạn tiếp tục cùng một dự án.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đọc năm tiêu chí.",
        "Xem bốn giai đoạn.",
        "Thống nhất cách làm và hỗ trợ."
      ],
      "phase": "Vận dụng",
      "scene": "idea",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "08-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 31,
      "v7": true,
      "originalTeachingPoints": [
        "Đọc năm tiêu chí.",
        "Xem bốn giai đoạn.",
        "Thống nhất cách làm và hỗ trợ."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P8.3B · Em tự làm"
    },
    {
      "type": "home",
      "id": "08-24",
      "title": "Bắt đầu bằng kế hoạch nhỏ",
      "note": {
        "activity": "Vận dụng và chuyển giao dự án",
        "purpose": "Hiểu bốn mốc tại nhà và điều kiện nộp.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Đại diện nhắc lại bốn mốc, một HS nêu cách hỏi khi gặp khó.",
        "conclusion": "Tại nhà sẽ hoàn thiện một dự án liên tục; không phải bốn dự án và không có tiết báo cáo thứ 13.",
        "assessment": "Chỉ giao khi nhóm biết đầu ra giai đoạn 1, cách nhận phản hồi và lựa chọn khi thiếu thiết bị.",
        "answers": [
          "Tại nhà sẽ hoàn thiện một dự án liên tục. Không phải bốn dự án và không có tiết báo cáo thứ 13."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch dự án nhóm AI, trang in 99; Bài 11 AI quanh ta và tác động thực tế. Lược bỏ yêu cầu lập trình, nhận dạng tư thế để phù hợp khung 12 tiết.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mở bản nháp và góp ý.\n2. Nói dễ hiểu: Điều chỉnh phạm vi.\n3. Điều cần nhớ: Phân công giai đoạn 1.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tại nhà sẽ hoàn thiện một dự án liên tục. Không phải bốn dự án và không có tiết báo cáo thứ 13.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mở bản nháp và góp ý.",
        "Điều chỉnh phạm vi.",
        "Phân công giai đoạn 1."
      ],
      "phase": "Vận dụng",
      "scene": "idea",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 32,
      "v7": true,
      "originalTeachingPoints": [
        "Mở bản nháp và góp ý.",
        "Điều chỉnh phạm vi.",
        "Phân công giai đoạn 1."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mở bản nháp và góp ý.",
          "tone": "key",
          "note": "Thầy/Cô: Mở bản nháp và góp ý."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Điều chỉnh phạm vi.",
          "tone": "explain",
          "note": "Thầy/Cô: Điều chỉnh phạm vi."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Phân công giai đoạn 1.",
          "tone": "action",
          "note": "Thầy/Cô: Phân công giai đoạn 1."
        }
      ]
    }
  ],
  "rubric": [
    [
      "1 Vấn đề và tính khả thi",
      "Chưa nêu vấn đề/người dùng hoặc mục tiêu không thể thực hiện.",
      "Có vấn đề/người dùng nhưng mục tiêu hoặc cách thực hiện còn rộng.",
      "Vấn đề, người dùng, mục tiêu rõ. Hình thức và quy mô phù hợp điều kiện."
    ],
    [
      "2 Chức năng AI và chính xác",
      "Không mô tả đúng AI hoặc gán chức năng không có bằng chứng.",
      "Có đầu vào/đầu ra. Còn thiếu liên kết hoặc chưa rõ mức đã làm.",
      "Chức năng, đầu vào/đầu ra và ví dụ đúng. Ghi rõ minh họa hay hoạt động thật."
    ],
    [
      "3 Con người và an toàn",
      "Chưa có bước kiểm tra. Hoặc còn chia sẻ thông tin riêng không cần thiết.",
      "Có người kiểm tra nhưng cách kiểm/điều kiện riêng tư còn chung chung.",
      "Có nguồn kiểm và cách xử lí khi sai. Con người quyết định. Chỉ dùng dữ liệu cần thiết."
    ],
    [
      "4 Sản phẩm nguồn và quá trình",
      "Thiếu phần chính, nguồn hoặc bằng chứng quá trình.",
      "Sản phẩm đọc được. Còn thiếu phần, nguồn khó xem lại hoặc bảng ghi chưa rõ.",
      "Đủ nội dung. Nguồn mở lại được. Sản phẩm dễ xem. Có bảng ghi quá trình."
    ],
    [
      "5 Hợp tác chỉnh sửa giới thiệu",
      "Chưa có đóng góp, góp ý hoặc sửa bài. Chưa giới thiệu sản phẩm.",
      "Có phân công hoặc sửa nhưng lí do chưa rõ. Giới thiệu chưa đủ hoặc còn thiếu minh chứng.",
      "Có đóng góp và một sửa có lí do. Video 2–3 phút nêu rõ vai AI và người."
    ]
  ],
  "evidence": [
    [
      "Chọn ý tưởng và thiết kế",
      "6.2.TC1b",
      "Đề xuất dự án nhỏ và phân biệt phần AI/con người.",
      "P8.1–P8.2, P8.3A cá nhân",
      "Chức năng AI phù hợp, kiểm tra có người thực hiện; đây là minh chứng đề xuất, chưa chứng minh mô hình chạy thật."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
