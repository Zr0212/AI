window.AI6_LESSON={
  "id": 6,
  "title": "Bài 6. Dữ liệu cá nhân, quyền riêng tư và an toàn khi dùng AI",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 30,
  "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 8,
    "title": "Ethics & AI: Privacy & the Future of Work",
    "start": 45,
    "end": 75,
    "poster": "frame_8_55.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/3RvsPKnda53SrBqZo3BxCB/d92dda3313b3d2845caf7dc8f85a7f0f/ai-07-ai-ethics-privacy-work.mp4",
    "question": "Khi chỉ hỏi nghĩa một từ, những thông tin cá nhân nào không cần cung cấp?",
    "local": "code-8.mp4"
  },
  "outcome": "Câu hỏi đã xóa thông tin thừa và thẻ hỏi an toàn.",
  "slides": [
    {
      "type": "cover",
      "id": "06-01",
      "title": "Bài 6. Dữ liệu cá nhân, quyền riêng tư và an toàn khi dùng AI",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra dữ liệu được yêu cầu có thể không cần cho nhiệm vụ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn.",
        "assessment": "Ghi nhận các em biết dừng và hỏi. Không kết luận chỉ cần có nút cho phép là an toàn.",
        "answers": [
          "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "privacy",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "06-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra dữ liệu được yêu cầu có thể không cần cho nhiệm vụ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn.",
        "assessment": "Ghi nhận các em biết dừng và hỏi. Không kết luận chỉ cần có nút cho phép là an toàn.",
        "answers": [
          "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhận ra thông tin không cần cho nhiệm vụ.\n2. Nói dễ hiểu: Xóa thông tin thừa, kiểm tệp đã sửa.\n3. Điều cần nhớ: Hỏi người lớn khi chưa rõ yêu cầu quyền.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nhận ra thông tin không cần cho nhiệm vụ.",
        "Xóa thông tin thừa, kiểm tệp đã sửa.",
        "Hỏi người lớn khi chưa rõ yêu cầu quyền."
      ],
      "phase": "Khởi động",
      "scene": "privacy",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Nhận ra thông tin không cần cho nhiệm vụ.",
        "Xóa thông tin thừa, kiểm tệp đã sửa.",
        "Hỏi người lớn khi chưa rõ yêu cầu quyền."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhận ra thông tin không cần cho nhiệm vụ.",
          "tone": "key",
          "note": "Thầy/Cô: Nhận ra thông tin không cần cho nhiệm vụ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Xóa thông tin thừa, kiểm tệp đã sửa.",
          "tone": "explain",
          "note": "Thầy/Cô: Xóa thông tin thừa, kiểm tệp đã sửa."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Hỏi người lớn khi chưa rõ yêu cầu quyền.",
          "tone": "action",
          "note": "Thầy/Cô: Hỏi người lớn khi chưa rõ yêu cầu quyền."
        }
      ]
    },
    {
      "type": "divider",
      "id": "06-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra dữ liệu được yêu cầu có thể không cần cho nhiệm vụ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn.",
        "assessment": "Ghi nhận các em biết dừng và hỏi. Không kết luận chỉ cần có nút cho phép là an toàn.",
        "answers": [],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "privacy",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "06-04",
      "title": "Hỏi nghĩa từ có cần địa chỉ?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra dữ liệu được yêu cầu có thể không cần cho nhiệm vụ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn.",
        "assessment": "Ghi nhận các em biết dừng và hỏi. Không kết luận chỉ cần có nút cho phép là an toàn.",
        "answers": [
          "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mục đích: hiểu từ under.\n2. Nói dễ hiểu: Ứng dụng xin tên, vị trí, danh bạ.\n3. Điều cần nhớ: Em có đồng ý ngay không?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Chỉ cung cấp thông tin cần thiết, sau khi hiểu mục đích và được người có trách nhiệm hướng dẫn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mục đích: hiểu từ under.",
        "Ứng dụng xin tên, vị trí, danh bạ.",
        "Em có đồng ý ngay không?"
      ],
      "phase": "Khởi động",
      "scene": "privacy",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Mục đích: hiểu từ under.",
        "Ứng dụng xin tên, vị trí, danh bạ.",
        "Em có đồng ý ngay không?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mục đích: hiểu từ under.",
          "tone": "key",
          "note": "Thầy/Cô: Mục đích: hiểu từ under."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ứng dụng xin tên, vị trí, danh bạ.",
          "tone": "explain",
          "note": "Thầy/Cô: Ứng dụng xin tên, vị trí, danh bạ."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em có đồng ý ngay không?",
          "tone": "action",
          "note": "Thầy/Cô: Em có đồng ý ngay không?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "06-05",
      "title": "Khám phá: dữ liệu nào cần thiết?",
      "note": {
        "activity": "Khám phá 2.1 Nhận diện dữ liệu và câu hỏi an toàn",
        "purpose": "Chỉ ra dữ liệu định danh, nêu ba câu hỏi trước khi chia sẻ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình.",
        "assessment": "Đạt khi nhận diện ít nhất bốn trường và ba câu hỏi có nội dung. Dùng gợi ý ai, để làm gì, có cần không.",
        "answers": [],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "privacy",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_8_55.jpg",
      "id": "06-06",
      "title": "Thông tin nào gắn với em?",
      "note": {
        "activity": "Khám phá 2.1 Nhận diện dữ liệu và câu hỏi an toàn",
        "purpose": "Chỉ ra dữ liệu định danh, nêu ba câu hỏi trước khi chia sẻ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình.",
        "assessment": "Đạt khi nhận diện ít nhất bốn trường và ba câu hỏi có nội dung. Dùng gợi ý ai, để làm gì, có cần không.",
        "answers": [
          "Để hỏi nghĩa under, không cần họ tên, lớp/trường, địa chỉ, số liên hệ, danh bạ hay vị trí chính xác.",
          "Chỉ giữ câu hỏi học tập. Nếu chưa rõ yêu cầu cấp quyền, dừng và hỏi Thầy/Cô/người lớn."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dữ liệu nào ứng dụng muốn có?\n2. Nói dễ hiểu: Dữ liệu nào cần cho câu hỏi?\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Để hỏi nghĩa under, không cần họ tên, lớp/trường, địa chỉ, số liên hệ, danh bạ hay vị trí chính xác.\nChỉ giữ câu hỏi học tập. Nếu chưa rõ yêu cầu cấp quyền, dừng và hỏi Thầy/Cô/người lớn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dữ liệu nào ứng dụng muốn có?",
        "Dữ liệu nào cần cho câu hỏi?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "Dữ liệu nào ứng dụng muốn có?",
        "Dữ liệu nào cần cho câu hỏi?",
        "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dữ liệu nào ứng dụng muốn có?",
          "tone": "key",
          "note": "Thầy/Cô: Dữ liệu nào ứng dụng muốn có?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dữ liệu nào cần cho câu hỏi?",
          "tone": "explain",
          "note": "Thầy/Cô: Dữ liệu nào cần cho câu hỏi?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình."
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 8,
        "title": "Ethics & AI: Privacy & the Future of Work",
        "start": 45,
        "end": 75,
        "poster": "frame_8_55.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/3RvsPKnda53SrBqZo3BxCB/d92dda3313b3d2845caf7dc8f85a7f0f/ai-07-ai-ethics-privacy-work.mp4",
        "question": "Dữ liệu nào đang được thu thập?",
        "local": "code-8.mp4"
      },
      "id": "06-07",
      "title": "Dữ liệu và quyền riêng tư",
      "note": {
        "activity": "Khám phá 2.1 Nhận diện dữ liệu và câu hỏi an toàn",
        "purpose": "Chỉ ra dữ liệu định danh, nêu ba câu hỏi trước khi chia sẻ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình.",
        "assessment": "Đạt khi nhận diện ít nhất bốn trường và ba câu hỏi có nội dung. Dùng gợi ý ai, để làm gì, có cần không.",
        "answers": [
          "Để hỏi nghĩa under, không cần họ tên, lớp/trường, địa chỉ, số liên hệ, danh bạ hay vị trí chính xác.",
          "Chỉ giữ câu hỏi học tập. Nếu chưa rõ yêu cầu cấp quyền, dừng và hỏi Thầy/Cô/người lớn."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: Tìm dữ liệu đang được thu thập. Liên hệ với việc hỏi nghĩa từ.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "Để hỏi nghĩa under, không cần họ tên, lớp/trường, địa chỉ, số liên hệ, danh bạ hay vị trí chính xác.\nChỉ giữ câu hỏi học tập. Nếu chưa rõ yêu cầu cấp quyền, dừng và hỏi Thầy/Cô/người lớn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "fallback": "Dữ liệu có thể gắn với một người. Chỉ cung cấp phần cần cho việc học; chưa rõ thì hỏi người lớn.",
      "v6": true,
      "screen": [
        "Tìm dữ liệu đang được thu thập.",
        "Liên hệ với việc hỏi nghĩa từ."
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 30 giây, em ghi một ví dụ vào vở."
      ],
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm dữ liệu đang được thu thập.",
        "Liên hệ với việc hỏi nghĩa từ."
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "type": "concept",
      "id": "06-08",
      "title": "Chỉ gửi phần cần cho nhiệm vụ",
      "note": {
        "activity": "Khám phá 2.1 Nhận diện dữ liệu và câu hỏi an toàn",
        "purpose": "Chỉ ra dữ liệu định danh, nêu ba câu hỏi trước khi chia sẻ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình.",
        "assessment": "Đạt khi nhận diện ít nhất bốn trường và ba câu hỏi có nội dung. Dùng gợi ý ai, để làm gì, có cần không.",
        "answers": [
          "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về em."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Hỏi nghĩa từ nhưng câu chat kèm địa chỉ nhà.\n2. Nói dễ hiểu: Địa chỉ gắn với một người, không cần để dịch.\n3. Điều cần nhớ: Xóa thông tin riêng không cần cho câu hỏi.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về em.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dữ liệu cá nhân: thông tin gắn với một người.",
        "Quyền riêng tư: kiểm soát việc tiếp cận, dùng thông tin.",
        "Hỏi nghĩa từ không cần địa chỉ nhà."
      ],
      "phase": "Khám phá",
      "scene": "privacy",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Dữ liệu cá nhân: thông tin gắn với một người.",
        "Quyền riêng tư: kiểm soát việc tiếp cận, dùng thông tin.",
        "Hỏi nghĩa từ không cần địa chỉ nhà."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Hỏi nghĩa từ nhưng câu chat kèm địa chỉ nhà.",
          "tone": "key",
          "note": "Thầy/Cô: Hỏi nghĩa từ nhưng câu chat kèm địa chỉ nhà."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Địa chỉ gắn với một người, không cần để dịch.",
          "tone": "explain",
          "note": "Thầy/Cô: Địa chỉ gắn với một người, không cần để dịch."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Xóa thông tin riêng không cần cho câu hỏi.",
          "tone": "action",
          "note": "Thầy/Cô: Xóa thông tin riêng không cần cho câu hỏi."
        }
      ]
    },
    {
      "id": "06-09-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu chọn thông tin cần gửi",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "privacy",
      "worked": {
        "title": "Mẫu chọn thông tin cần gửi",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Mục đích",
          "Tên và trường",
          "Số liên hệ",
          "Câu hỏi giữ lại",
          "Vị trí nhà"
        ],
        "values": [
          "Hiểu nghĩa từ under",
          "Bỏ khỏi câu hỏi",
          "Bỏ khỏi câu hỏi",
          "Từ under nghĩa là gì?",
          "Không cần gửi vị trí nhà"
        ],
        "why": [
          "Mục đích quyết định dữ liệu cần dùng.",
          "Biết tên không giúp giải nghĩa từ.",
          "Chỉ giữ phần câu hỏi học tập."
        ],
        "question": "Ô vị trí nhà nên giữ hay bỏ?",
        "scene": "Privacy"
      },
      "targetId": "06-09",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không cần gửi vị trí nhà",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Mục đích: Hiểu nghĩa từ under\nTên và trường: Bỏ khỏi câu hỏi\nSố liên hệ: Bỏ khỏi câu hỏi\nCâu hỏi giữ lại: Từ under nghĩa là gì?\nVị trí nhà: Không cần gửi vị trí nhà"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Hỏi nghĩa under có cần số điện thoại không?\n2. Nói dễ hiểu: Hiểu nghĩa từ không cần biết số điện thoại.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Mục đích: Hiểu nghĩa từ under\nTên và trường: Bỏ khỏi câu hỏi\nSố liên hệ: Bỏ khỏi câu hỏi\nCâu hỏi giữ lại: Từ under nghĩa là gì?\nVị trí nhà: Không cần gửi vị trí nhà",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 9,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Hỏi nghĩa under có cần số điện thoại không?",
          "tone": "key",
          "note": "Thầy/Cô: Hỏi nghĩa under có cần số điện thoại không?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Hiểu nghĩa từ không cần biết số điện thoại.",
          "tone": "explain",
          "note": "Thầy/Cô: Hiểu nghĩa từ không cần biết số điện thoại."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Ô vị trí nhà nên giữ hay bỏ? Gợi ý: Không cần gửi vị trí nhà"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P6.1 Hồ sơ ví dụ tạo sẵn",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Bỏ tên, lớp/trường, địa chỉ, số liên hệ, vị trí vì không cần để hỏi nghĩa từ. Giữ câu hỏi học tập.",
          "Câu hỏi chấp nhận: Dữ liệu này để làm gì? Có cần cho nhiệm vụ không? Có thể không cấp quyền không? Ai hỗ trợ khi chưa rõ? Không kết luận cứ hồ sơ giả là được tùy ý tải lên mọi công cụ."
        ],
        "pages": [
          {
            "title": "Chọn thông tin cần giữ — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thông tin",
              "Nội dung mẫu",
              "Giữ hay bỏ? Vì sao?"
            ],
            "rows": [
              [
                "Tên",
                "Em ngồi cạnh Học Sinh Mẫu",
                {
                  "label": "Tên: quyết định và lí do",
                  "key": "06-09-v3-0"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn thông tin cần giữ — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thông tin",
              "Nội dung mẫu",
              "Giữ hay bỏ? Vì sao?"
            ],
            "rows": [
              [
                "Lớp/trường",
                "6X, Trường Mẫu",
                {
                  "label": "Lớp/trường: quyết định và lí do",
                  "key": "06-09-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn thông tin cần giữ — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thông tin",
              "Nội dung mẫu",
              "Giữ hay bỏ? Vì sao?"
            ],
            "rows": [
              [
                "Địa chỉ",
                "Nhà số XX, Đường Mẫu",
                {
                  "label": "Địa chỉ: quyết định và lí do",
                  "key": "06-09-v3-2"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn thông tin cần giữ — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thông tin",
              "Nội dung mẫu",
              "Giữ hay bỏ? Vì sao?"
            ],
            "rows": [
              [
                "Số liên hệ",
                "09xx xxx xxx",
                {
                  "label": "Số liên hệ: quyết định và lí do",
                  "key": "06-09-v3-3"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Chọn thông tin cần giữ — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thông tin",
              "Nội dung mẫu",
              "Giữ hay bỏ? Vì sao?"
            ],
            "rows": [
              [
                "Vị trí",
                "Tọa độ ví dụ tạo sẵn",
                {
                  "label": "Vị trí: quyết định và lí do",
                  "key": "06-09-v3-4"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Chọn thông tin cần giữ — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thông tin",
              "Nội dung mẫu",
              "Giữ hay bỏ? Vì sao?"
            ],
            "rows": [
              [
                "Câu hỏi",
                "Nghĩa của under trong câu mẫu",
                {
                  "label": "Câu hỏi: quyết định và lí do",
                  "key": "06-09-v3-5"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Hỏi trước khi cấp quyền",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Câu hỏi về mục đích thu thập",
                "key": "06-09-v3-6"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Hỏi trước khi cấp quyền",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Câu hỏi về thông tin có thật sự cần thiết không",
                "key": "06-09-v3-7"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Hỏi trước khi cấp quyền",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Câu hỏi để nhờ Thầy/Cô/người lớn hỗ trợ",
                "key": "06-09-v3-8"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 3,
          "2": 6
        }
      },
      "time": 5,
      "id": "06-09",
      "title": "P6.1 — Giữ hay bỏ thông tin?",
      "note": {
        "activity": "Khám phá 2.1 Nhận diện dữ liệu và câu hỏi an toàn",
        "purpose": "Hoàn thành hồ sơ giả định theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Bỏ tên, lớp/trường, địa chỉ, số liên hệ, vị trí vì không cần để hỏi nghĩa từ. Giữ câu hỏi học tập.",
          "Câu hỏi chấp nhận: Dữ liệu này để làm gì? Có cần cho nhiệm vụ không? Có thể không cấp quyền không? Ai hỗ trợ khi chưa rõ? Không kết luận cứ hồ sơ giả là được tùy ý tải lên mọi công cụ."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Mục đích chỉ là hỏi nghĩa under. Chọn thông tin cần giữ. Viết câu hỏi trước khi cấp quyền.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Bỏ tên, lớp/trường, địa chỉ, số liên hệ, vị trí vì không cần để hỏi nghĩa từ. Giữ câu hỏi học tập.\nCâu hỏi chấp nhận: Dữ liệu này để làm gì? Có cần cho nhiệm vụ không? Có thể không cấp quyền không? Ai hỗ trợ khi chưa rõ? Không kết luận cứ hồ sơ giả là được tùy ý tải lên mọi công cụ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em so kết quả để rút ra điều có căn cứ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mục đích chỉ là hỏi nghĩa under.",
        "Chọn thông tin cần giữ.",
        "Viết câu hỏi trước khi cấp quyền."
      ],
      "phase": "Khám phá",
      "scene": "privacy",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "06-09-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 10,
      "v7": true,
      "originalTeachingPoints": [
        "Mục đích chỉ là hỏi nghĩa under.",
        "Chọn thông tin cần giữ.",
        "Viết câu hỏi trước khi cấp quyền."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P6.1 · Chọn thông tin cần"
    },
    {
      "type": "conclusion",
      "id": "06-10",
      "title": "Dừng lại để hỏi rõ",
      "note": {
        "activity": "Khám phá 2.1 Nhận diện dữ liệu và câu hỏi an toàn",
        "purpose": "Chỉ ra dữ liệu định danh, nêu ba câu hỏi trước khi chia sẻ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về mình.",
        "assessment": "Đạt khi nhận diện ít nhất bốn trường và ba câu hỏi có nội dung. Dùng gợi ý ai, để làm gì, có cần không.",
        "answers": [
          "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về em."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em so kết quả để rút ra điều có căn cứ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Thông tin này phục vụ việc gì?\n2. Nói dễ hiểu: Có thể không cung cấp không?\n3. Điều cần nhớ: Chưa rõ, em nhờ ai?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Dữ liệu cá nhân gắn với một người và cần được bảo vệ. Quyền riêng tư liên quan việc kiểm soát tiếp cận, sử dụng thông tin về em.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Thông tin này phục vụ việc gì?",
        "Có thể không cung cấp không?",
        "Chưa rõ, em nhờ ai?"
      ],
      "phase": "Khám phá",
      "scene": "privacy",
      "taskLines": [
        "Trong 30 giây, em nêu một căn cứ tại chỗ."
      ],
      "connector": "Em so kết quả để rút ra điều có căn cứ.",
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [
        "Thông tin này phục vụ việc gì?",
        "Có thể không cung cấp không?",
        "Chưa rõ, em nhờ ai?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Thông tin này phục vụ việc gì?",
          "tone": "key",
          "note": "Thầy/Cô: Thông tin này phục vụ việc gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Có thể không cung cấp không?",
          "tone": "explain",
          "note": "Thầy/Cô: Có thể không cung cấp không?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chưa rõ, em nhờ ai?",
          "tone": "action",
          "note": "Thầy/Cô: Chưa rõ, em nhờ ai?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "06-11",
      "title": "Thực hành: tạo bản chia sẻ an toàn",
      "note": {
        "activity": "Khám phá 2.2 Tạo bản chia sẻ an toàn",
        "purpose": "Thực hiện loại thông tin không cần thiết và kiểm tra bản cuối.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
        "assessment": "Quan sát thao tác và bản cuối. Không coi quy trình này là chứng nhận xóa mọi siêu dữ liệu trên mọi định dạng.",
        "answers": [],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “tin nhắn này đang lộ gì?”."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "06-v7-unsafe",
      "type": "guide",
      "title": "Tin nhắn này đang lộ gì?",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Tên: EM_MẪU; lớp: 6X, TRƯỜNG_MẪU.",
        "Nhà: ĐỊA_CHỈ_MẪU; mẹ: 09xx xxx xxx.",
        "Câu cần hỏi: Từ under nghĩa là gì?"
      ],
      "scene": "privacy-raw",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đọc lại để chắc đã xóa thông tin thừa",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tên: EM_MẪU; lớp: 6X, TRƯỜNG_MẪU. / Nhà: ĐỊA_CHỈ_MẪU; mẹ: 09xx xxx xxx. / Câu cần hỏi: Từ under nghĩa là gì?"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Tin nhắn này đang lộ gì?.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tên: EM_MẪU; lớp: 6X, TRƯỜNG_MẪU.\n2. Nói dễ hiểu: Nhà: ĐỊA_CHỈ_MẪU; mẹ: 09xx xxx xxx.\n3. Điều cần nhớ: Câu cần hỏi: Từ under nghĩa là gì?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tên: EM_MẪU; lớp: 6X, TRƯỜNG_MẪU. / Nhà: ĐỊA_CHỈ_MẪU; mẹ: 09xx xxx xxx. / Câu cần hỏi: Từ under nghĩa là gì?",
          "closing": "Thầy/Cô chốt: Câu cần hỏi: Từ under nghĩa là gì?",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “bốn phần không cần gửi”."
        }
      },
      "number": 13,
      "originalTeachingPoints": [
        "Tên: EM_MẪU; lớp: 6X, TRƯỜNG_MẪU.",
        "Nhà: ĐỊA_CHỈ_MẪU; mẹ: 09xx xxx xxx.",
        "Câu cần hỏi: Từ under nghĩa là gì?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tên: EM_MẪU; lớp: 6X, TRƯỜNG_MẪU.",
          "tone": "error",
          "note": "Thầy/Cô: Tên: EM_MẪU; lớp: 6X, TRƯỜNG_MẪU."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nhà: ĐỊA_CHỈ_MẪU; mẹ: 09xx xxx xxx.",
          "tone": "explain",
          "note": "Thầy/Cô: Nhà: ĐỊA_CHỈ_MẪU; mẹ: 09xx xxx xxx."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Câu cần hỏi: Từ under nghĩa là gì?",
          "tone": "action",
          "note": "Thầy/Cô: Câu cần hỏi: Từ under nghĩa là gì?"
        }
      ]
    },
    {
      "id": "06-v7-risk",
      "type": "guide",
      "title": "Bốn phần không cần gửi",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Tên; lớp/trường; địa chỉ; số điện thoại mẹ.",
        "Các mục này có thể giúp nhận ra một người.",
        "Hỏi nghĩa từ không cần các thông tin đó."
      ],
      "scene": "privacy-risk",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đọc lại để chắc đã xóa thông tin thừa",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tên; lớp/trường; địa chỉ; số điện thoại mẹ. / Các mục này có thể giúp nhận ra một người. / Hỏi nghĩa từ không cần các thông tin đó."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Bốn phần không cần gửi.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tên; lớp/trường; địa chỉ; số điện thoại mẹ.\n2. Nói dễ hiểu: Các mục này có thể giúp nhận ra một người.\n3. Điều cần nhớ: Hỏi nghĩa từ không cần các thông tin đó.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tên; lớp/trường; địa chỉ; số điện thoại mẹ. / Các mục này có thể giúp nhận ra một người. / Hỏi nghĩa từ không cần các thông tin đó.",
          "closing": "Thầy/Cô chốt: Hỏi nghĩa từ không cần các thông tin đó.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “giữ câu hỏi, xóa thông tin riêng”."
        }
      },
      "number": 14,
      "originalTeachingPoints": [
        "Tên; lớp/trường; địa chỉ; số điện thoại mẹ.",
        "Các mục này có thể giúp nhận ra một người.",
        "Hỏi nghĩa từ không cần các thông tin đó."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tên; lớp/trường; địa chỉ; số điện thoại mẹ.",
          "tone": "error",
          "note": "Thầy/Cô: Tên; lớp/trường; địa chỉ; số điện thoại mẹ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Các mục này có thể giúp nhận ra một người.",
          "tone": "explain",
          "note": "Thầy/Cô: Các mục này có thể giúp nhận ra một người."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Hỏi nghĩa từ không cần các thông tin đó.",
          "tone": "action",
          "note": "Thầy/Cô: Hỏi nghĩa từ không cần các thông tin đó."
        }
      ]
    },
    {
      "id": "06-v7-safe",
      "type": "guide",
      "title": "Giữ câu hỏi, xóa thông tin riêng",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Từ under nghĩa là gì trong câu này?",
        "The cat is under the table.",
        "Đọc lại: chỉ còn câu hỏi học tập."
      ],
      "scene": "privacy-safe",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đọc lại để chắc đã xóa thông tin thừa",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Từ under nghĩa là gì trong câu này? / The cat is under the table. / Đọc lại: chỉ còn câu hỏi học tập."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi, xóa thông tin riêng.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Từ under nghĩa là gì trong câu này?\n2. Nói dễ hiểu: The cat is under the table.\n3. Điều cần nhớ: Đọc lại: chỉ còn câu hỏi học tập.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Từ under nghĩa là gì trong câu này? / The cat is under the table. / Đọc lại: chỉ còn câu hỏi học tập.",
          "closing": "Thầy/Cô chốt: Đọc lại: chỉ còn câu hỏi học tập.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "number": 15,
      "originalTeachingPoints": [
        "Từ under nghĩa là gì trong câu này?",
        "The cat is under the table.",
        "Đọc lại: chỉ còn câu hỏi học tập."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Từ under nghĩa là gì trong câu này?",
          "tone": "key",
          "note": "Thầy/Cô: Từ under nghĩa là gì trong câu này?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "The cat is under the table.",
          "tone": "explain",
          "note": "Thầy/Cô: The cat is under the table."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đọc lại: chỉ còn câu hỏi học tập.",
          "tone": "key",
          "note": "Thầy/Cô: Đọc lại: chỉ còn câu hỏi học tập."
        }
      ]
    },
    {
      "id": "06-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu sửa hai khung chat",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "worked": {
        "title": "Mẫu sửa hai khung chat",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Khung trước",
          "Thông tin đánh dấu",
          "Phần cần giữ",
          "Khung sau",
          "Việc kiểm cuối"
        ],
        "values": [
          "Tên EM_MẪU. Trường MẪU. SĐT 09xx",
          "Tên, trường và số liên hệ",
          "Câu hỏi nghĩa từ under",
          "Từ under nghĩa là gì?",
          "Đọc lại để chắc đã xóa thông tin thừa"
        ],
        "why": [
          "Các phần đánh đỏ không giúp hỏi nghĩa.",
          "Xóa khỏi nội dung, không chỉ che màu.",
          "Bản sau vẫn nêu rõ việc cần hỏi."
        ],
        "question": "Trước khi gửi, em cần kiểm gì?",
        "scene": "Privacy"
      },
      "targetId": "06-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đọc lại để chắc đã xóa thông tin thừa",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Khung trước: Tên EM_MẪU. Trường MẪU. SĐT 09xx\nThông tin đánh dấu: Tên, trường và số liên hệ\nPhần cần giữ: Câu hỏi nghĩa từ under\nKhung sau: Từ under nghĩa là gì?\nViệc kiểm cuối: Đọc lại để chắc đã xóa thông tin thừa"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tin nhắn mẫu chứa tên, trường và số liên hệ.\n2. Nói dễ hiểu: Xóa thông tin riêng, giữ nguyên câu hỏi học tập.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Khung trước: Tên EM_MẪU. Trường MẪU. SĐT 09xx\nThông tin đánh dấu: Tên, trường và số liên hệ\nPhần cần giữ: Câu hỏi nghĩa từ under\nKhung sau: Từ under nghĩa là gì?\nViệc kiểm cuối: Đọc lại để chắc đã xóa thông tin thừa",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tin nhắn mẫu chứa tên, trường và số liên hệ.",
          "tone": "key",
          "note": "Thầy/Cô: Tin nhắn mẫu chứa tên, trường và số liên hệ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Xóa thông tin riêng, giữ nguyên câu hỏi học tập.",
          "tone": "explain",
          "note": "Thầy/Cô: Xóa thông tin riêng, giữ nguyên câu hỏi học tập."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Trước khi gửi, em cần kiểm gì? Gợi ý: Đọc lại để chắc đã xóa thông tin thừa"
        }
      ]
    },
    {
      "type": "task",
      "id": "06-12",
      "title": "Tạo một bản hỏi nghĩa an toàn",
      "note": {
        "activity": "Khám phá 2.2 Tạo bản chia sẻ an toàn",
        "purpose": "Thực hiện loại thông tin không cần thiết và kiểm tra bản cuối.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
        "assessment": "Quan sát thao tác và bản cuối. Không coi quy trình này là chứng nhận xóa mọi siêu dữ liệu trên mọi định dạng.",
        "answers": [
          "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mở bản sao ví dụ tạo sẵn.\n2. Nói dễ hiểu: Xóa thông tin không cần.\n3. Điều cần nhớ: Tải và mở lại bản sạch.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em mở bản sao để xóa thông tin không cần."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mở bản sao ví dụ tạo sẵn.",
        "Xóa thông tin không cần.",
        "Tải và mở lại bản sạch."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 11 phút, em xóa thông tin thừa trong ô văn bản."
      ],
      "sampleId": "06-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Mở bản sao ví dụ tạo sẵn.",
        "Xóa thông tin không cần.",
        "Tải và mở lại bản sạch."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mở bản sao ví dụ tạo sẵn.",
          "tone": "key",
          "note": "Thầy/Cô: Mở bản sao ví dụ tạo sẵn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Xóa thông tin không cần.",
          "tone": "explain",
          "note": "Thầy/Cô: Xóa thông tin không cần."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Tải và mở lại bản sạch.",
          "tone": "action",
          "note": "Thầy/Cô: Tải và mở lại bản sạch."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 0,
      "id": "06-13",
      "title": "Bước 1 — Xóa phần không cần",
      "note": {
        "activity": "Khám phá 2.2 Tạo bản chia sẻ an toàn",
        "purpose": "Thực hiện loại thông tin không cần thiết và kiểm tra bản cuối.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
        "assessment": "Quan sát thao tác và bản cuối. Không coi quy trình này là chứng nhận xóa mọi siêu dữ liệu trên mọi định dạng.",
        "answers": [
          "Bản sạch chỉ còn: Từ under nghĩa là gì trong The cat is under the table?",
          "Xóa tên, lớp/trường, địa chỉ, liên hệ và vị trí khỏi văn bản. Lưu tệp Cau_hoi_tu_vung.txt rồi mở lại kiểm tra. Đây là bài tập văn bản ví dụ tạo sẵn, không phải chứng nhận đã xóa mọi dữ liệu của mọi loại tệp."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em mở bản sao để xóa thông tin không cần.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Xóa tên, lớp, địa chỉ và liên hệ.\n2. Nói dễ hiểu: Giữ câu hỏi nghĩa under.\n3. Điều cần nhớ: Không chỉ che chữ bằng màu.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bản sạch chỉ còn: Từ under nghĩa là gì trong The cat is under the table?\nXóa tên, lớp/trường, địa chỉ, liên hệ và vị trí khỏi văn bản. Lưu tệp Cau_hoi_tu_vung.txt rồi mở lại kiểm tra. Đây là bài tập văn bản ví dụ tạo sẵn, không phải chứng nhận đã xóa mọi dữ liệu của mọi loại tệp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Bản trên màn hình đã sửa. Em kiểm tệp sẽ chia sẻ."
        }
      },
      "theme": "cream",
      "recordTarget": "06-17",
      "recordPage": 0,
      "v6": true,
      "screen": [
        "Xóa tên, lớp, địa chỉ và liên hệ.",
        "Giữ câu hỏi nghĩa under.",
        "Không chỉ che chữ bằng màu."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 1 phút, em làm bước này trong ô văn bản."
      ],
      "connector": "Em mở bản sao để xóa thông tin không cần.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Xóa tên, lớp, địa chỉ và liên hệ.",
        "Giữ câu hỏi nghĩa under.",
        "Không chỉ che chữ bằng màu."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Xóa tên, lớp, địa chỉ và liên hệ.",
          "tone": "key",
          "note": "Thầy/Cô: Xóa tên, lớp, địa chỉ và liên hệ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Giữ câu hỏi nghĩa under.",
          "tone": "explain",
          "note": "Thầy/Cô: Giữ câu hỏi nghĩa under."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không chỉ che chữ bằng màu.",
          "tone": "action",
          "note": "Thầy/Cô: Không chỉ che chữ bằng màu."
        }
      ]
    },
    {
      "type": "step",
      "step": 2,
      "time": 0,
      "id": "06-15",
      "title": "Bước 2 — Tải rồi mở lại",
      "note": {
        "activity": "Khám phá 2.2 Tạo bản chia sẻ an toàn",
        "purpose": "Thực hiện loại thông tin không cần thiết và kiểm tra bản cuối.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
        "assessment": "Quan sát thao tác và bản cuối. Không coi quy trình này là chứng nhận xóa mọi siêu dữ liệu trên mọi định dạng.",
        "answers": [
          "Bản sạch chỉ còn: Từ under nghĩa là gì trong The cat is under the table?",
          "Xóa tên, lớp/trường, địa chỉ, liên hệ và vị trí khỏi văn bản. Lưu tệp Cau_hoi_tu_vung.txt rồi mở lại kiểm tra. Đây là bài tập văn bản ví dụ tạo sẵn, không phải chứng nhận đã xóa mọi dữ liệu của mọi loại tệp."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Bản trên màn hình đã sửa. Em kiểm tệp sẽ chia sẻ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tải Cau_hoi_tu_vung.txt.\n2. Nói dễ hiểu: Mở tệp vừa tải.\n3. Điều cần nhớ: Kiểm nội dung và tên tệp.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bản sạch chỉ còn: Từ under nghĩa là gì trong The cat is under the table?\nXóa tên, lớp/trường, địa chỉ, liên hệ và vị trí khỏi văn bản. Lưu tệp Cau_hoi_tu_vung.txt rồi mở lại kiểm tra. Đây là bài tập văn bản ví dụ tạo sẵn, không phải chứng nhận đã xóa mọi dữ liệu của mọi loại tệp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "recordTarget": "06-17",
      "recordPage": 1,
      "v6": true,
      "screen": [
        "Tải Cau_hoi_tu_vung.txt.",
        "Mở tệp vừa tải.",
        "Kiểm nội dung và tên tệp."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 1 phút, em làm bước này trong ô văn bản."
      ],
      "connector": "Bản trên màn hình đã sửa. Em kiểm tệp sẽ chia sẻ.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "Tải Cau_hoi_tu_vung.txt.",
        "Mở tệp vừa tải.",
        "Kiểm nội dung và tên tệp."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tải Cau_hoi_tu_vung.txt.",
          "tone": "key",
          "note": "Thầy/Cô: Tải Cau_hoi_tu_vung.txt."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mở tệp vừa tải.",
          "tone": "explain",
          "note": "Thầy/Cô: Mở tệp vừa tải."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Kiểm nội dung và tên tệp.",
          "tone": "action",
          "note": "Thầy/Cô: Kiểm nội dung và tên tệp."
        }
      ]
    },
    {
      "id": "06-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu kiểm chính tệp đã tải",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "document",
      "worked": {
        "title": "Mẫu kiểm chính tệp đã tải",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Nội dung còn lại",
          "Nút dùng",
          "Tên tệp",
          "Việc sau khi tải",
          "Dấu hiệu đạt"
        ],
        "values": [
          "Từ under nghĩa là gì?",
          "Tải bản câu hỏi đã sửa",
          "Cau_hoi_tu_vung.txt",
          "Mở tệp rồi đọc lại",
          "Có câu hỏi. Không còn tên và liên hệ"
        ],
        "why": [
          "Ô nhập đúng chưa đủ chứng minh tệp đúng.",
          "Tên tệp cũng không chứa dữ liệu riêng.",
          "Chưa mở thì chưa đánh dấu đã kiểm."
        ],
        "question": "Khi mở tệp, em cần thấy điều gì?",
        "scene": "Document"
      },
      "targetId": "06-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Có câu hỏi. Không còn tên và liên hệ",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Nội dung còn lại: Từ under nghĩa là gì?\nNút dùng: Tải bản câu hỏi đã sửa\nTên tệp: Cau_hoi_tu_vung.txt\nViệc sau khi tải: Mở tệp rồi đọc lại\nDấu hiệu đạt: Có câu hỏi. Không còn tên và liên hệ"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Câu hỏi đã sửa cần được tải và mở lại.\n2. Nói dễ hiểu: Mở tệp để biết phần thừa đã thực sự bị xóa.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Nội dung còn lại: Từ under nghĩa là gì?\nNút dùng: Tải bản câu hỏi đã sửa\nTên tệp: Cau_hoi_tu_vung.txt\nViệc sau khi tải: Mở tệp rồi đọc lại\nDấu hiệu đạt: Có câu hỏi. Không còn tên và liên hệ",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Câu hỏi đã sửa cần được tải và mở lại.",
          "tone": "key",
          "note": "Thầy/Cô: Câu hỏi đã sửa cần được tải và mở lại."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mở tệp để biết phần thừa đã thực sự bị xóa.",
          "tone": "explain",
          "note": "Thầy/Cô: Mở tệp để biết phần thừa đã thực sự bị xóa."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Khi mở tệp, em cần thấy điều gì? Gợi ý: Có câu hỏi. Không còn tên và liên hệ"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P6.2 Tạo bản chia sẻ",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Bản sạch chỉ còn: Từ under nghĩa là gì trong The cat is under the table?",
          "Xóa tên, lớp/trường, địa chỉ, liên hệ và vị trí khỏi văn bản. Lưu tệp Cau_hoi_tu_vung.txt rồi mở lại kiểm tra. Đây là bài tập văn bản ví dụ tạo sẵn, không phải chứng nhận đã xóa mọi dữ liệu của mọi loại tệp."
        ],
        "pages": [
          {
            "editor": true,
            "title": "Sửa bản sao ngay trên slide",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Bản sao để em chỉnh sửa",
                "initial": "Tên: EM_MẪU\nTrường: TRƯỜNG_MẪU\nLiên hệ: 09xx xxx xxx\nĐịa chỉ: ĐỊA_CHỈ_MẪU\nTừ under nghĩa là gì?",
                "key": "06-17-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "downloadCopy": true,
            "title": "Kiểm tra và lưu bản sạch",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Bản đã sửa còn tên, lớp, địa chỉ, liên hệ hoặc vị trí không?",
                "key": "06-17-v3-1"
              }
            ],
            "originalPage": 1
          },
          {
            "downloadCopy": true,
            "title": "Kiểm tra và lưu bản sạch",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Câu hỏi học tập có còn đầy đủ không?",
                "key": "06-17-v3-2"
              }
            ],
            "originalPage": 1
          },
          {
            "downloadCopy": true,
            "title": "Kiểm tra và lưu bản sạch",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em ngồi cạnh trong em đã phát hiện điều gì cần sửa thêm?",
                "key": "06-17-v3-3"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 1
        }
      },
      "time": 16,
      "id": "06-17",
      "title": "P6.2 — Sửa và kiểm bản sạch",
      "note": {
        "activity": "Khám phá 2.2 Tạo bản chia sẻ an toàn",
        "purpose": "Hoàn thành bản chia sẻ an toàn theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Bản sạch chỉ còn: Từ under nghĩa là gì trong The cat is under the table?",
          "Xóa tên, lớp/trường, địa chỉ, liên hệ và vị trí khỏi văn bản. Lưu tệp Cau_hoi_tu_vung.txt rồi mở lại kiểm tra. Đây là bài tập văn bản ví dụ tạo sẵn, không phải chứng nhận đã xóa mọi dữ liệu của mọi loại tệp."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Trang 1: sửa câu hỏi. Trang 2: tải và kiểm tệp. Ghi đúng điều đã làm.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Bản sạch chỉ còn: Từ under nghĩa là gì trong The cat is under the table?\nXóa tên, lớp/trường, địa chỉ, liên hệ và vị trí khỏi văn bản. Lưu tệp Cau_hoi_tu_vung.txt rồi mở lại kiểm tra. Đây là bài tập văn bản ví dụ tạo sẵn, không phải chứng nhận đã xóa mọi dữ liệu của mọi loại tệp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Trang 1: sửa câu hỏi.",
        "Trang 2: tải và kiểm tệp.",
        "Ghi đúng điều đã làm."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "06-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 21,
      "v7": true,
      "originalTeachingPoints": [
        "Trang 1: sửa câu hỏi.",
        "Trang 2: tải và kiểm tệp.",
        "Ghi đúng điều đã làm."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P6.2 · Sửa câu hỏi"
    },
    {
      "type": "report",
      "id": "06-18",
      "title": "Bỏ gì mà vẫn hỏi được?",
      "note": {
        "activity": "Khám phá 2.2 Tạo bản chia sẻ an toàn",
        "purpose": "Thực hiện loại thông tin không cần thiết và kiểm tra bản cuối.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
        "assessment": "Quan sát thao tác và bản cuối. Không coi quy trình này là chứng nhận xóa mọi siêu dữ liệu trên mọi định dạng.",
        "answers": [
          "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em bỏ thông tin nào?\n2. Nói dễ hiểu: Vì sao không cần?\n3. Điều cần nhớ: Đã kiểm tệp cuối chưa?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Em bỏ thông tin nào?",
        "Vì sao không cần?",
        "Đã kiểm tệp cuối chưa?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [
        "Em bỏ thông tin nào?",
        "Vì sao không cần?",
        "Đã kiểm tệp cuối chưa?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em bỏ thông tin nào?",
          "tone": "key",
          "note": "Thầy/Cô: Em bỏ thông tin nào?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Vì sao không cần?",
          "tone": "explain",
          "note": "Thầy/Cô: Vì sao không cần?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đã kiểm tệp cuối chưa?",
          "tone": "action",
          "note": "Thầy/Cô: Đã kiểm tệp cuối chưa?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "06-20",
      "title": "Luyện tập: xử lí yêu cầu quyền",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Lựa chọn hành động khi công cụ đòi quyền không liên quan.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không tự ý chia sẻ dữ liệu của người khác; hỏi GV/người lớn khi chưa rõ.",
        "assessment": "Đạt khi cả ba lựa chọn bảo vệ dữ liệu. Hỗ trợ câu còn sai bằng sơ đồ mục đích–dữ liệu.",
        "answers": [],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "06-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu trả lời yêu cầu quyền",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "worked": {
        "title": "Mẫu trả lời yêu cầu quyền",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Nhiệm vụ",
          "Quyền ứng dụng xin",
          "Có cần cho nhiệm vụ?",
          "Việc làm trước",
          "Người hỗ trợ"
        ],
        "values": [
          "Hỏi nghĩa từ",
          "Danh bạ",
          "Không cần cho câu hỏi này",
          "Chưa đồng ý, hỏi rõ mục đích",
          "Thầy/Cô hoặc người lớn đáng tin"
        ],
        "why": [
          "Gắn quyền với việc đang làm.",
          "Không bấm cho xong khi chưa rõ.",
          "Không cần đổi cài đặt thật để luyện."
        ],
        "question": "Em nhờ ai cùng xem yêu cầu?",
        "scene": "Privacy"
      },
      "targetId": "06-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thầy/Cô hoặc người lớn đáng tin",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Nhiệm vụ: Hỏi nghĩa từ\nQuyền ứng dụng xin: Danh bạ\nCó cần cho nhiệm vụ?: Không cần cho câu hỏi này\nViệc làm trước: Chưa đồng ý, hỏi rõ mục đích\nNgười hỗ trợ: Thầy/Cô hoặc người lớn đáng tin"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ứng dụng hỏi nghĩa từ xin xem danh bạ.\n2. Nói dễ hiểu: Danh bạ không giúp giải nghĩa từ trong câu này.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Nhiệm vụ: Hỏi nghĩa từ\nQuyền ứng dụng xin: Danh bạ\nCó cần cho nhiệm vụ?: Không cần cho câu hỏi này\nViệc làm trước: Chưa đồng ý, hỏi rõ mục đích\nNgười hỗ trợ: Thầy/Cô hoặc người lớn đáng tin",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ứng dụng hỏi nghĩa từ xin xem danh bạ.",
          "tone": "key",
          "note": "Thầy/Cô: Ứng dụng hỏi nghĩa từ xin xem danh bạ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Danh bạ không giúp giải nghĩa từ trong câu này.",
          "tone": "explain",
          "note": "Thầy/Cô: Danh bạ không giúp giải nghĩa từ trong câu này."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em nhờ ai cùng xem yêu cầu? Gợi ý: Thầy/Cô hoặc người lớn đáng tin"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P6.3 Quyền truy cập và thẻ an toàn",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "1. Danh bạ và vị trí chính xác không cần để hỏi nghĩa từ.",
          "2. Chưa bấm Đồng ý. Xem mục đích, từ chối quyền không liên quan, hỏi Thầy/Cô/người lớn khi chưa rõ.",
          "3. Không tự tải bài có thông tin của em ngồi cạnh lên AI. Xin phép và loại phần không cần theo hướng dẫn. Không chia sẻ nếu chưa được phép."
        ],
        "pages": [
          {
            "title": "Khi ứng dụng đòi quyền không liên quan",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Những quyền này có cần để hỏi nghĩa từ không? Vì sao?",
                "key": "06-21-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Khi ứng dụng đòi quyền không liên quan",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ làm gì trước khi bấm Đồng ý?",
                "key": "06-21-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Tôn trọng thông tin của em ngồi cạnh",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em có tự đưa bài đó lên công cụ AI không? Em cần làm gì trước?",
                "key": "06-21-v3-2"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2
        }
      },
      "time": 4,
      "id": "06-21",
      "title": "P6.3A — Gặp yêu cầu quyền lạ",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành xử lí tình huống cấp quyền theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Không tự ý chia sẻ dữ liệu của người khác; hỏi GV/người lớn khi chưa rõ.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1. Danh bạ và vị trí chính xác không cần để hỏi nghĩa từ.",
          "2. Chưa bấm Đồng ý. Xem mục đích, từ chối quyền không liên quan, hỏi Thầy/Cô/người lớn khi chưa rõ.",
          "3. Không tự tải bài có thông tin của em ngồi cạnh lên AI. Xin phép và loại phần không cần theo hướng dẫn. Không chia sẻ nếu chưa được phép."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Danh bạ có cần để hiểu từ không? Chưa rõ quyền thì làm gì? Có được tải thông tin của em ngồi cạnh lên AI không?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1. Danh bạ và vị trí chính xác không cần để hỏi nghĩa từ.\n2. Chưa bấm Đồng ý. Xem mục đích, từ chối quyền không liên quan, hỏi Thầy/Cô/người lớn khi chưa rõ.\n3. Không tự tải bài có thông tin của em ngồi cạnh lên AI. Xin phép và loại phần không cần theo hướng dẫn. Không chia sẻ nếu chưa được phép.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Danh bạ có cần để hiểu từ không?",
        "Chưa rõ quyền thì làm gì?",
        "Có được tải thông tin của em ngồi cạnh lên AI không?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "06-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [
        "Danh bạ có cần để hiểu từ không?",
        "Chưa rõ quyền thì làm gì?",
        "Có được tải thông tin của em ngồi cạnh lên AI không?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P6.3A · Em tự làm"
    },
    {
      "type": "recap",
      "id": "06-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Tạo bản chia sẻ an toàn",
        "purpose": "Thực hiện loại thông tin không cần thiết và kiểm tra bản cuối.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
        "assessment": "Quan sát thao tác và bản cuối. Không coi quy trình này là chứng nhận xóa mọi siêu dữ liệu trên mọi định dạng.",
        "answers": [
          "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chỉ gửi thông tin cần cho nhiệm vụ.\n2. Nói dễ hiểu: Tôn trọng thông tin riêng của người khác.\n3. Điều cần nhớ: Đọc lại bản chia sẻ. Chưa rõ thì hỏi.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Che nhìn thấy chưa chắc xóa dữ liệu gốc. Bản chia sẻ nên chỉ còn nội dung cần thiết và phải được kiểm tra lại.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chỉ gửi thông tin cần cho nhiệm vụ.",
        "Tôn trọng thông tin riêng của người khác.",
        "Đọc lại bản chia sẻ. Chưa rõ thì hỏi."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "privacy",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [
        "Chỉ gửi thông tin cần cho nhiệm vụ.",
        "Tôn trọng thông tin riêng của người khác.",
        "Đọc lại bản chia sẻ. Chưa rõ thì hỏi."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chỉ gửi thông tin cần cho nhiệm vụ.",
          "tone": "key",
          "note": "Thầy/Cô: Chỉ gửi thông tin cần cho nhiệm vụ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tôn trọng thông tin riêng của người khác.",
          "tone": "explain",
          "note": "Thầy/Cô: Tôn trọng thông tin riêng của người khác."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đọc lại bản chia sẻ. Chưa rõ thì hỏi.",
          "tone": "action",
          "note": "Thầy/Cô: Đọc lại bản chia sẻ. Chưa rõ thì hỏi."
        }
      ]
    },
    {
      "type": "divider",
      "id": "06-22",
      "title": "Vận dụng: viết thẻ an toàn",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Tạo cam kết sử dụng AI có trách nhiệm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Khi chưa rõ mục đích hoặc quyền truy cập, dừng và hỏi người có trách nhiệm.",
        "assessment": "Thẻ là minh chứng nhận thức. Kết hợp bản xử lí để nhận xét thao tác bảo vệ dữ liệu.",
        "answers": [],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "privacy",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "06-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu viết câu hỏi an toàn",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "privacy",
      "worked": {
        "title": "Mẫu viết câu hỏi an toàn",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Tình huống",
          "Điều chưa rõ",
          "Câu hỏi mục đích",
          "Câu hỏi lựa chọn",
          "Câu hỏi hỗ trợ"
        ],
        "values": [
          "Xin vị trí khi em hỏi bài",
          "Vị trí giúp trả lời phần nào?",
          "Công cụ cần vị trí để làm gì?",
          "Em có thể không gửi vị trí không?",
          "Thầy/Cô giúp em kiểm yêu cầu này được không?"
        ],
        "why": [
          "Câu hỏi gắn đúng quyền đang xin.",
          "Em cần một lựa chọn có thể làm.",
          "Chưa rõ thì dừng để hỏi."
        ],
        "question": "Em sẽ viết câu nhờ hỗ trợ thế nào?",
        "scene": "Privacy"
      },
      "targetId": "06-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Thầy/Cô giúp em kiểm yêu cầu này được không?",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tình huống: Xin vị trí khi em hỏi bài\nĐiều chưa rõ: Vị trí giúp trả lời phần nào?\nCâu hỏi mục đích: Công cụ cần vị trí để làm gì?\nCâu hỏi lựa chọn: Em có thể không gửi vị trí không?\nCâu hỏi hỗ trợ: Thầy/Cô giúp em kiểm yêu cầu này được không?"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Công cụ hỏi bài lại xin vị trí chính xác.\n2. Nói dễ hiểu: Chưa rõ vì sao cần vị trí thì em hỏi người lớn.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Tình huống: Xin vị trí khi em hỏi bài\nĐiều chưa rõ: Vị trí giúp trả lời phần nào?\nCâu hỏi mục đích: Công cụ cần vị trí để làm gì?\nCâu hỏi lựa chọn: Em có thể không gửi vị trí không?\nCâu hỏi hỗ trợ: Thầy/Cô giúp em kiểm yêu cầu này được không?",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Công cụ hỏi bài lại xin vị trí chính xác.",
          "tone": "key",
          "note": "Thầy/Cô: Công cụ hỏi bài lại xin vị trí chính xác."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chưa rõ vì sao cần vị trí thì em hỏi người lớn.",
          "tone": "explain",
          "note": "Thầy/Cô: Chưa rõ vì sao cần vị trí thì em hỏi người lớn."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em sẽ viết câu nhờ hỗ trợ thế nào? Gợi ý: Thầy/Cô giúp em kiểm yêu cầu này được không?"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P6.3 Quyền truy cập và thẻ an toàn",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Ví dụ câu 1: Ứng dụng cần dữ liệu này để làm gì?",
          "Ví dụ câu 2: Em có thể không cung cấp thông tin không cần cho nhiệm vụ không?",
          "Ví dụ câu 3: Em có thể nhờ Thầy/Cô hoặc cha mẹ cùng kiểm tra yêu cầu này không?",
          "Chấp nhận cách diễn đạt khác nếu giúp quyết định trước khi cấp quyền."
        ],
        "pages": [
          {
            "title": "Ba câu hỏi an toàn",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Dữ liệu được xin dùng để làm gì? — em sẽ hỏi thế nào?",
                "key": "06-23-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ba câu hỏi an toàn",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có thể từ chối thông tin không cần thiết không? — em sẽ hỏi thế nào?",
                "key": "06-23-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Ba câu hỏi an toàn",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ nhờ ai hỗ trợ khi chưa rõ?",
                "key": "06-23-v3-2"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 3,
      "id": "06-23",
      "title": "P6.3B — Ba câu hỏi trước khi chia sẻ",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Hoàn thành thẻ an toàn của em theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Khi chưa rõ mục đích hoặc quyền truy cập, dừng và hỏi người có trách nhiệm.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Ví dụ câu 1: Ứng dụng cần dữ liệu này để làm gì?",
          "Ví dụ câu 2: Em có thể không cung cấp thông tin không cần cho nhiệm vụ không?",
          "Ví dụ câu 3: Em có thể nhờ Thầy/Cô hoặc cha mẹ cùng kiểm tra yêu cầu này không?",
          "Chấp nhận cách diễn đạt khác nếu giúp quyết định trước khi cấp quyền."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Dữ liệu này dùng làm gì? Em có thể không gửi không? Em có thể nhờ ai kiểm cùng?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Ví dụ câu 1: Ứng dụng cần dữ liệu này để làm gì?\nVí dụ câu 2: Em có thể không cung cấp thông tin không cần cho nhiệm vụ không?\nVí dụ câu 3: Em có thể nhờ Thầy/Cô hoặc cha mẹ cùng kiểm tra yêu cầu này không?\nChấp nhận cách diễn đạt khác nếu giúp quyết định trước khi cấp quyền.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dữ liệu này dùng làm gì?",
        "Em có thể không gửi không?",
        "Em có thể nhờ ai kiểm cùng?"
      ],
      "phase": "Vận dụng",
      "scene": "privacy",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "06-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [
        "Dữ liệu này dùng làm gì?",
        "Em có thể không gửi không?",
        "Em có thể nhờ ai kiểm cùng?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P6.3B · Em tự làm"
    },
    {
      "type": "home",
      "id": "06-24",
      "title": "Nhìn lại một yêu cầu quyền",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Tạo cam kết sử dụng AI có trách nhiệm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Khi chưa rõ mục đích hoặc quyền truy cập, dừng và hỏi người có trách nhiệm.",
        "assessment": "Thẻ là minh chứng nhận thức. Kết hợp bản xử lí để nhận xét thao tác bảo vệ dữ liệu.",
        "answers": [
          "Khi chưa rõ mục đích hoặc quyền truy cập, dừng và hỏi người có trách nhiệm."
        ],
        "source": "Bài 12 Đạo đức AI quyền riêng tư và công bằng, mục AI thu thập thông tin cá nhân và rủi ro, trang in 90–91; tình huống trách nhiệm trang in 94. Bài dạy không khẳng định mọi ứng dụng đều thu thập mọi loại dữ liệu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chọn tình huống ví dụ tạo sẵn.\n2. Nói dễ hiểu: Nêu mục đích của quyền.\n3. Điều cần nhớ: Ghi câu hỏi còn chưa rõ.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Khi chưa rõ mục đích hoặc quyền truy cập, dừng và hỏi người có trách nhiệm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn tình huống ví dụ tạo sẵn.",
        "Nêu mục đích của quyền.",
        "Ghi câu hỏi còn chưa rõ."
      ],
      "phase": "Vận dụng",
      "scene": "privacy",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 30,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn tình huống ví dụ tạo sẵn.",
        "Nêu mục đích của quyền.",
        "Ghi câu hỏi còn chưa rõ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chọn tình huống ví dụ tạo sẵn.",
          "tone": "key",
          "note": "Thầy/Cô: Chọn tình huống ví dụ tạo sẵn."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nêu mục đích của quyền.",
          "tone": "explain",
          "note": "Thầy/Cô: Nêu mục đích của quyền."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi câu hỏi còn chưa rõ.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi câu hỏi còn chưa rõ."
        }
      ]
    }
  ],
  "rubric": [],
  "evidence": [
    [
      "Phân tích dữ liệu",
      "4.2.TC1a",
      "Giải thích cách bảo vệ dữ liệu cá nhân.",
      "P6.1, lời giải thích",
      "Nêu đúng dữ liệu cần bỏ và lí do."
    ],
    [
      "Xử lí bản chia sẻ",
      "4.2.TC1b",
      "Loại thông tin định danh không cần thiết.",
      "P6.2 và quan sát",
      "Kiểm tra bản cuối; thao tác giấy chưa đủ chứng minh dùng công cụ số."
    ],
    [
      "Chọn cách dùng công cụ",
      "6.2.TC1c",
      "Xem xét riêng tư và bảo mật trước sử dụng.",
      "P6.3 cá nhân",
      "Có câu hỏi mục đích/quyền/hỗ trợ, không cấp quyền theo thói quen."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
