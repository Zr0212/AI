window.AI6_LESSON={
  "id": 11,
  "title": "Dự án tại nhà - Giai đoạn 3: Tạo sản phẩm",
  "mode": "Dự án tại nhà · tự làm, có thể chia phiên",
  "count": 20,
  "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 6,
    "title": "AI: How Chatbots and Large Language Models Work",
    "start": 85,
    "end": 115,
    "poster": "frame_6_95.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/5PAq7BvRs4dvpeDtdBeciP/df29bc68f49899c2eb16c161b6e4698d/HowAIWorks_LLM_SM_CoBrand__1_.mp4",
    "question": "Hình robot biểu diễn ý tưởng. Sản phẩm của nhóm có chức năng chạy thật hay đang mô tả thiết kế?",
    "local": "code-6.mp4"
  },
  "outcome": "Bản 1, nguồn và phần việc của từng em.",
  "slides": [
    {
      "type": "cover",
      "id": "11-01",
      "title": "Dự án tại nhà - Giai đoạn 3: Tạo sản phẩm",
      "note": {
        "activity": "Xem lại thiết kế",
        "purpose": "Chuyển thiết kế thành cấu trúc sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Nhóm lưu lựa chọn và lí do trong nhật kí.",
        "conclusion": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "assessment": "Kiểm tra nhóm có đủ nội dung trước khi thiết kế chi tiết.",
        "answers": [
          "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "credits",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "11-02",
      "title": "Giai đoạn này cần hoàn thành gì?",
      "note": {
        "activity": "Xem lại thiết kế",
        "purpose": "Chuyển thiết kế thành cấu trúc sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu lựa chọn và lí do trong nhật kí.",
        "conclusion": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "assessment": "Kiểm tra nhóm có đủ nội dung trước khi thiết kế chi tiết.",
        "answers": [
          "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tạo bản 1 từ thiết kế đã chốt.\n2. Nói dễ hiểu: Ghi nguồn và việc từng người làm.\n3. Điều cần nhớ: Ghi đúng ý tưởng hay mô hình đã chạy.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tạo bản 1 từ thiết kế đã chốt.",
        "Ghi nguồn và việc từng người làm.",
        "Ghi đúng ý tưởng hay mô hình đã chạy."
      ],
      "phase": "Khởi động",
      "scene": "credits",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Tạo bản 1 từ thiết kế đã chốt.",
        "Ghi nguồn và việc từng người làm.",
        "Ghi đúng ý tưởng hay mô hình đã chạy."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tạo bản 1 từ thiết kế đã chốt.",
          "tone": "key",
          "note": "Thầy/Cô: Tạo bản 1 từ thiết kế đã chốt."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi nguồn và việc từng người làm.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi nguồn và việc từng người làm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi đúng ý tưởng hay mô hình đã chạy.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi đúng ý tưởng hay mô hình đã chạy."
        }
      ]
    },
    {
      "type": "divider",
      "id": "11-03",
      "title": "Khởi động: xem lại thiết kế",
      "note": {
        "activity": "Xem lại thiết kế",
        "purpose": "Chuyển thiết kế thành cấu trúc sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm lưu lựa chọn và lí do trong nhật kí.",
        "conclusion": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "assessment": "Kiểm tra nhóm có đủ nội dung trước khi thiết kế chi tiết.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "credits",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "id": "11-04",
      "title": "Từ thiết kế sang bản 1",
      "note": {
        "activity": "Xem lại thiết kế",
        "purpose": "Chuyển thiết kế thành cấu trúc sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu lựa chọn và lí do trong nhật kí.",
        "conclusion": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "assessment": "Kiểm tra nhóm có đủ nội dung trước khi thiết kế chi tiết.",
        "answers": [
          "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đọc góp ý giai đoạn 2.\n2. Nói dễ hiểu: Chốt hình thức sản phẩm.\n3. Điều cần nhớ: Chia phần nội dung để cùng làm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đọc góp ý giai đoạn 2.",
        "Chốt hình thức sản phẩm.",
        "Chia phần nội dung để cùng làm."
      ],
      "phase": "Khởi động",
      "scene": "credits",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Đọc góp ý giai đoạn 2.",
        "Chốt hình thức sản phẩm.",
        "Chia phần nội dung để cùng làm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đọc góp ý giai đoạn 2.",
          "tone": "key",
          "note": "Thầy/Cô: Đọc góp ý giai đoạn 2."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chốt hình thức sản phẩm.",
          "tone": "explain",
          "note": "Thầy/Cô: Chốt hình thức sản phẩm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chia phần nội dung để cùng làm.",
          "tone": "action",
          "note": "Thầy/Cô: Chia phần nội dung để cùng làm."
        }
      ]
    },
    {
      "type": "concept",
      "id": "11-05",
      "title": "Một sản phẩm cần nói rõ gì?",
      "note": {
        "activity": "Xem lại thiết kế",
        "purpose": "Chuyển thiết kế thành cấu trúc sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu lựa chọn và lí do trong nhật kí.",
        "conclusion": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "assessment": "Kiểm tra nhóm có đủ nội dung trước khi thiết kế chi tiết.",
        "answers": [
          "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Người xem chưa biết áp phích của nhóm giúp gì.\n2. Nói dễ hiểu: Nêu người dùng, ví dụ và cách kiểm kết quả.\n3. Điều cần nhớ: Ghi phần AI, người kiểm, giới hạn và nguồn.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Vấn đề, người dùng và phần AI hỗ trợ.",
        "Ví dụ sử dụng và cách kiểm.",
        "Giới hạn, riêng tư và nguồn."
      ],
      "phase": "Khám phá",
      "scene": "credits",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [
        "Vấn đề, người dùng và phần AI hỗ trợ.",
        "Ví dụ sử dụng và cách kiểm.",
        "Giới hạn, riêng tư và nguồn."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Người xem chưa biết áp phích của nhóm giúp gì.",
          "tone": "key",
          "note": "Thầy/Cô: Người xem chưa biết áp phích của nhóm giúp gì."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nêu người dùng, ví dụ và cách kiểm kết quả.",
          "tone": "explain",
          "note": "Thầy/Cô: Nêu người dùng, ví dụ và cách kiểm kết quả."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi phần AI, người kiểm, giới hạn và nguồn.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi phần AI, người kiểm, giới hạn và nguồn."
        }
      ]
    },
    {
      "type": "concept",
      "id": "11-07",
      "title": "Ý tưởng hay mô hình đã chạy?",
      "note": {
        "activity": "Xem lại thiết kế",
        "purpose": "Chuyển thiết kế thành cấu trúc sản phẩm.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu lựa chọn và lí do trong nhật kí.",
        "conclusion": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "assessment": "Kiểm tra nhóm có đủ nội dung trước khi thiết kế chi tiết.",
        "answers": [
          "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Áp phích mô tả AI nhưng chưa chạy công cụ.\n2. Nói dễ hiểu: Đó là ý tưởng, chưa có kết quả thử thật.\n3. Điều cần nhớ: Ghi rõ Ý tưởng; không ghi AI đã chạy.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Hình thức phục vụ ý tưởng. Mức độ phức tạp không quyết định chất lượng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ý tưởng: mô tả cách dự kiến hoạt động.",
        "Đã chạy: có thao tác và kết quả thật.",
        "Hình robot chưa chứng minh đã chạy."
      ],
      "phase": "Khám phá",
      "scene": "credits",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "Ý tưởng: mô tả cách dự kiến hoạt động.",
        "Đã chạy: có thao tác và kết quả thật.",
        "Hình robot chưa chứng minh đã chạy."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Áp phích mô tả AI nhưng chưa chạy công cụ.",
          "tone": "key",
          "note": "Thầy/Cô: Áp phích mô tả AI nhưng chưa chạy công cụ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đó là ý tưởng, chưa có kết quả thử thật.",
          "tone": "explain",
          "note": "Thầy/Cô: Đó là ý tưởng, chưa có kết quả thử thật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi rõ Ý tưởng; không ghi AI đã chạy.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi rõ Ý tưởng; không ghi AI đã chạy."
        }
      ]
    },
    {
      "id": "11-08-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu dùng lại bản thiết kế",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "worked": {
        "title": "Mẫu dùng lại bản thiết kế",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Hình thức",
          "Nhu cầu",
          "AI hỗ trợ",
          "Ví dụ và cách kiểm",
          "Giới hạn và nguồn"
        ],
        "values": [
          "Áp phích ý tưởng",
          "Hiểu ba từ trong bài",
          "Gợi nghĩa và câu ví dụ",
          "Một câu mẫu, so nghĩa bằng bảng từ",
          "Ghi nguồn đã đọc, không thu tên, địa chỉ"
        ],
        "why": [
          "Dùng lại thiết kế, không chọn việc mới.",
          "Ví dụ cần chỉ cách người kiểm.",
          "Ghi rõ chưa chạy hệ thống thật."
        ],
        "question": "Nhóm cần ghi giới hạn và nguồn ra sao?",
        "scene": "Idea"
      },
      "targetId": "11-08",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Ghi nguồn đã đọc, không thu tên, địa chỉ",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Hình thức: Áp phích ý tưởng\nNhu cầu: Hiểu ba từ trong bài\nAI hỗ trợ: Gợi nghĩa và câu ví dụ\nVí dụ và cách kiểm: Một câu mẫu, so nghĩa bằng bảng từ\nGiới hạn và nguồn: Ghi nguồn đã đọc, không thu tên, địa chỉ"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm làm áp phích về ba từ tiếng Anh.\n2. Nói dễ hiểu: Dùng lại thiết kế, thêm ví dụ và nguồn đã đọc.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Hình thức: Áp phích ý tưởng\nNhu cầu: Hiểu ba từ trong bài\nAI hỗ trợ: Gợi nghĩa và câu ví dụ\nVí dụ và cách kiểm: Một câu mẫu, so nghĩa bằng bảng từ\nGiới hạn và nguồn: Ghi nguồn đã đọc, không thu tên, địa chỉ",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm làm áp phích về ba từ tiếng Anh.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm làm áp phích về ba từ tiếng Anh."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Dùng lại thiết kế, thêm ví dụ và nguồn đã đọc.",
          "tone": "explain",
          "note": "Thầy/Cô: Dùng lại thiết kế, thêm ví dụ và nguồn đã đọc."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Nhóm cần ghi giới hạn và nguồn ra sao? Gợi ý: Ghi nguồn đã đọc, không thu tên, địa chỉ"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P11.1 Nội dung sản phẩm bản 1",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Đạt nội dung khi đủ sáu phần và nhãn mức độ hoạt động. Một ví dụ minh họa có thể dùng dữ liệu giả nhưng phải ghi rõ.",
          "Nếu mô hình chạy thật, ghi cách thử/kết quả thật. Không dựng độ chính xác hoặc ảnh kết quả. Không cần mô hình chạy thật để đạt mục tiêu dự án theo khung."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Có thể làm áp phích, vài slide, kịch bản hình, mô hình giấy hoặc video.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Nếu nói đã chạy thử, cần có kết quả thật.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Chọn sản phẩm bản đầu",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tên dự án và hình thức sản phẩm",
                "key": "11-08-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn sản phẩm bản đầu",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Sản phẩm hiện ở mức nào?",
                "options": [
                  "Ý tưởng minh họa",
                  "Mô hình đã chạy thử"
                ],
                "key": "11-08-v3-1",
                "optionLabels": [
                  "Ý tưởng minh họa",
                  "Mô hình đã chạy thử"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Soạn nội dung — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vấn đề, người dùng và mục tiêu",
                "key": "11-08-v3-2"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Soạn nội dung — bước 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Dữ liệu vào, việc AI làm và kết quả",
                "key": "11-08-v3-3"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Soạn nội dung — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Một ví dụ sử dụng",
                "key": "11-08-v3-4"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Soạn nội dung — bước 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Con người kiểm tra và xử lí khi kết quả sai",
                "key": "11-08-v3-5"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Soạn nội dung — bước 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Hạn chế và thông tin cá nhân không thu thập",
                "key": "11-08-v3-6"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Soạn nội dung — bước 3",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nguồn thông tin/hình ảnh và công cụ đã dùng",
                "key": "11-08-v3-7"
              }
            ],
            "originalPage": 3
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4,
          "2": 6,
          "3": 8
        }
      },
      "id": "11-08",
      "title": "P11.1 — Dùng lại thiết kế để soạn",
      "note": {
        "activity": "Tạo sản phẩm bản 1",
        "purpose": "Hoàn thành nội dung bản 1 theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm lưu bản trước chỉnh sửa và một ghi chép của từng thành viên.",
        "conclusion": "Sản phẩm phải trung thực: không biến minh họa thành kết quả thử, không nhận toàn bộ nội dung hỗ trợ là do mình tự làm.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Đạt nội dung khi đủ sáu phần và nhãn mức độ hoạt động. Một ví dụ minh họa có thể dùng dữ liệu giả nhưng phải ghi rõ.",
          "Nếu mô hình chạy thật, ghi cách thử/kết quả thật. Không dựng độ chính xác hoặc ảnh kết quả. Không cần mô hình chạy thật để đạt mục tiêu dự án theo khung."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Lấy nội dung đã chốt. Bổ sung ví dụ, giới hạn và nguồn. Sửa phần còn thiếu.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Đạt nội dung khi đủ sáu phần và nhãn mức độ hoạt động. Một ví dụ minh họa có thể dùng dữ liệu giả nhưng phải ghi rõ.\nNếu mô hình chạy thật, ghi cách thử/kết quả thật. Không dựng độ chính xác hoặc ảnh kết quả. Không cần mô hình chạy thật để đạt mục tiêu dự án theo khung.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "reuseKind": "design",
      "v6": true,
      "screen": [
        "Lấy nội dung đã chốt.",
        "Bổ sung ví dụ, giới hạn và nguồn.",
        "Sửa phần còn thiếu."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "11-08-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Lấy nội dung đã chốt.",
        "Bổ sung ví dụ, giới hạn và nguồn.",
        "Sửa phần còn thiếu."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P11.1 · Soạn từ thiết kế"
    },
    {
      "type": "divider",
      "id": "11-09",
      "title": "Thực hành: làm sản phẩm bản 1",
      "note": {
        "activity": "Tạo sản phẩm bản 1",
        "purpose": "Tạo nội dung có ví dụ và nguồn rõ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm lưu bản trước chỉnh sửa và một ghi chép của từng thành viên.",
        "conclusion": "Sản phẩm phải trung thực: không biến minh họa thành kết quả thử, không nhận toàn bộ nội dung hỗ trợ là do mình tự làm.",
        "assessment": "Đạt khi có đủ phần cốt lõi, nguồn và bảng ghi. Sản phẩm giấy được nhận xét nội dung, chưa đủ mọi minh chứng thao tác số.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 9,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "11-10-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu chia phần làm bản 1",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "roles",
      "worked": {
        "title": "Mẫu chia phần làm bản 1",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Em A",
          "Em B",
          "Em C",
          "Cùng kiểm",
          "Cách ghi việc"
        ],
        "values": [
          "Soạn mục tiêu và ví dụ",
          "Vẽ cách AI hỗ trợ và người kiểm",
          "Dàn trang và ghi nguồn",
          "Đọc lại ví dụ, thử mở tệp",
          "Mỗi em ghi phần trực tiếp tạo hoặc sửa"
        ],
        "why": [
          "Người phụ trách vẫn cần các em góp ý.",
          "Không để một em làm toàn bộ.",
          "Dấu đã làm phải gắn việc thật."
        ],
        "question": "Mỗi em cần ghi việc của em thế nào?",
        "scene": "Roles"
      },
      "targetId": "11-10",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mỗi em ghi phần trực tiếp tạo hoặc sửa",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Em A: Soạn mục tiêu và ví dụ\nEm B: Vẽ cách AI hỗ trợ và người kiểm\nEm C: Dàn trang và ghi nguồn\nCùng kiểm: Đọc lại ví dụ, thử mở tệp\nCách ghi việc: Mỗi em ghi phần trực tiếp tạo hoặc sửa"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ba em cùng tạo áp phích bản 1.\n2. Nói dễ hiểu: Mỗi em tạo một phần và ghi việc có thật.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Em A: Soạn mục tiêu và ví dụ\nEm B: Vẽ cách AI hỗ trợ và người kiểm\nEm C: Dàn trang và ghi nguồn\nCùng kiểm: Đọc lại ví dụ, thử mở tệp\nCách ghi việc: Mỗi em ghi phần trực tiếp tạo hoặc sửa",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 10,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ba em cùng tạo áp phích bản 1.",
          "tone": "key",
          "note": "Thầy/Cô: Ba em cùng tạo áp phích bản 1."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mỗi em tạo một phần và ghi việc có thật.",
          "tone": "explain",
          "note": "Thầy/Cô: Mỗi em tạo một phần và ghi việc có thật."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Mỗi em cần ghi việc của em thế nào? Gợi ý: Mỗi em ghi phần trực tiếp tạo hoặc sửa"
        }
      ]
    },
    {
      "type": "task",
      "id": "11-10",
      "title": "Tạo bản 1, mỗi em làm một phần",
      "note": {
        "activity": "Tạo sản phẩm bản 1",
        "purpose": "Tạo nội dung có ví dụ và nguồn rõ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm phần được giao; ghi kết quả thật.",
        "report": "Nhóm lưu bản trước chỉnh sửa và một ghi chép của từng thành viên.",
        "conclusion": "Sản phẩm phải trung thực: không biến minh họa thành kết quả thử, không nhận toàn bộ nội dung hỗ trợ là do mình tự làm.",
        "assessment": "Đạt khi có đủ phần cốt lõi, nguồn và bảng ghi. Sản phẩm giấy được nhận xét nội dung, chưa đủ mọi minh chứng thao tác số.",
        "answers": [
          "Sản phẩm phải trung thực: không biến minh họa thành kết quả thử, không nhận toàn bộ nội dung hỗ trợ là do em tự làm."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Làm theo bố cục đã chốt.\n2. Nói dễ hiểu: Ghi nguồn khi thêm nội dung.\n3. Điều cần nhớ: Ghi thao tác số đã làm hoặc cần hỗ trợ.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em làm phần được giao; ghi kết quả thật.",
          "answer": "Sản phẩm phải trung thực: không biến minh họa thành kết quả thử, không nhận toàn bộ nội dung hỗ trợ là do em tự làm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “mẫu · đánh dấu việc em đã làm”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Làm theo bố cục đã chốt.",
        "Ghi nguồn khi thêm nội dung.",
        "Ghi thao tác số đã làm hoặc cần hỗ trợ."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "taskLines": [
        "Trong 11 phút, nhóm em tạo bản 1 theo thiết kế."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "11-10-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [
        "Làm theo bố cục đã chốt.",
        "Ghi nguồn khi thêm nội dung.",
        "Ghi thao tác số đã làm hoặc cần hỗ trợ."
      ],
      "pupilTask": "Em làm phần được giao; ghi kết quả thật.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Làm theo bố cục đã chốt.",
          "tone": "key",
          "note": "Thầy/Cô: Làm theo bố cục đã chốt."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi nguồn khi thêm nội dung.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi nguồn khi thêm nội dung."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi thao tác số đã làm hoặc cần hỗ trợ.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi thao tác số đã làm hoặc cần hỗ trợ."
        }
      ]
    },
    {
      "id": "11-v7-contribution",
      "type": "guide",
      "title": "Mẫu · Đánh dấu việc em đã làm",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Chỉ đánh dấu phần em trực tiếp tạo hoặc sửa.",
        "Ghi tên tệp hoặc vị trí để xem lại.",
        "Không ghi giúp việc chưa xảy ra."
      ],
      "scene": "credits",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "✓ Dàn trang, ghi nguồn, mở thử tệp",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Chỉ đánh dấu phần em trực tiếp tạo hoặc sửa. / Ghi tên tệp hoặc vị trí để xem lại. / Không ghi giúp việc chưa xảy ra."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Mẫu · Đánh dấu việc em đã làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chỉ đánh dấu phần em trực tiếp tạo hoặc sửa.\n2. Nói dễ hiểu: Ghi tên tệp hoặc vị trí để xem lại.\n3. Điều cần nhớ: Không ghi giúp việc chưa xảy ra.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Chỉ đánh dấu phần em trực tiếp tạo hoặc sửa. / Ghi tên tệp hoặc vị trí để xem lại. / Không ghi giúp việc chưa xảy ra.",
          "closing": "Thầy/Cô chốt: Không ghi giúp việc chưa xảy ra.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "guideTable": {
        "headers": [
          "Thành viên",
          "Đã làm",
          "Bằng chứng"
        ],
        "rows": [
          [
            "Em A",
            "✓ Chụp ảnh, so nguồn",
            "coc_nhom.jpg"
          ],
          [
            "Em B",
            "✓ Sửa nghĩa của một từ",
            "Thẻ từ số 2"
          ],
          [
            "Em C",
            "✓ Dàn trang, mở thử",
            "Bản 1 của áp phích"
          ]
        ],
        "label": "Bảng mẫu; thay bằng việc thật của từng em."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 12,
      "originalTeachingPoints": [
        "Chỉ đánh dấu phần em trực tiếp tạo hoặc sửa.",
        "Ghi tên tệp hoặc vị trí để xem lại.",
        "Không ghi giúp việc chưa xảy ra."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chỉ đánh dấu phần em trực tiếp tạo hoặc sửa.",
          "tone": "key",
          "note": "Thầy/Cô: Chỉ đánh dấu phần em trực tiếp tạo hoặc sửa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi tên tệp hoặc vị trí để xem lại.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi tên tệp hoặc vị trí để xem lại."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không ghi giúp việc chưa xảy ra.",
          "tone": "action",
          "note": "Thầy/Cô: Không ghi giúp việc chưa xảy ra."
        }
      ]
    },
    {
      "id": "11-11-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu · Ghi nguồn tư liệu đã dùng",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "worked": {
        "title": "Mẫu ghi nguồn và việc đã làm",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Tư liệu",
          "Ai tạo / nơi lấy",
          "Vị trí nguồn",
          "Phần dùng",
          "Đã kiểm gì?"
        ],
        "values": [
          "Ảnh cốc",
          "Em A tự chụp",
          "Tệp coc_nhom.jpg của nhóm",
          "Ảnh minh họa trên áp phích",
          "Không có mặt người hoặc thông tin riêng"
        ],
        "why": [
          "Tự chụp cũng cần ghi ai tạo ảnh.",
          "Chỉ ghi nguồn thật sự đã đọc.",
          "Dấu ✓ đi với một việc cụ thể."
        ],
        "question": "Dòng em C nên ghi việc cụ thể nào?",
        "scene": "Credits"
      },
      "targetId": "11-11",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "✓ Dàn trang, ghi nguồn, mở thử tệp",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tư liệu: Ảnh cốc\nAi tạo / nơi lấy: Em A tự chụp\nVị trí nguồn: Tệp coc_nhom.jpg của nhóm\nPhần dùng: Ảnh minh họa trên áp phích\nĐã kiểm gì?: Không có mặt người hoặc thông tin riêng"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm dùng một ảnh cốc do em A chụp.\n2. Nói dễ hiểu: Ghi người tạo, tên tệp và phần tư liệu dùng.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Tư liệu: Ảnh cốc\nAi tạo / nơi lấy: Em A tự chụp\nVị trí nguồn: Tệp coc_nhom.jpg của nhóm\nPhần dùng: Ảnh minh họa trên áp phích\nĐã kiểm gì?: Không có mặt người hoặc thông tin riêng",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm dùng một ảnh cốc do em A chụp.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm dùng một ảnh cốc do em A chụp."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi người tạo, tên tệp và phần tư liệu dùng.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi người tạo, tên tệp và phần tư liệu dùng."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Dòng em C nên ghi việc cụ thể nào? Gợi ý: Không có mặt người hoặc thông tin riêng"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P11.2 bảng ghi nguồn và đóng góp",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Ghi nguồn đủ nhận diện. Ảnh tự vẽ/tự chụp ghi đúng tính chất. Không mặc định mọi ảnh tìm được đều được phép dùng.",
          "Không đánh giá đóng góp chỉ qua số dòng bảng ghi. Thầy/Cô đối chiếu sản phẩm và câu trả lời cá nhân."
        ],
        "pages": [
          {
            "title": "Ghi đóng góp — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thành viên và việc đã làm",
              "Nguồn/công cụ đã dùng",
              "Đã kiểm tra hoặc sửa gì?"
            ],
            "rows": [
              [
                {
                  "label": "Thành viên 1 và phần việc",
                  "key": "11-11-v3-0"
                },
                {
                  "label": "Nguồn của thành viên 1",
                  "key": "11-11-v3-1"
                },
                {
                  "label": "Kiểm tra của thành viên 1",
                  "key": "11-11-v3-2"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi đóng góp — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thành viên và việc đã làm",
              "Nguồn/công cụ đã dùng",
              "Đã kiểm tra hoặc sửa gì?"
            ],
            "rows": [
              [
                {
                  "label": "Thành viên 2 và phần việc",
                  "key": "11-11-v3-3"
                },
                {
                  "label": "Nguồn của thành viên 2",
                  "key": "11-11-v3-4"
                },
                {
                  "label": "Kiểm tra của thành viên 2",
                  "key": "11-11-v3-5"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi đóng góp — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thành viên và việc đã làm",
              "Nguồn/công cụ đã dùng",
              "Đã kiểm tra hoặc sửa gì?"
            ],
            "rows": [
              [
                {
                  "label": "Thành viên 3 và phần việc",
                  "key": "11-11-v3-6"
                },
                {
                  "label": "Nguồn của thành viên 3",
                  "key": "11-11-v3-7"
                },
                {
                  "label": "Kiểm tra của thành viên 3",
                  "key": "11-11-v3-8"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi đóng góp — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Thành viên và việc đã làm",
              "Nguồn/công cụ đã dùng",
              "Đã kiểm tra hoặc sửa gì?"
            ],
            "rows": [
              [
                {
                  "label": "Thành viên 4 và phần việc",
                  "key": "11-11-v3-9"
                },
                {
                  "label": "Nguồn của thành viên 4",
                  "key": "11-11-v3-10"
                },
                {
                  "label": "Kiểm tra của thành viên 4",
                  "key": "11-11-v3-11"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi nguồn rõ ràng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ảnh trong sản phẩm do ai chụp/vẽ, hoặc lấy từ đâu?",
                "key": "11-11-v3-12"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Ghi nguồn rõ ràng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Thông tin lấy từ tài liệu nào, trang hoặc đường dẫn nào?",
                "key": "11-11-v3-13"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Ghi nguồn rõ ràng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã kiểm phần AI hỗ trợ thế nào?",
                "key": "11-11-v3-14"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2,
          "2": 4
        }
      },
      "id": "11-11",
      "title": "P11.2 — Ghi nguồn và đóng góp",
      "note": {
        "activity": "Tạo sản phẩm bản 1",
        "purpose": "Hoàn thành nguồn và đóng góp theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm lưu bản trước chỉnh sửa và một ghi chép của từng thành viên.",
        "conclusion": "Sản phẩm phải trung thực: không biến minh họa thành kết quả thử, không nhận toàn bộ nội dung hỗ trợ là do mình tự làm.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Ghi nguồn đủ nhận diện. Ảnh tự vẽ/tự chụp ghi đúng tính chất. Không mặc định mọi ảnh tìm được đều được phép dùng.",
          "Không đánh giá đóng góp chỉ qua số dòng bảng ghi. Thầy/Cô đối chiếu sản phẩm và câu trả lời cá nhân."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Ai làm phần nào? Đã dùng nguồn hoặc công cụ gì? Đã kiểm hoặc sửa điều gì?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Ghi nguồn đủ nhận diện. Ảnh tự vẽ/tự chụp ghi đúng tính chất. Không mặc định mọi ảnh tìm được đều được phép dùng.\nKhông đánh giá đóng góp chỉ qua số dòng bảng ghi. Thầy/Cô đối chiếu sản phẩm và câu trả lời cá nhân.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ai làm phần nào?",
        "Đã dùng nguồn hoặc công cụ gì?",
        "Đã kiểm hoặc sửa điều gì?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "11-11-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [
        "Ai làm phần nào?",
        "Đã dùng nguồn hoặc công cụ gì?",
        "Đã kiểm hoặc sửa điều gì?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P11.2 · Nguồn và đóng góp"
    },
    {
      "type": "divider",
      "id": "11-12",
      "title": "Tự kiểm tra bản 1",
      "note": {
        "activity": "Tự kiểm tra bản đầu",
        "purpose": "Phát hiện thiếu nội dung, nguồn hoặc giới hạn.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Ghi điểm đã sửa và điểm cần xin góp ý ở giai đoạn 4.",
        "conclusion": "Tự kiểm tra giúp bản đầu đủ rõ để nhận góp ý có ích.",
        "assessment": "Không yêu cầu mọi mục phải đạt ngay. Yêu cầu ghi rõ điều chưa xong.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "11-13-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu kiểm trước khi hỏi góp ý",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "worked": {
        "title": "Mẫu kiểm trước khi hỏi góp ý",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Điểm đã có",
          "Vị trí",
          "Điểm còn thiếu",
          "Điều cần sửa",
          "Câu xin góp ý"
        ],
        "values": [
          "Tên dự án và nguồn",
          "Tiêu đề trên, dòng nguồn dưới",
          "Chưa có người kiểm nghĩa",
          "Thêm bước so bảng từ",
          "Bước người kiểm này đã đủ rõ chưa?"
        ],
        "why": [
          "Chỉ vào vị trí thật trong bản 1.",
          "Ưu tiên nội dung trước màu sắc.",
          "Câu hỏi cần giúp nhóm sửa tiếp."
        ],
        "question": "Nhóm nên hỏi góp ý bằng câu nào?",
        "scene": "Credits"
      },
      "targetId": "11-13",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Bước người kiểm này đã đủ rõ chưa?",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Điểm đã có: Tên dự án và nguồn\nVị trí: Tiêu đề trên, dòng nguồn dưới\nĐiểm còn thiếu: Chưa có người kiểm nghĩa\nĐiều cần sửa: Thêm bước so bảng từ\nCâu xin góp ý: Bước người kiểm này đã đủ rõ chưa?"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Áp phích có nguồn, nhưng thiếu cách kiểm nghĩa.\n2. Nói dễ hiểu: Góp ý cụ thể chỉ ra chỗ còn thiếu để sửa.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Điểm đã có: Tên dự án và nguồn\nVị trí: Tiêu đề trên, dòng nguồn dưới\nĐiểm còn thiếu: Chưa có người kiểm nghĩa\nĐiều cần sửa: Thêm bước so bảng từ\nCâu xin góp ý: Bước người kiểm này đã đủ rõ chưa?",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Áp phích có nguồn, nhưng thiếu cách kiểm nghĩa.",
          "tone": "key",
          "note": "Thầy/Cô: Áp phích có nguồn, nhưng thiếu cách kiểm nghĩa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Góp ý cụ thể chỉ ra chỗ còn thiếu để sửa.",
          "tone": "explain",
          "note": "Thầy/Cô: Góp ý cụ thể chỉ ra chỗ còn thiếu để sửa."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Nhóm nên hỏi góp ý bằng câu nào? Gợi ý: Bước người kiểm này đã đủ rõ chưa?"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P11.3 Kiểm tra bản đầu",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Ưu tiên sửa lỗi kiến thức, thiếu kiểm tra hoặc riêng tư trước bố cục. Ghi Chưa có căn cứ vẫn tốt hơn tích đạt không có bằng chứng.",
          "Nếu chỉ làm giấy, nhận xét nội dung và ghi cần hỗ trợ thao tác số, không tự công nhận đầy đủ 3.1.TC1a."
        ],
        "pages": [
          {
            "title": "Rà bản đầu — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Nêu rõ vấn đề và người dùng.",
                {
                  "label": "Nêu rõ vấn đề và người dùng. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "11-13-v3-0",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Nêu rõ vấn đề và người dùng. — ghi chú",
                  "key": "11-13-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Rà bản đầu — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Mô tả đúng việc AI làm và dữ liệu vào/ra.",
                {
                  "label": "Mô tả đúng việc AI làm và dữ liệu vào/ra. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "11-13-v3-2",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Mô tả đúng việc AI làm và dữ liệu vào/ra. — ghi chú",
                  "key": "11-13-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Rà bản đầu — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Phân biệt ví dụ tạo sẵn với kết quả chạy thật.",
                {
                  "label": "Phân biệt ví dụ ví dụ tạo sẵn với kết quả chạy thật. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "11-13-v3-4",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Phân biệt ví dụ ví dụ tạo sẵn với kết quả chạy thật. — ghi chú",
                  "key": "11-13-v3-5"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Rà bản đầu — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Có bước con người kiểm tra.",
                {
                  "label": "Có bước con người kiểm tra. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "11-13-v3-6",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Có bước con người kiểm tra. — ghi chú",
                  "key": "11-13-v3-7"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Rà bản đầu — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Không đưa thông tin riêng tư không cần thiết.",
                {
                  "label": "Không đưa thông tin riêng tư không cần thiết. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "11-13-v3-8",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Không đưa thông tin riêng tư không cần thiết. — ghi chú",
                  "key": "11-13-v3-9"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Rà bản đầu — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Có nguồn thông tin và hình ảnh.",
                {
                  "label": "Có nguồn thông tin và hình ảnh. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "11-13-v3-10",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Có nguồn thông tin và hình ảnh. — ghi chú",
                  "key": "11-13-v3-11"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Rà bản đầu — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Mỗi thành viên có phần việc cụ thể.",
                {
                  "label": "Đóng góp từng người — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "11-13-v3-12",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Đóng góp từng người — minh chứng",
                  "key": "11-13-v3-13"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Rà bản đầu — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Mục kiểm",
              "Trạng thái",
              "Vị trí, cách sửa"
            ],
            "rows": [
              [
                "Chữ và hình dễ xem.",
                {
                  "label": "Chữ và hình — trạng thái",
                  "key": "11-13-v4-read",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Chữ và hình — điều cần sửa",
                  "key": "11-13-v4-read-note"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Xin góp ý đúng chỗ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm đã sửa điểm nào?",
                "key": "11-13-v3-14"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Xin góp ý đúng chỗ",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm muốn xin góp ý về điểm nào?",
                "key": "11-13-v3-15"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4,
          "2": 8
        }
      },
      "id": "11-13",
      "title": "P11.3 — Kiểm bản 1 bằng vị trí thật",
      "note": {
        "activity": "Tự kiểm tra bản đầu",
        "purpose": "Hoàn thành câu hỏi rà soát theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Ghi điểm đã sửa và điểm cần xin góp ý ở giai đoạn 4.",
        "conclusion": "Tự kiểm tra giúp bản đầu đủ rõ để nhận góp ý có ích.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Ưu tiên sửa lỗi kiến thức, thiếu kiểm tra hoặc riêng tư trước bố cục. Ghi Chưa có căn cứ vẫn tốt hơn tích đạt không có bằng chứng.",
          "Nếu chỉ làm giấy, nhận xét nội dung và ghi cần hỗ trợ thao tác số, không tự công nhận đầy đủ 3.1.TC1a."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Nội dung có đúng và đủ không? Nguồn, riêng tư và đóng góp đã rõ chưa? Chữ, hình có dễ xem không?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Ưu tiên sửa lỗi kiến thức, thiếu kiểm tra hoặc riêng tư trước bố cục. Ghi Chưa có căn cứ vẫn tốt hơn tích đạt không có bằng chứng.\nNếu chỉ làm giấy, nhận xét nội dung và ghi cần hỗ trợ thao tác số, không tự công nhận đầy đủ 3.1.TC1a.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nội dung có đúng và đủ không?",
        "Nguồn, riêng tư và đóng góp đã rõ chưa?",
        "Chữ, hình có dễ xem không?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "11-13-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Nội dung có đúng và đủ không?",
        "Nguồn, riêng tư và đóng góp đã rõ chưa?",
        "Chữ, hình có dễ xem không?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P11.3 · Tự kiểm bản 1"
    },
    {
      "type": "recap",
      "id": "11-14",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Tự kiểm tra bản đầu",
        "purpose": "Phát hiện thiếu nội dung, nguồn hoặc giới hạn.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Ghi điểm đã sửa và điểm cần xin góp ý ở giai đoạn 4.",
        "conclusion": "Tự kiểm tra giúp bản đầu đủ rõ để nhận góp ý có ích.",
        "assessment": "Không yêu cầu mọi mục phải đạt ngay. Yêu cầu ghi rõ điều chưa xong.",
        "answers": [
          "Tự kiểm tra giúp bản đầu đủ rõ để nhận góp ý có ích."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nói đúng ý tưởng hay đã chạy thử.\n2. Nói dễ hiểu: Ghi nguồn và đóng góp có thật.\n3. Điều cần nhớ: Sửa nội dung trước, làm rõ chữ và hình sau.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tự kiểm tra giúp bản đầu đủ rõ để nhận góp ý có ích.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nói đúng ý tưởng hay đã chạy thử.",
        "Ghi nguồn và đóng góp có thật.",
        "Sửa nội dung trước, làm rõ chữ và hình sau."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "credits",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Nói đúng ý tưởng hay đã chạy thử.",
        "Ghi nguồn và đóng góp có thật.",
        "Sửa nội dung trước, làm rõ chữ và hình sau."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nói đúng ý tưởng hay đã chạy thử.",
          "tone": "key",
          "note": "Thầy/Cô: Nói đúng ý tưởng hay đã chạy thử."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi nguồn và đóng góp có thật.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi nguồn và đóng góp có thật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Sửa nội dung trước, làm rõ chữ và hình sau.",
          "tone": "action",
          "note": "Thầy/Cô: Sửa nội dung trước, làm rõ chữ và hình sau."
        }
      ]
    },
    {
      "type": "divider",
      "id": "11-15",
      "title": "Vận dụng: gửi và xin góp ý",
      "note": {
        "activity": "Nộp bản 1 và xin góp ý",
        "purpose": "Chuẩn bị một phản hồi cụ thể để hoàn thiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm ghi người góp ý và nội dung sẽ xem xét.",
        "conclusion": "Giai đoạn 4 dùng góp ý để chỉnh sửa có lí do, không làm lại toàn bộ vì hình thức.",
        "assessment": "Thầy/Cô xem đóng góp cá nhân, không chỉ chấm người tổng hợp tệp.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Bản cần gửi đã có. Em mở thử trước khi nộp."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "credits",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "submission",
      "id": "11-16",
      "title": "Gửi bản 1 và hỏi một câu rõ",
      "note": {
        "activity": "Nộp bản 1 và xin góp ý",
        "purpose": "Chuẩn bị một phản hồi cụ thể để hoàn thiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
        "report": "Nhóm ghi người góp ý và nội dung sẽ xem xét.",
        "conclusion": "Giai đoạn 4 dùng góp ý để chỉnh sửa có lí do, không làm lại toàn bộ vì hình thức.",
        "assessment": "Thầy/Cô xem đóng góp cá nhân, không chỉ chấm người tổng hợp tệp.",
        "answers": [
          "Giai đoạn 4 dùng góp ý để chỉnh sửa có lí do, không làm lại toàn bộ vì hình thức."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Bản cần gửi đã có. Em mở thử trước khi nộp.",
          "explanation": "Nộp bản 1 và bảng ghi. Gửi một câu hỏi xin góp ý, ví dụ bước kiểm tra của con người đã rõ chưa?\nÝ cần giảng rõ: Gửi bản 1 và bảng ghi. Nêu một điều muốn được góp ý. Kiểm tệp mở được trước khi gửi.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
          "answer": "Giai đoạn 4 dùng góp ý để chỉnh sửa có lí do, không làm lại toàn bộ vì hình thức.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Gửi bản 1 và bảng ghi.",
        "Nêu một điều muốn được góp ý.",
        "Kiểm tệp mở được trước khi gửi."
      ],
      "phase": "Vận dụng",
      "scene": "credits",
      "taskLines": [
        "Trong 3 phút, em kiểm hồ sơ ở thư mục.",
        "Sau đó, em gửi tệp theo kênh của lớp."
      ],
      "connector": "Bản cần gửi đã có. Em mở thử trước khi nộp.",
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [
        "Gửi bản 1 và bảng ghi.",
        "Nêu một điều muốn được góp ý.",
        "Kiểm tệp mở được trước khi gửi."
      ],
      "pupilTask": "Em kiểm tệp; ghi phần việc rồi tải bài."
    }
  ],
  "rubric": [
    [
      "1 Vấn đề và tính khả thi",
      "Chưa nêu vấn đề/người dùng hoặc mục tiêu không thể thực hiện.",
      "Có vấn đề/người dùng nhưng mục tiêu hoặc cách thực hiện còn rộng.",
      "Vấn đề, người dùng, mục tiêu rõ. Hình thức và quy mô phù hợp điều kiện."
    ],
    [
      "2 Chức năng AI và chính xác",
      "Không mô tả đúng AI hoặc gán chức năng không có bằng chứng.",
      "Có đầu vào/đầu ra. Còn thiếu liên kết hoặc chưa rõ mức đã làm.",
      "Chức năng, đầu vào/đầu ra và ví dụ đúng. Ghi rõ minh họa hay hoạt động thật."
    ],
    [
      "3 Con người và an toàn",
      "Chưa có bước kiểm tra. Hoặc còn chia sẻ thông tin riêng không cần thiết.",
      "Có người kiểm tra nhưng cách kiểm/điều kiện riêng tư còn chung chung.",
      "Có nguồn kiểm và cách xử lí khi sai. Con người quyết định. Chỉ dùng dữ liệu cần thiết."
    ],
    [
      "4 Sản phẩm nguồn và quá trình",
      "Thiếu phần chính, nguồn hoặc bằng chứng quá trình.",
      "Sản phẩm đọc được. Còn thiếu phần, nguồn khó xem lại hoặc bảng ghi chưa rõ.",
      "Đủ nội dung. Nguồn mở lại được. Sản phẩm dễ xem. Có bảng ghi quá trình."
    ],
    [
      "5 Hợp tác chỉnh sửa giới thiệu",
      "Chưa có đóng góp, góp ý hoặc sửa bài. Chưa giới thiệu sản phẩm.",
      "Có phân công hoặc sửa nhưng lí do chưa rõ. Giới thiệu chưa đủ hoặc còn thiếu minh chứng.",
      "Có đóng góp và một sửa có lí do. Video 2–3 phút nêu rõ vai AI và người."
    ]
  ],
  "evidence": [
    [
      "Tạo bản sản phẩm",
      "3.1.TC1a",
      "Tạo và chỉnh sửa nội dung số đơn giản.",
      "Bản 1, nhật kí thao tác",
      "Có thao tác số do HS thực hiện; bản giấy cần bổ sung khi được hỗ trợ."
    ],
    [
      "Ghi nguồn",
      "2.2.TC1c",
      "Ghi chú nguồn hình ảnh, thông tin, học liệu.",
      "Nguồn trên sản phẩm, P11.2",
      "Nguồn xác định lại được và gắn nội dung dùng, kể cả học liệu GV cung cấp."
    ]
  ],
  "review": {
    "type": "video",
    "video": {
      "index": 6,
      "title": "AI: How Chatbots and Large Language Models Work",
      "start": 85,
      "end": 115,
      "poster": "frame_6_95.jpg",
      "url": "https://contentful-videos.code.org/90t6bu6vlf76/5PAq7BvRs4dvpeDtdBeciP/df29bc68f49899c2eb16c161b6e4698d/HowAIWorks_LLM_SM_CoBrand__1_.mp4",
      "question": "Sản phẩm là ý tưởng hay đã chạy?",
      "local": "code-6.mp4"
    },
    "optional": true,
    "id": "11-06",
    "number": 6,
    "title": "Ôn nhanh: minh họa và hoạt động thật",
    "note": {
      "activity": "Xem lại thiết kế",
      "purpose": "Chuyển thiết kế thành cấu trúc sản phẩm.",
      "teacher": "GV gửi gợi ý bố cục và nhắc không bắt đầu từ hiệu ứng/trang trí. Trả lời câu hỏi về hình thức; ưu tiên công cụ nhóm đã biết dùng.",
      "students": "Đọc phản hồi giai đoạn 2, chọn hình thức và phân chia phần nội dung.",
      "report": "Nhóm lưu lựa chọn và lí do trong nhật kí.",
      "conclusion": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
      "assessment": "Kiểm tra nhóm có đủ nội dung trước khi thiết kế chi tiết.",
      "answers": [
        "Áp phích/sơ đồ mô tả ý tưởng chưa chứng minh có chức năng chạy thật. Chỉ ghi đã thử khi có thao tác và kết quả thật."
      ],
      "source": "Bài 13 Dự án AI sáng tạo, phần ý tưởng và chức năng, trang in 99. Sản phẩm poster/storyboard thay nhiệm vụ lập trình của sách theo khung; không tuyên bố sản phẩm giấy có AI chạy thật.",
      "time": "Tự làm theo mốc 7′ đọc nhiệm vụ + 27′ thực hiện + 8′ tự kiểm + 3′ nộp/lưu phản hồi. Phản hồi có thể đến sau.",
      "script": {
        "opening": "Mình xem đoạn video với câu hỏi: Hình robot biểu diễn ý tưởng. Sản phẩm của nhóm có chức năng chạy thật hay đang mô tả thiết kế?",
        "explanation": "Dùng nút Phát đoạn gợi ý, từ 85 đến 115 giây. Video tiếng Anh; GV giải nghĩa phần liên quan bằng tiếng Việt. Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "delivery": "Trước xem: giao một câu hỏi. Trong xem: cho HS chú ý một ví dụ, dừng khi cần giải nghĩa. Sau xem: mời hai ý kiến và yêu cầu chỉ chi tiết làm căn cứ. Đây là đoạn ôn tùy chọn trong dự án tại nhà, có thể dùng ảnh và tóm tắt thay thế. Nếu trình duyệt chặn âm thanh ở màn chiếu, bấm phát trực tiếp tại cửa sổ đó một lần.",
        "answer": "• Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "closing": "Hình thức phục vụ ý tưởng; mức độ phức tạp không quyết định chất lượng.",
        "transition": "Tiếp theo, mình cùng tìm hiểu: “Sản phẩm đang ở mức nào?”.",
        "students": "Quan sát chi tiết liên quan câu hỏi; nêu một nhận xét có căn cứ sau đoạn xem."
      }
    },
    "theme": "cream",
    "fallback": "Áp phích chỉ mô tả ý tưởng. Em cần kết quả thật để ghi đã chạy."
  },
  "revision": "V7 — 19/11/2026"
};
