window.AI6_LESSON={
  "id": 9,
  "title": "Dự án tại nhà - Giai đoạn 1: Lựa chọn vấn đề và lập kế hoạch",
  "mode": "Dự án tại nhà · tự làm, có thể chia phiên",
  "count": 20,
  "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 2,
    "title": "AI: What is Machine Learning?",
    "start": 120,
    "end": 150,
    "poster": "frame_2_135.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/5EavZqgaf5cKZ9dKyk9m2h/7e2c2c2c3fdd5224a8171accaf272d85/ai-02-machine-learning.mp4",
    "question": "Nhóm cần dữ liệu đầu vào gì? Chỉ rõ một chức năng nhỏ, không chỉ viết AI làm mọi việc.",
    "local": "code-2.mp4"
  },
  "outcome": "Kế hoạch có việc, người phụ trách và mốc hoàn thành.",
  "slides": [
    {
      "type": "cover",
      "id": "09-01",
      "title": "Dự án tại nhà - Giai đoạn 1: Lựa chọn vấn đề và lập kế hoạch",
      "note": {
        "activity": "Xem lại nhiệm vụ",
        "purpose": "Nhận ra điểm cần làm rõ của ý tưởng sơ bộ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Nhóm lưu hai dòng tổng hợp điểm cần chỉnh vào kế hoạch.",
        "conclusion": "Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "assessment": "Thầy/Cô đọc điểm cần chỉnh ở bản nộp, yêu cầu bổ sung nếu vẫn chỉ ghi AI giúp mọi người.",
        "answers": [
          "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "roadmap",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "09-02",
      "title": "Giai đoạn này cần hoàn thành gì?",
      "note": {
        "activity": "Xem lại nhiệm vụ",
        "purpose": "Nhận ra điểm cần làm rõ của ý tưởng sơ bộ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu hai dòng tổng hợp điểm cần chỉnh vào kế hoạch.",
        "conclusion": "Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "assessment": "Thầy/Cô đọc điểm cần chỉnh ở bản nộp, yêu cầu bổ sung nếu vẫn chỉ ghi AI giúp mọi người.",
        "answers": [
          "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chốt người dùng và vấn đề nhỏ.\n2. Nói dễ hiểu: Chia việc, người phụ trách và mốc hoàn thành.\n3. Điều cần nhớ: Ghi điều kiện và hỗ trợ cần có.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chốt người dùng và vấn đề nhỏ.",
        "Chia việc, người phụ trách và mốc hoàn thành.",
        "Ghi điều kiện và hỗ trợ cần có."
      ],
      "phase": "Khởi động",
      "scene": "roadmap",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Chốt người dùng và vấn đề nhỏ.",
        "Chia việc, người phụ trách và mốc hoàn thành.",
        "Ghi điều kiện và hỗ trợ cần có."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chốt người dùng và vấn đề nhỏ.",
          "tone": "key",
          "note": "Thầy/Cô: Chốt người dùng và vấn đề nhỏ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chia việc, người phụ trách và mốc hoàn thành.",
          "tone": "explain",
          "note": "Thầy/Cô: Chia việc, người phụ trách và mốc hoàn thành."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi điều kiện và hỗ trợ cần có.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi điều kiện và hỗ trợ cần có."
        }
      ]
    },
    {
      "type": "divider",
      "id": "09-03",
      "title": "Khởi động: mở lại ý tưởng",
      "note": {
        "activity": "Xem lại nhiệm vụ",
        "purpose": "Nhận ra điểm cần làm rõ của ý tưởng sơ bộ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm lưu hai dòng tổng hợp điểm cần chỉnh vào kế hoạch.",
        "conclusion": "Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "assessment": "Thầy/Cô đọc điểm cần chỉnh ở bản nộp, yêu cầu bổ sung nếu vẫn chỉ ghi AI giúp mọi người.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "roadmap",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "id": "09-04",
      "title": "Mở bản nháp, chọn điều cần rõ",
      "note": {
        "activity": "Xem lại nhiệm vụ",
        "purpose": "Nhận ra điểm cần làm rõ của ý tưởng sơ bộ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu hai dòng tổng hợp điểm cần chỉnh vào kế hoạch.",
        "conclusion": "Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "assessment": "Thầy/Cô đọc điểm cần chỉnh ở bản nộp, yêu cầu bổ sung nếu vẫn chỉ ghi AI giúp mọi người.",
        "answers": [
          "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đọc ý tưởng tiết 8.\n2. Nói dễ hiểu: Đọc góp ý đã nhận.\n3. Điều cần nhớ: Chọn một điểm cần làm rõ.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đọc ý tưởng tiết 8.",
        "Đọc góp ý đã nhận.",
        "Chọn một điểm cần làm rõ."
      ],
      "phase": "Khởi động",
      "scene": "roadmap",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Đọc ý tưởng tiết 8.",
        "Đọc góp ý đã nhận.",
        "Chọn một điểm cần làm rõ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đọc ý tưởng tiết 8.",
          "tone": "key",
          "note": "Thầy/Cô: Đọc ý tưởng tiết 8."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đọc góp ý đã nhận.",
          "tone": "explain",
          "note": "Thầy/Cô: Đọc góp ý đã nhận."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chọn một điểm cần làm rõ.",
          "tone": "action",
          "note": "Thầy/Cô: Chọn một điểm cần làm rõ."
        }
      ]
    },
    {
      "type": "concept",
      "id": "09-05",
      "title": "Từ ý rộng đến mục tiêu nhỏ",
      "note": {
        "activity": "Xem lại nhiệm vụ",
        "purpose": "Nhận ra điểm cần làm rõ của ý tưởng sơ bộ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm lưu hai dòng tổng hợp điểm cần chỉnh vào kế hoạch.",
        "conclusion": "Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "assessment": "Thầy/Cô đọc điểm cần chỉnh ở bản nộp, yêu cầu bổ sung nếu vẫn chỉ ghi AI giúp mọi người.",
        "answers": [
          "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI giúp mọi người học tiếng Anh: còn rộng.\n2. Nói dễ hiểu: Chọn ba từ trong một bài cho em lớp 6.\n3. Điều cần nhớ: Xong khi có ba thẻ, ví dụ và nguồn kiểm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bản nháp được phép thay đổi. Ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Quá rộng: AI giúp mọi người.",
        "Cụ thể: trợ lí giải nghĩa ba từ.",
        "Hoàn thành: có ví dụ, nguồn và cách kiểm."
      ],
      "phase": "Khám phá",
      "scene": "roadmap",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [
        "Quá rộng: AI giúp mọi người.",
        "Cụ thể: trợ lí giải nghĩa ba từ.",
        "Hoàn thành: có ví dụ, nguồn và cách kiểm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI giúp mọi người học tiếng Anh: còn rộng.",
          "tone": "key",
          "note": "Thầy/Cô: AI giúp mọi người học tiếng Anh: còn rộng."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Chọn ba từ trong một bài cho em lớp 6.",
          "tone": "explain",
          "note": "Thầy/Cô: Chọn ba từ trong một bài cho em lớp 6."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Xong khi có ba thẻ, ví dụ và nguồn kiểm.",
          "tone": "action",
          "note": "Thầy/Cô: Xong khi có ba thẻ, ví dụ và nguồn kiểm."
        }
      ]
    },
    {
      "id": "09-08-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu thu nhỏ một mục tiêu",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "idea",
      "worked": {
        "title": "Mẫu thu nhỏ một mục tiêu",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Người dùng",
          "Việc cần giúp",
          "Phạm vi",
          "Dấu hiệu hoàn thành",
          "Phần con người"
        ],
        "values": [
          "Em lớp 6",
          "Hiểu từ trong một bài",
          "Ba từ đã chọn",
          "Có ba thẻ từ, ví dụ và nguồn",
          "Kiểm nghĩa trước khi dùng"
        ],
        "why": [
          "Phạm vi nhỏ giúp chia việc rõ.",
          "Nêu dấu hiệu có thể nhìn thấy.",
          "AI không tự quyết định bài đã đúng."
        ],
        "question": "Con người cần kiểm phần nào?",
        "scene": "Idea"
      },
      "targetId": "09-08",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Kiểm nghĩa trước khi dùng",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Người dùng: Em lớp 6\nViệc cần giúp: Hiểu từ trong một bài\nPhạm vi: Ba từ đã chọn\nDấu hiệu hoàn thành: Có ba thẻ từ, ví dụ và nguồn\nPhần con người: Kiểm nghĩa trước khi dùng"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ý tưởng ban đầu: AI giúp học tiếng Anh.\n2. Nói dễ hiểu: Thu nhỏ thành ba từ trong một bài cụ thể.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Người dùng: Em lớp 6\nViệc cần giúp: Hiểu từ trong một bài\nPhạm vi: Ba từ đã chọn\nDấu hiệu hoàn thành: Có ba thẻ từ, ví dụ và nguồn\nPhần con người: Kiểm nghĩa trước khi dùng",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ý tưởng ban đầu: AI giúp học tiếng Anh.",
          "tone": "key",
          "note": "Thầy/Cô: Ý tưởng ban đầu: AI giúp học tiếng Anh."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thu nhỏ thành ba từ trong một bài cụ thể.",
          "tone": "explain",
          "note": "Thầy/Cô: Thu nhỏ thành ba từ trong một bài cụ thể."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Con người cần kiểm phần nào? Gợi ý: Kiểm nghĩa trước khi dùng"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P9.1 Xác nhận vấn đề và mục tiêu",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Ví dụ mục tiêu khả thi: poster mô tả trợ lí từ vựng với ba ví dụ, nguồn đối chiếu và cách xử lí khi bản dịch sai. Không ghi chỉ tạo AI thông minh.",
          "Đạt khi nhu cầu, mục tiêu và chức năng ăn khớp. Có thể thay ý tưởng sau khi xem điều kiện."
        ],
        "pages": [
          {
            "title": "Xác định việc cần giúp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ai cần giúp và đang gặp khó khăn gì?",
                "key": "09-08-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Xác định việc cần giúp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm sẽ làm sản phẩm gì để hỗ trợ?",
                "key": "09-08-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Xác định việc cần giúp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Khi hoàn thành, sản phẩm phải thể hiện được điều gì?",
                "key": "09-08-v3-2"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Xác định việc cần giúp",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nhóm đã sửa điểm nào so với bản nháp?",
                "key": "09-08-v3-3"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Chia rõ việc AI và việc con người",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "AI hỗ trợ phần nào?",
                "key": "09-08-v3-4"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Chia rõ việc AI và việc con người",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Con người kiểm tra và quyết định phần nào?",
                "key": "09-08-v3-5"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Chia rõ việc AI và việc con người",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Phần nào không cần AI?",
                "key": "09-08-v3-6"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Chia rõ việc AI và việc con người",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Có điều gì sản phẩm chưa làm được?",
                "key": "09-08-v3-7"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 4
        }
      },
      "id": "09-08",
      "title": "P9.1 — Chốt vấn đề và mục tiêu",
      "note": {
        "activity": "Thực hiện kế hoạch",
        "purpose": "Hoàn thành vấn đề và mục tiêu theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm ghi quyết định chọn ý tưởng và lí do không chọn phương án quá rộng.",
        "conclusion": "Kế hoạch cần việc cụ thể, người phụ trách và tiêu chí hoàn thành; mỗi em có một phần việc và minh chứng riêng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Ví dụ mục tiêu khả thi: poster mô tả trợ lí từ vựng với ba ví dụ, nguồn đối chiếu và cách xử lí khi bản dịch sai. Không ghi chỉ tạo AI thông minh.",
          "Đạt khi nhu cầu, mục tiêu và chức năng ăn khớp. Có thể thay ý tưởng sau khi xem điều kiện."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Nêu người dùng và nhu cầu. Chia việc AI và con người. Đặt dấu hiệu hoàn thành.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Ví dụ mục tiêu khả thi: poster mô tả trợ lí từ vựng với ba ví dụ, nguồn đối chiếu và cách xử lí khi bản dịch sai. Không ghi chỉ tạo AI thông minh.\nĐạt khi nhu cầu, mục tiêu và chức năng ăn khớp. Có thể thay ý tưởng sau khi xem điều kiện.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nêu người dùng và nhu cầu.",
        "Chia việc AI và con người.",
        "Đặt dấu hiệu hoàn thành."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "09-08-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Nêu người dùng và nhu cầu.",
        "Chia việc AI và con người.",
        "Đặt dấu hiệu hoàn thành."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P9.1 · Chốt mục tiêu"
    },
    {
      "type": "divider",
      "id": "09-09",
      "title": "Thực hành: lập kế hoạch",
      "note": {
        "activity": "Thực hiện kế hoạch",
        "purpose": "Xác định mục tiêu và phân công có thể thực hiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm ghi quyết định chọn ý tưởng và lí do không chọn phương án quá rộng.",
        "conclusion": "Kế hoạch cần việc cụ thể, người phụ trách và tiêu chí hoàn thành; mỗi em có một phần việc và minh chứng riêng.",
        "assessment": "Đạt khi mỗi công việc có người chịu trách nhiệm và dự kiến hoàn thành. Chức năng AI không chỉ là trang trí tên gọi.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "concept",
      "id": "09-11",
      "title": "Nhóm đang có điều kiện gì?",
      "note": {
        "activity": "Thực hiện kế hoạch",
        "purpose": "Xác định mục tiêu và phân công có thể thực hiện.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm ghi quyết định chọn ý tưởng và lí do không chọn phương án quá rộng.",
        "conclusion": "Kế hoạch cần việc cụ thể, người phụ trách và tiêu chí hoàn thành; mỗi em có một phần việc và minh chứng riêng.",
        "assessment": "Đạt khi mỗi công việc có người chịu trách nhiệm và dự kiến hoàn thành. Chức năng AI không chỉ là trang trí tên gọi.",
        "answers": [
          "Kế hoạch cần việc cụ thể, người phụ trách và tiêu chí hoàn thành. Mỗi em có một phần việc và minh chứng riêng."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm chỉ có máy chung vào buổi chiều.\n2. Nói dễ hiểu: Việc đọc, chọn từ có thể làm trên giấy trước.\n3. Điều cần nhớ: Ghi giờ dùng máy và hỗ trợ còn cần.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Kế hoạch cần việc cụ thể, người phụ trách và tiêu chí hoàn thành. Mỗi em có một phần việc và minh chứng riêng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “chia việc cho ba hoặc bốn em”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Có giấy, máy và mạng khi nào?",
        "Việc nào làm được trên giấy?",
        "Phần số nào cần hỗ trợ?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 9,
      "v7": true,
      "originalTeachingPoints": [
        "Có giấy, máy và mạng khi nào?",
        "Việc nào làm được trên giấy?",
        "Phần số nào cần hỗ trợ?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm chỉ có máy chung vào buổi chiều.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm chỉ có máy chung vào buổi chiều."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Việc đọc, chọn từ có thể làm trên giấy trước.",
          "tone": "explain",
          "note": "Thầy/Cô: Việc đọc, chọn từ có thể làm trên giấy trước."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi giờ dùng máy và hỗ trợ còn cần.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi giờ dùng máy và hỗ trợ còn cần."
        }
      ]
    },
    {
      "id": "09-v7-roles",
      "type": "guide",
      "title": "Chia việc cho ba hoặc bốn em",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Mỗi em nhận một việc rõ và người cùng kiểm.",
        "Ba em có thể gộp vai ghi và theo dõi.",
        "Ghi tên người nhận; không ghi Cả nhóm cho mọi việc."
      ],
      "scene": "roles",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mỗi em ghi việc và mốc em nhận",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Mỗi em nhận một việc rõ và người cùng kiểm. / Ba em có thể gộp vai ghi và theo dõi. / Ghi tên người nhận; không ghi Cả nhóm cho mọi việc."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Chia việc cho ba hoặc bốn em.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mỗi em nhận một việc rõ và người cùng kiểm.\n2. Nói dễ hiểu: Ba em có thể gộp vai ghi và theo dõi.\n3. Điều cần nhớ: Ghi tên người nhận; không ghi Cả nhóm cho mọi việc.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Mỗi em nhận một việc rõ và người cùng kiểm. / Ba em có thể gộp vai ghi và theo dõi. / Ghi tên người nhận; không ghi Cả nhóm cho mọi việc.",
          "closing": "Thầy/Cô chốt: Ghi tên người nhận; không ghi Cả nhóm cho mọi việc.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “gắn việc với bốn mốc”."
        }
      },
      "number": 10,
      "originalTeachingPoints": [
        "Mỗi em nhận một việc rõ và người cùng kiểm.",
        "Ba em có thể gộp vai ghi và theo dõi.",
        "Ghi tên người nhận; không ghi Cả nhóm cho mọi việc."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mỗi em nhận một việc rõ và người cùng kiểm.",
          "tone": "key",
          "note": "Thầy/Cô: Mỗi em nhận một việc rõ và người cùng kiểm."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ba em có thể gộp vai ghi và theo dõi.",
          "tone": "explain",
          "note": "Thầy/Cô: Ba em có thể gộp vai ghi và theo dõi."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi tên người nhận; không ghi Cả nhóm cho mọi việc.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi tên người nhận; không ghi Cả nhóm cho mọi việc."
        }
      ]
    },
    {
      "id": "09-v7-milestones",
      "type": "guide",
      "title": "Gắn việc với bốn mốc",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Chốt việc → Tìm nguồn → Làm bản 1 → Sửa.",
        "Mốc thật theo lịch Thầy/Cô thông báo.",
        "Mỗi mốc cần có việc và sản phẩm để kiểm."
      ],
      "scene": "roadmap",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mỗi em ghi việc và mốc em nhận",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Chốt việc → Tìm nguồn → Làm bản 1 → Sửa. / Mốc thật theo lịch Thầy/Cô thông báo. / Mỗi mốc cần có việc và sản phẩm để kiểm."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Gắn việc với bốn mốc.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Chốt việc → Tìm nguồn → Làm bản 1 → Sửa.\n2. Nói dễ hiểu: Mốc thật theo lịch Thầy/Cô thông báo.\n3. Điều cần nhớ: Mỗi mốc cần có việc và sản phẩm để kiểm.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Chốt việc → Tìm nguồn → Làm bản 1 → Sửa. / Mốc thật theo lịch Thầy/Cô thông báo. / Mỗi mốc cần có việc và sản phẩm để kiểm.",
          "closing": "Thầy/Cô chốt: Mỗi mốc cần có việc và sản phẩm để kiểm.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “mẫu kế hoạch đã chia việc”."
        }
      },
      "number": 11,
      "originalTeachingPoints": [
        "Chốt việc → Tìm nguồn → Làm bản 1 → Sửa.",
        "Mốc thật theo lịch Thầy/Cô thông báo.",
        "Mỗi mốc cần có việc và sản phẩm để kiểm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Chốt việc → Tìm nguồn → Làm bản 1 → Sửa.",
          "tone": "key",
          "note": "Thầy/Cô: Chốt việc → Tìm nguồn → Làm bản 1 → Sửa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mốc thật theo lịch Thầy/Cô thông báo.",
          "tone": "explain",
          "note": "Thầy/Cô: Mốc thật theo lịch Thầy/Cô thông báo."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Mỗi mốc cần có việc và sản phẩm để kiểm.",
          "tone": "action",
          "note": "Thầy/Cô: Mỗi mốc cần có việc và sản phẩm để kiểm."
        }
      ]
    },
    {
      "id": "09-v7-plan",
      "type": "guide",
      "title": "Mẫu kế hoạch đã chia việc",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Em đọc cột người nhận và người cùng kiểm.",
        "Bốn mốc là ví dụ, chưa phải lịch nộp.",
        "Nhóm thay bằng ngày Thầy/Cô đã thông báo."
      ],
      "scene": "roles",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mỗi em ghi việc và mốc em nhận",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Em đọc cột người nhận và người cùng kiểm. / Bốn mốc là ví dụ, chưa phải lịch nộp. / Nhóm thay bằng ngày Thầy/Cô đã thông báo."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Mẫu kế hoạch đã chia việc.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em đọc cột người nhận và người cùng kiểm.\n2. Nói dễ hiểu: Bốn mốc là ví dụ, chưa phải lịch nộp.\n3. Điều cần nhớ: Nhóm thay bằng ngày Thầy/Cô đã thông báo.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Em đọc cột người nhận và người cùng kiểm. / Bốn mốc là ví dụ, chưa phải lịch nộp. / Nhóm thay bằng ngày Thầy/Cô đã thông báo.",
          "closing": "Thầy/Cô chốt: Nhóm thay bằng ngày Thầy/Cô đã thông báo.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "guideTable": {
        "headers": [
          "Mốc",
          "Người nhận / cùng kiểm",
          "Phần hoàn thành"
        ],
        "rows": [
          [
            "1 · Chốt việc",
            "Em A / Em B",
            "Mục tiêu ba từ"
          ],
          [
            "2 · Tìm nguồn",
            "Em B / Em C",
            "Hai nguồn đã đọc"
          ],
          [
            "3 · Bản 1",
            "Em C / Em A",
            "Áp phích có ví dụ"
          ],
          [
            "4 · Sửa, gửi",
            "Em A / Em B,C",
            "Bản cuối đã mở thử"
          ]
        ],
        "label": "Nhóm bốn em: em D nhận ghi nguồn và kiểm tệp."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 12,
      "originalTeachingPoints": [
        "Em đọc cột người nhận và người cùng kiểm.",
        "Bốn mốc là ví dụ, chưa phải lịch nộp.",
        "Nhóm thay bằng ngày Thầy/Cô đã thông báo."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em đọc cột người nhận và người cùng kiểm.",
          "tone": "key",
          "note": "Thầy/Cô: Em đọc cột người nhận và người cùng kiểm."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bốn mốc là ví dụ, chưa phải lịch nộp.",
          "tone": "explain",
          "note": "Thầy/Cô: Bốn mốc là ví dụ, chưa phải lịch nộp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Nhóm thay bằng ngày Thầy/Cô đã thông báo.",
          "tone": "action",
          "note": "Thầy/Cô: Nhóm thay bằng ngày Thầy/Cô đã thông báo."
        }
      ]
    },
    {
      "id": "09-10-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu phân công ba em, bốn tuần",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "worked": {
        "title": "Mẫu phân công ba em, bốn tuần",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Tuần 1 / giai đoạn 1",
          "Tuần 2 / giai đoạn 2",
          "Tuần 3 / giai đoạn 3",
          "Tuần 4 / giai đoạn 4",
          "Cách tránh bỏ sót"
        ],
        "values": [
          "Em A: chốt việc. Em B/C góp mục tiêu",
          "Em B: tìm nguồn. Em A/C cùng kiểm",
          "Em C: tạo bố cục. Em A/B làm nội dung",
          "Cả ba sửa, giới thiệu và kiểm hồ sơ",
          "Mỗi em ghi việc và mốc em nhận"
        ],
        "why": [
          "Người phụ trách không phải làm một em.",
          "Mỗi tuần chỉ là cách bố trí mẫu.",
          "Cả ba đều có việc kiểm được."
        ],
        "question": "Mỗi em cần ghi thêm gì để không quên việc?",
        "scene": "Roadmap"
      },
      "targetId": "09-10",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Mỗi em ghi việc và mốc em nhận",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tuần 1 / giai đoạn 1: Em A: chốt việc. Em B/C góp mục tiêu\nTuần 2 / giai đoạn 2: Em B: tìm nguồn. Em A/C cùng kiểm\nTuần 3 / giai đoạn 3: Em C: tạo bố cục. Em A/B làm nội dung\nTuần 4 / giai đoạn 4: Cả ba sửa, giới thiệu và kiểm hồ sơ\nCách tránh bỏ sót: Mỗi em ghi việc và mốc em nhận"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nhóm ba em chia việc theo bốn mốc.\n2. Nói dễ hiểu: Mỗi mốc có người làm và người cùng kiểm.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Tuần 1 / giai đoạn 1: Em A: chốt việc. Em B/C góp mục tiêu\nTuần 2 / giai đoạn 2: Em B: tìm nguồn. Em A/C cùng kiểm\nTuần 3 / giai đoạn 3: Em C: tạo bố cục. Em A/B làm nội dung\nTuần 4 / giai đoạn 4: Cả ba sửa, giới thiệu và kiểm hồ sơ\nCách tránh bỏ sót: Mỗi em ghi việc và mốc em nhận",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nhóm ba em chia việc theo bốn mốc.",
          "tone": "key",
          "note": "Thầy/Cô: Nhóm ba em chia việc theo bốn mốc."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mỗi mốc có người làm và người cùng kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: Mỗi mốc có người làm và người cùng kiểm."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Mỗi em cần ghi thêm gì để không quên việc? Gợi ý: Mỗi em ghi việc và mốc em nhận"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P9.2 Phân công và mốc công việc",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Mỗi việc có người chịu trách nhiệm và người phối hợp. Mọi thành viên có phần việc, không chỉ người biết thiết kế.",
          "Thiếu thiết bị có thể thiết kế giấy và xin hỗ trợ thao tác số/quay sản phẩm theo kế hoạch của Thầy/Cô. Không tự đánh dấu đã có video."
        ],
        "pages": [
          {
            "title": "Phân công — giai đoạn 1 và 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Việc / sản phẩm",
              "Người làm / cùng kiểm",
              "Mốc xong"
            ],
            "rows": [
              [
                "1. Chốt vấn đề → bản kế hoạch",
                {
                  "label": "Người phụ trách giai đoạn 1",
                  "key": "09-10-v3-0"
                },
                {
                  "label": "Thời điểm giai đoạn 1",
                  "key": "09-10-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Phân công — giai đoạn 1 và 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Việc / sản phẩm",
              "Người làm / cùng kiểm",
              "Mốc xong"
            ],
            "rows": [
              [
                "2. Tìm nguồn → sơ đồ thiết kế",
                {
                  "label": "Người phụ trách giai đoạn 2",
                  "key": "09-10-v3-2"
                },
                {
                  "label": "Thời điểm giai đoạn 2",
                  "key": "09-10-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Phân công — giai đoạn 3 và 4",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Việc / sản phẩm",
              "Người làm / cùng kiểm",
              "Mốc xong"
            ],
            "rows": [
              [
                "3. Làm sản phẩm → bản đầu",
                {
                  "label": "Người phụ trách giai đoạn 3",
                  "key": "09-10-v3-4"
                },
                {
                  "label": "Thời điểm giai đoạn 3",
                  "key": "09-10-v3-5"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Phân công — giai đoạn 3 và 4",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Việc / sản phẩm",
              "Người làm / cùng kiểm",
              "Mốc xong"
            ],
            "rows": [
              [
                "4. Sửa, quay giới thiệu → bản cuối",
                {
                  "label": "Người phụ trách giai đoạn 4",
                  "key": "09-10-v3-6"
                },
                {
                  "label": "Thời điểm giai đoạn 4",
                  "key": "09-10-v3-7"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Chuẩn bị điều kiện thực hiện",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Thiết bị/vật liệu và thời gian có sẵn",
                "key": "09-10-v3-8"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Chuẩn bị điều kiện thực hiện",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Cách làm khi thiếu mạng hoặc thiết bị",
                "key": "09-10-v3-9"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Chuẩn bị điều kiện thực hiện",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Điều cần hỏi Thầy/Cô và việc em nhận",
                "key": "09-10-v3-10"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2,
          "2": 4
        }
      },
      "id": "09-10",
      "title": "P9.2 — Mỗi việc có người và mốc",
      "note": {
        "activity": "Thực hiện kế hoạch",
        "purpose": "Hoàn thành ai làm gì, khi nào xong? theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm ghi quyết định chọn ý tưởng và lí do không chọn phương án quá rộng.",
        "conclusion": "Kế hoạch cần việc cụ thể, người phụ trách và tiêu chí hoàn thành; mỗi em có một phần việc và minh chứng riêng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Mỗi việc có người chịu trách nhiệm và người phối hợp. Mọi thành viên có phần việc, không chỉ người biết thiết kế.",
          "Thiếu thiết bị có thể thiết kế giấy và xin hỗ trợ thao tác số/quay sản phẩm theo kế hoạch của Thầy/Cô. Không tự đánh dấu đã có video."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Chia việc theo bốn giai đoạn. Ghi người phụ trách. Ghi mốc theo lịch lớp.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Mỗi việc có người chịu trách nhiệm và người phối hợp. Mọi thành viên có phần việc, không chỉ người biết thiết kế.\nThiếu thiết bị có thể thiết kế giấy và xin hỗ trợ thao tác số/quay sản phẩm theo kế hoạch của Thầy/Cô. Không tự đánh dấu đã có video.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chia việc theo bốn giai đoạn.",
        "Ghi người phụ trách.",
        "Ghi mốc theo lịch lớp."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "09-10-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [
        "Chia việc theo bốn giai đoạn.",
        "Ghi người phụ trách.",
        "Ghi mốc theo lịch lớp."
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P9.2 · Chia việc, đặt mốc"
    },
    {
      "type": "divider",
      "id": "09-12",
      "title": "Tự kiểm tra kế hoạch",
      "note": {
        "activity": "Tự kiểm tra",
        "purpose": "Phát hiện thiếu sót trước khi nộp.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm tóm tắt thay đổi trong một dòng để GV dễ phản hồi.",
        "conclusion": "Bảng kiểm nhằm phát hiện chỗ cần bổ sung, không phải tự đánh dấu hoàn thành tất cả.",
        "assessment": "Có căn cứ cho mỗi dấu kiểm. Ghi chưa đạt trung thực vẫn được hỗ trợ.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "09-13-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu kiểm một dòng kế hoạch",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "worked": {
        "title": "Mẫu kiểm một dòng kế hoạch",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Việc",
          "Người phụ trách",
          "Mốc mẫu",
          "Điều kiện",
          "Mục cần bổ sung"
        ],
        "values": [
          "Tìm hai nguồn cho ba từ",
          "Em B",
          "Giai đoạn 2 theo lịch lớp",
          "Dùng sách và máy chung",
          "Ghi ai cùng kiểm và khi nào kiểm xong"
        ],
        "why": [
          "Một tên chưa thay toàn bộ phân công.",
          "Mốc phải theo lịch đã thống nhất.",
          "Thiếu gì thì ghi rõ để bổ sung."
        ],
        "question": "Dòng này còn cần thêm thông tin gì?",
        "scene": "Roadmap"
      },
      "targetId": "09-13",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô gọi 1–2 em trả lời.",
        "conclusion": "Ghi ai cùng kiểm và khi nào kiểm xong",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Việc: Tìm hai nguồn cho ba từ\nNgười phụ trách: Em B\nMốc mẫu: Giai đoạn 2 theo lịch lớp\nĐiều kiện: Dùng sách và máy chung\nMục cần bổ sung: Ghi ai cùng kiểm và khi nào kiểm xong"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em B nhận tìm hai nguồn cho ba từ.\n2. Nói dễ hiểu: Thêm người kiểm và mốc xong để tránh bỏ sót.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô chỉ lần lượt các ô đã điền. Giữ ô cuối trống trong 30 giây. Gọi 1–2 em tại chỗ. Bấm Mở ô cuối sau khi các em trả lời. Chỉ chuyển sang tự làm khi các em hiểu cách điền.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Việc: Tìm hai nguồn cho ba từ\nNgười phụ trách: Em B\nMốc mẫu: Giai đoạn 2 theo lịch lớp\nĐiều kiện: Dùng sách và máy chung\nMục cần bổ sung: Ghi ai cùng kiểm và khi nào kiểm xong",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em B nhận tìm hai nguồn cho ba từ.",
          "tone": "key",
          "note": "Thầy/Cô: Em B nhận tìm hai nguồn cho ba từ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thêm người kiểm và mốc xong để tránh bỏ sót.",
          "tone": "explain",
          "note": "Thầy/Cô: Thêm người kiểm và mốc xong để tránh bỏ sót."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Dòng này còn cần thêm thông tin gì? Gợi ý: Ghi ai cùng kiểm và khi nào kiểm xong"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P9.3 Bảng kiểm kế hoạch",
        "intro": "Trong 5 phút, nhóm em điền phần này trên phiếu. Mỗi em nhận một vai trước khi làm.",
        "answers": [
          "Đạt khi sáu mục có căn cứ. Mục chưa rõ phải được bổ sung trước khi chuyển tìm nguồn. Thầy/Cô nhận xét nội dung và trách nhiệm cá nhân, không chỉ độ đẹp tệp."
        ],
        "pages": [
          {
            "title": "Kiểm tra kế hoạch — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần có",
              "Trạng thái",
              "Cần bổ sung gì?"
            ],
            "rows": [
              [
                "Vấn đề và người dùng đã rõ.",
                {
                  "label": "Vấn đề và người dùng đã rõ. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "09-13-v3-0",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Vấn đề và người dùng đã rõ. — cần bổ sung",
                  "key": "09-13-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Kiểm tra kế hoạch — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần có",
              "Trạng thái",
              "Cần bổ sung gì?"
            ],
            "rows": [
              [
                "Mục tiêu có thể kiểm tra được.",
                {
                  "label": "Mục tiêu có thể kiểm tra được. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "09-13-v3-2",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Mục tiêu có thể kiểm tra được. — cần bổ sung",
                  "key": "09-13-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Kiểm tra kế hoạch — bước 1",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần có",
              "Trạng thái",
              "Cần bổ sung gì?"
            ],
            "rows": [
              [
                "Việc AI và việc người đã tách rõ.",
                {
                  "label": "Việc AI và việc người đã tách rõ. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "09-13-v3-4",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Việc AI và việc người đã tách rõ. — cần bổ sung",
                  "key": "09-13-v3-5"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Kiểm tra kế hoạch — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần có",
              "Trạng thái",
              "Cần bổ sung gì?"
            ],
            "rows": [
              [
                "Mỗi việc có người và thời điểm hoàn thành.",
                {
                  "label": "Mỗi việc có người và thời điểm hoàn thành. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "09-13-v3-6",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Mỗi việc có người và thời điểm hoàn thành. — cần bổ sung",
                  "key": "09-13-v3-7"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Kiểm tra kế hoạch — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần có",
              "Trạng thái",
              "Cần bổ sung gì?"
            ],
            "rows": [
              [
                "Đã chọn dữ liệu cần và bỏ dữ liệu không cần.",
                {
                  "label": "Đã chọn dữ liệu cần và bỏ dữ liệu không cần. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "09-13-v3-8",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Đã chọn dữ liệu cần và bỏ dữ liệu không cần. — cần bổ sung",
                  "key": "09-13-v3-9"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Kiểm tra kế hoạch — bước 2",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Điều cần có",
              "Trạng thái",
              "Cần bổ sung gì?"
            ],
            "rows": [
              [
                "Đã có cách làm phù hợp thiết bị.",
                {
                  "label": "Đã có cách làm phù hợp thiết bị. — trạng thái",
                  "options": [
                    "Đã có",
                    "Cần bổ sung"
                  ],
                  "key": "09-13-v3-10",
                  "optionLabels": [
                    "Đã có",
                    "Cần bổ sung"
                  ]
                },
                {
                  "label": "Đã có cách làm phù hợp thiết bị. — cần bổ sung",
                  "key": "09-13-v3-11"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Trách nhiệm cá nhân",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em phụ trách việc gì?",
                "key": "09-13-v3-12"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Trách nhiệm cá nhân",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Sau khi tự kiểm tra, nhóm đã sửa điều gì?",
                "key": "09-13-v3-13"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 3,
          "2": 6
        }
      },
      "id": "09-13",
      "title": "P9.3 — Kiểm kế hoạch trước gửi",
      "note": {
        "activity": "Tự kiểm tra",
        "purpose": "Hoàn thành kiểm tra trước khi gửi theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em ghi phần việc thật.",
        "report": "Nhóm tóm tắt thay đổi trong một dòng để GV dễ phản hồi.",
        "conclusion": "Bảng kiểm nhằm phát hiện chỗ cần bổ sung, không phải tự đánh dấu hoàn thành tất cả.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Đạt khi sáu mục có căn cứ. Mục chưa rõ phải được bổ sung trước khi chuyển tìm nguồn. Thầy/Cô nhận xét nội dung và trách nhiệm cá nhân, không chỉ độ đẹp tệp."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Mục tiêu có đủ nhỏ? Việc đã có người và mốc? Ai còn cần hỗ trợ?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. Thầy/Cô kiểm phân công trước khi các em làm. Một em phụ trách không có nghĩa làm thay cả nhóm. Các em đổi vai ở chặng tiếp. Nếu nhóm có ba em, gộp vai ghi và theo dõi. Giai đoạn tại nhà có thể chia phiên.",
          "students": "Em ghi phần việc thật.",
          "answer": "Đạt khi sáu mục có căn cứ. Mục chưa rõ phải được bổ sung trước khi chuyển tìm nguồn. Thầy/Cô nhận xét nội dung và trách nhiệm cá nhân, không chỉ độ đẹp tệp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mục tiêu có đủ nhỏ?",
        "Việc đã có người và mốc?",
        "Ai còn cần hỗ trợ?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "taskLines": [
        "Trong 5 phút, nhóm em điền phần này trên phiếu.",
        "Mỗi em nhận một vai trước khi làm."
      ],
      "rolesV6": [
        "Em đọc yêu cầu",
        "Em tìm và làm",
        "Em kiểm kết quả",
        "Em ghi và theo dõi"
      ],
      "sampleId": "09-13-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Mục tiêu có đủ nhỏ?",
        "Việc đã có người và mốc?",
        "Ai còn cần hỗ trợ?"
      ],
      "pupilTask": "Em ghi phần việc thật.",
      "pupilTitle": "P9.3 · Em tự làm"
    },
    {
      "type": "recap",
      "id": "09-14",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Tự kiểm tra",
        "purpose": "Phát hiện thiếu sót trước khi nộp.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Nhóm tóm tắt thay đổi trong một dòng để GV dễ phản hồi.",
        "conclusion": "Bảng kiểm nhằm phát hiện chỗ cần bổ sung, không phải tự đánh dấu hoàn thành tất cả.",
        "assessment": "Có căn cứ cho mỗi dấu kiểm. Ghi chưa đạt trung thực vẫn được hỗ trợ.",
        "answers": [
          "Bảng kiểm nhằm phát hiện chỗ cần bổ sung, không phải tự đánh dấu hoàn thành tất cả."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Mục tiêu đủ nhỏ để kiểm hoàn thành.\n2. Nói dễ hiểu: Mỗi việc có người và mốc.\n3. Điều cần nhớ: Thiếu điều kiện thì ghi hỗ trợ cần hỏi.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bảng kiểm nhằm phát hiện chỗ cần bổ sung, không phải tự đánh dấu hoàn thành tất cả.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Mục tiêu đủ nhỏ để kiểm hoàn thành.",
        "Mỗi việc có người và mốc.",
        "Thiếu điều kiện thì ghi hỗ trợ cần hỏi."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "roadmap",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Mục tiêu đủ nhỏ để kiểm hoàn thành.",
        "Mỗi việc có người và mốc.",
        "Thiếu điều kiện thì ghi hỗ trợ cần hỏi."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Mục tiêu đủ nhỏ để kiểm hoàn thành.",
          "tone": "key",
          "note": "Thầy/Cô: Mục tiêu đủ nhỏ để kiểm hoàn thành."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mỗi việc có người và mốc.",
          "tone": "explain",
          "note": "Thầy/Cô: Mỗi việc có người và mốc."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Thiếu điều kiện thì ghi hỗ trợ cần hỏi.",
          "tone": "action",
          "note": "Thầy/Cô: Thiếu điều kiện thì ghi hỗ trợ cần hỏi."
        }
      ]
    },
    {
      "type": "divider",
      "id": "09-15",
      "title": "Vận dụng: gửi và giữ kế hoạch",
      "note": {
        "activity": "Nộp và nhận phản hồi",
        "purpose": "Bàn giao kế hoạch làm đầu vào giai đoạn 2.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Nhóm lưu phiên bản, các em xác nhận phần việc cá nhân trong bản kế hoạch.",
        "conclusion": "Chuyển sang giai đoạn 2 khi ý tưởng đủ rõ để tìm nguồn và vẽ sơ đồ.",
        "assessment": "Nếu chưa rõ mục tiêu, Thầy/Cô nêu một câu cần viết lại và hỗ trợ ở phiên trao đổi tiếp theo.",
        "answers": [],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Bản cần gửi đã có. Em mở thử trước khi nộp."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "roadmap",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "submission",
      "id": "09-16",
      "title": "Gửi kế hoạch, giữ bản để làm tiếp",
      "note": {
        "activity": "Nộp và nhận phản hồi",
        "purpose": "Bàn giao kế hoạch làm đầu vào giai đoạn 2.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
        "report": "Nhóm lưu phiên bản, các em xác nhận phần việc cá nhân trong bản kế hoạch.",
        "conclusion": "Chuyển sang giai đoạn 2 khi ý tưởng đủ rõ để tìm nguồn và vẽ sơ đồ.",
        "assessment": "Nếu chưa rõ mục tiêu, Thầy/Cô nêu một câu cần viết lại và hỗ trợ ở phiên trao đổi tiếp theo.",
        "answers": [
          "Chuyển sang giai đoạn 2 khi ý tưởng đủ rõ để tìm nguồn và vẽ sơ đồ."
        ],
        "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Bản cần gửi đã có. Em mở thử trước khi nộp.",
          "explanation": "Nộp một bản kế hoạch và câu trả lời cá nhân theo kênh lớp. Nếu nộp giấy, dùng lịch nhận do Thầy/Cô thông báo.\nÝ cần giảng rõ: Một kế hoạch chung. Câu trả lời của từng thành viên. Ghi phần cần Thầy/Cô hỗ trợ.",
          "delivery": "Thầy/Cô hướng dẫn chia vai rõ; nhóm ba em có thể gộp vai ghi và theo dõi. Thầy/Cô làm mẫu trước; chỉ mở ô cuối sau khi nghe đề xuất. Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm. ",
          "students": "Em kiểm tệp; ghi phần việc rồi tải bài.",
          "answer": "Chuyển sang giai đoạn 2 khi ý tưởng đủ rõ để tìm nguồn và vẽ sơ đồ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Một kế hoạch chung.",
        "Câu trả lời của từng thành viên.",
        "Ghi phần cần Thầy/Cô hỗ trợ."
      ],
      "phase": "Vận dụng",
      "scene": "roadmap",
      "taskLines": [
        "Trong 3 phút, em kiểm hồ sơ ở thư mục.",
        "Sau đó, em gửi tệp theo kênh của lớp."
      ],
      "connector": "Bản cần gửi đã có. Em mở thử trước khi nộp.",
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [
        "Một kế hoạch chung.",
        "Câu trả lời của từng thành viên.",
        "Ghi phần cần Thầy/Cô hỗ trợ."
      ],
      "pupilTask": "Em kiểm tệp; ghi phần việc rồi tải bài."
    }
  ],
  "rubric": [
    [
      "1 Vấn đề và tính khả thi",
      "Chưa nêu vấn đề/người dùng hoặc mục tiêu không thể thực hiện.",
      "Có vấn đề/người dùng nhưng mục tiêu hoặc cách thực hiện còn rộng.",
      "Vấn đề, người dùng, mục tiêu rõ. Hình thức và quy mô phù hợp điều kiện."
    ],
    [
      "2 Chức năng AI và chính xác",
      "Không mô tả đúng AI hoặc gán chức năng không có bằng chứng.",
      "Có đầu vào/đầu ra. Còn thiếu liên kết hoặc chưa rõ mức đã làm.",
      "Chức năng, đầu vào/đầu ra và ví dụ đúng. Ghi rõ minh họa hay hoạt động thật."
    ],
    [
      "3 Con người và an toàn",
      "Chưa có bước kiểm tra. Hoặc còn chia sẻ thông tin riêng không cần thiết.",
      "Có người kiểm tra nhưng cách kiểm/điều kiện riêng tư còn chung chung.",
      "Có nguồn kiểm và cách xử lí khi sai. Con người quyết định. Chỉ dùng dữ liệu cần thiết."
    ],
    [
      "4 Sản phẩm nguồn và quá trình",
      "Thiếu phần chính, nguồn hoặc bằng chứng quá trình.",
      "Sản phẩm đọc được. Còn thiếu phần, nguồn khó xem lại hoặc bảng ghi chưa rõ.",
      "Đủ nội dung. Nguồn mở lại được. Sản phẩm dễ xem. Có bảng ghi quá trình."
    ],
    [
      "5 Hợp tác chỉnh sửa giới thiệu",
      "Chưa có đóng góp, góp ý hoặc sửa bài. Chưa giới thiệu sản phẩm.",
      "Có phân công hoặc sửa nhưng lí do chưa rõ. Giới thiệu chưa đủ hoặc còn thiếu minh chứng.",
      "Có đóng góp và một sửa có lí do. Video 2–3 phút nêu rõ vai AI và người."
    ]
  ],
  "evidence": [
    [
      "Chọn vấn đề và lập kế hoạch",
      "6.2.TC1b",
      "Xác định người dùng, mục tiêu, vai trò dự kiến của AI.",
      "P9.1–P9.2 và trả lời cá nhân",
      "Có nhu cầu cụ thể, chức năng phù hợp và phần việc con người; chưa suy ra năng lực lập trình."
    ]
  ],
  "review": {
    "type": "video",
    "video": {
      "index": 2,
      "title": "AI: What is Machine Learning?",
      "start": 120,
      "end": 150,
      "poster": "frame_2_135.jpg",
      "url": "https://contentful-videos.code.org/90t6bu6vlf76/5EavZqgaf5cKZ9dKyk9m2h/7e2c2c2c3fdd5224a8171accaf272d85/ai-02-machine-learning.mp4",
      "question": "Ví dụ nào giúp nhóm chốt đầu vào và kết quả?",
      "local": "code-2.mp4"
    },
    "optional": true,
    "id": "09-06",
    "number": 6,
    "title": "Ôn nhanh: AI hỗ trợ nhiệm vụ nào?",
    "note": {
      "activity": "Xem lại nhiệm vụ",
      "purpose": "Nhận ra điểm cần làm rõ của ý tưởng sơ bộ.",
      "teacher": "GV gửi góp ý ngắn và mốc nộp do lớp quy định, không yêu cầu họp trực tuyến. Trong thông báo có câu gợi ý Ai gặp vấn đề gì và kết quả nào là đủ? HS được gửi câu hỏi khi đọc.",
      "students": "Đọc độc lập, trao đổi bất đồng bộ và đánh dấu phần cần sửa.",
      "report": "Nhóm lưu hai dòng tổng hợp điểm cần chỉnh vào kế hoạch.",
      "conclusion": "Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
      "assessment": "GV đọc điểm cần chỉnh ở bản nộp, yêu cầu bổ sung nếu vẫn chỉ ghi AI giúp mọi người.",
      "answers": [
        "Ví dụ: chọn nhận ảnh đồ vật và trả nhãn, hoặc nhận câu tiếng Anh và trả bản dịch. Nhóm phải nêu đúng chức năng nhỏ của mình."
      ],
      "source": "Bài 13 Dự án AI sáng tạo, mục Xác định chủ đề, ý tưởng và kế hoạch, trang in 99; bốn giai đoạn tại nhà được thiết kế theo khung người dùng.",
      "time": "Tự làm theo mốc 7′ đọc nhiệm vụ + 27′ thực hiện + 8′ tự kiểm + 3′ nộp/lưu phản hồi. Phản hồi có thể đến sau.",
      "script": {
        "opening": "Mình xem đoạn video với câu hỏi: Nhóm cần dữ liệu đầu vào gì? Chỉ rõ một chức năng nhỏ, không chỉ viết AI làm mọi việc.",
        "explanation": "Dùng nút Phát đoạn gợi ý, từ 120 đến 150 giây. Video tiếng Anh; GV giải nghĩa phần liên quan bằng tiếng Việt. Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "delivery": "Trước xem: giao một câu hỏi. Trong xem: cho HS chú ý một ví dụ, dừng khi cần giải nghĩa. Sau xem: mời hai ý kiến và yêu cầu chỉ chi tiết làm căn cứ. Đây là đoạn ôn tùy chọn trong dự án tại nhà, có thể dùng ảnh và tóm tắt thay thế. Nếu trình duyệt chặn âm thanh ở màn chiếu, bấm phát trực tiếp tại cửa sổ đó một lần.",
        "answer": "• Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "closing": "Bản nháp được phép thay đổi; ưu tiên thu hẹp nhu cầu để làm được trong thời gian có sẵn.",
        "transition": "Tiếp theo, mình cùng tìm hiểu: “Xác định người dùng và mục tiêu”.",
        "students": "Quan sát chi tiết liên quan câu hỏi; nêu một nhận xét có căn cứ sau đoạn xem."
      }
    },
    "theme": "cream",
    "fallback": "Ví dụ: AI nhận ảnh và gợi tên vật. Em cần chọn rõ phần AI hỗ trợ."
  },
  "revision": "V7 — 19/11/2026"
};
