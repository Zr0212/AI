window.AI6_LESSON={
  "id": 1,
  "title": "Bài 1. Làm quen với AI và một số công nghệ AI quen thuộc",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 30,
  "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 0,
    "title": "Introducing How AI Works",
    "start": 0,
    "end": 89,
    "poster": "frame_0_20.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/1jVlIMJ2yBmzqD1H5hHDNj/9fe6b733248373a6546b44d1bad1baf6/ai-01-intro-to-ai.mp4",
    "question": "Tìm một việc AI giúp con người. Trước khi sử dụng kết quả, người dùng cần làm gì?",
    "local": "code-0.mp4"
  },
  "outcome": "Hai bảng ghi và thẻ giới thiệu một tính năng AI.",
  "slides": [
    {
      "type": "cover",
      "id": "01-01",
      "title": "Bài 1. Làm quen với AI và một số công nghệ AI quen thuộc",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra phải xem xét tính năng cụ thể khi nhận biết AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI; cần biết tính năng và cách hoạt động.",
        "assessment": "Quan sát căn cứ các em sử dụng. Ghi lại nhận định mọi công cụ số đều là AI để sửa ở hoạt động sau.",
        "answers": [
          "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI. Cần biết tính năng và cách hoạt động."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI. Cần biết tính năng và cách hoạt động.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "01-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra phải xem xét tính năng cụ thể khi nhận biết AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI; cần biết tính năng và cách hoạt động.",
        "assessment": "Quan sát căn cứ các em sử dụng. Ghi lại nhận định mọi công cụ số đều là AI để sửa ở hoạt động sau.",
        "answers": [
          "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI. Cần biết tính năng và cách hoạt động."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Nói AI giúp được việc gì.\n2. Nói dễ hiểu: Phân biệt tính năng qua mô tả.\n3. Điều cần nhớ: Thử dịch, thử ảnh và kiểm kết quả.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI. Cần biết tính năng và cách hoạt động.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Nói AI giúp được việc gì.",
        "Phân biệt tính năng qua mô tả.",
        "Thử dịch, thử ảnh và kiểm kết quả."
      ],
      "phase": "Khởi động",
      "scene": "translate",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Nói AI giúp được việc gì.",
        "Phân biệt tính năng qua mô tả.",
        "Thử dịch, thử ảnh và kiểm kết quả."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Nói AI giúp được việc gì.",
          "tone": "key",
          "note": "Thầy/Cô: Nói AI giúp được việc gì."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Phân biệt tính năng qua mô tả.",
          "tone": "explain",
          "note": "Thầy/Cô: Phân biệt tính năng qua mô tả."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Thử dịch, thử ảnh và kiểm kết quả.",
          "tone": "action",
          "note": "Thầy/Cô: Thử dịch, thử ảnh và kiểm kết quả."
        }
      ]
    },
    {
      "type": "divider",
      "id": "01-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra phải xem xét tính năng cụ thể khi nhận biết AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI; cần biết tính năng và cách hoạt động.",
        "assessment": "Quan sát căn cứ các em sử dụng. Ghi lại nhận định mọi công cụ số đều là AI để sửa ở hoạt động sau.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "01-04",
      "title": "Nhanh có phải là AI?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra phải xem xét tính năng cụ thể khi nhận biết AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI; cần biết tính năng và cách hoạt động.",
        "assessment": "Quan sát căn cứ các em sử dụng. Ghi lại nhận định mọi công cụ số đều là AI để sửa ở hoạt động sau.",
        "answers": [
          "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI. Cần biết tính năng và cách hoạt động."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Máy tính: 125 + 37 = 162.\n2. Nói dễ hiểu: Công cụ AI: nhận ảnh, gợi ý tên đồ vật.\n3. Điều cần nhớ: Chỉ nhìn tốc độ, em đã phân biệt được chưa?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Tốc độ, có Internet hoặc dùng máy tính chưa đủ để kết luận có AI. Cần biết tính năng và cách hoạt động.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Máy tính: 125 + 37 = 162.",
        "Công cụ AI: nhận ảnh, gợi ý tên đồ vật.",
        "Chỉ nhìn tốc độ, em đã phân biệt được chưa?"
      ],
      "phase": "Khởi động",
      "scene": "calculator",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Máy tính: 125 + 37 = 162.",
        "Công cụ AI: nhận ảnh, gợi ý tên đồ vật.",
        "Chỉ nhìn tốc độ, em đã phân biệt được chưa?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Máy tính: 125 + 37 = 162.",
          "tone": "key",
          "note": "Thầy/Cô: Máy tính: 125 + 37 = 162."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Công cụ AI: nhận ảnh, gợi ý tên đồ vật.",
          "tone": "explain",
          "note": "Thầy/Cô: Công cụ AI: nhận ảnh, gợi ý tên đồ vật."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chỉ nhìn tốc độ, em đã phân biệt được chưa?",
          "tone": "action",
          "note": "Thầy/Cô: Chỉ nhìn tốc độ, em đã phân biệt được chưa?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "01-05",
      "title": "Khám phá: AI làm được gì?",
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Đạt khi đúng tối thiểu 4/6 và giải thích hợp lí hai loại tính năng. Các em còn nhầm được ghép lại cặp thẻ để so sánh.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_0_20.jpg",
      "id": "01-06",
      "title": "Xem video để tìm hai điều",
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Đạt khi đúng tối thiểu 4/6 và giải thích hợp lí hai loại tính năng. Các em còn nhầm được ghép lại cặp thẻ để so sánh.",
        "answers": [
          "AI có thể hỗ trợ dịch câu, nhận dạng ảnh hoặc lời nói. Chấp nhận ví dụ phù hợp khác từ đoạn đã xem.",
          "Trước khi dùng, cần đối chiếu với bảng từ, đồ vật thật hoặc nhờ Thầy/Cô kiểm tra."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI giúp con người làm việc gì?\n2. Nói dễ hiểu: Người dùng cần kiểm tra điều gì?\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI có thể hỗ trợ dịch câu, nhận dạng ảnh hoặc lời nói. Chấp nhận ví dụ phù hợp khác từ đoạn đã xem.\nTrước khi dùng, cần đối chiếu với bảng từ, đồ vật thật hoặc nhờ Thầy/Cô kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "AI giúp con người làm việc gì?",
        "Người dùng cần kiểm tra điều gì?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "AI giúp con người làm việc gì?",
        "Người dùng cần kiểm tra điều gì?",
        "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI giúp con người làm việc gì?",
          "tone": "key",
          "note": "Thầy/Cô: AI giúp con người làm việc gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Người dùng cần kiểm tra điều gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Người dùng cần kiểm tra điều gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm."
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 0,
        "title": "Introducing How AI Works",
        "start": 0,
        "end": 89,
        "poster": "frame_0_20.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/1jVlIMJ2yBmzqD1H5hHDNj/9fe6b733248373a6546b44d1bad1baf6/ai-01-intro-to-ai.mp4",
        "question": "AI giúp gì? Em cần kiểm gì?",
        "local": "code-0.mp4"
      },
      "id": "01-07",
      "title": "AI giúp gì? Con người làm gì?",
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Đạt khi đúng tối thiểu 4/6 và giải thích hợp lí hai loại tính năng. Các em còn nhầm được ghép lại cặp thẻ để so sánh.",
        "answers": [
          "AI có thể hỗ trợ dịch câu, nhận dạng ảnh hoặc lời nói. Chấp nhận ví dụ phù hợp khác từ đoạn đã xem.",
          "Trước khi dùng, cần đối chiếu với bảng từ, đồ vật thật hoặc nhờ Thầy/Cô kiểm tra."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: Tìm một việc AI hỗ trợ. Nêu một việc người dùng cần làm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "AI có thể hỗ trợ dịch câu, nhận dạng ảnh hoặc lời nói. Chấp nhận ví dụ phù hợp khác từ đoạn đã xem.\nTrước khi dùng, cần đối chiếu với bảng từ, đồ vật thật hoặc nhờ Thầy/Cô kiểm tra.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “vì sao em thấy video này?”."
        }
      },
      "theme": "cream",
      "fallback": "AI hỗ trợ nhận dạng, ngôn ngữ và dự đoán. Con người cần kiểm kết quả trước khi dùng.",
      "v6": true,
      "screen": [
        "Tìm một việc AI hỗ trợ.",
        "Nêu một việc người dùng cần làm."
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 89 giây, em ghi một ví dụ vào vở."
      ],
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm một việc AI hỗ trợ.",
        "Nêu một việc người dùng cần làm."
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "id": "01-v7-youtube",
      "type": "guide",
      "title": "Vì sao em thấy video này?",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "YouTube gợi ý phim hoạt hình cho em.",
        "AI học từ hoạt động xem để gợi ý.",
        "Em chọn nội dung phù hợp với bài học."
      ],
      "scene": "video",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Đạt khi đúng tối thiểu 4/6 và giải thích hợp lí hai loại tính năng. Các em còn nhầm được ghép lại cặp thẻ để so sánh.",
        "answers": [
          "YouTube gợi ý phim hoạt hình cho em. / AI học từ hoạt động xem để gợi ý. / Em chọn nội dung phù hợp với bài học."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Vì sao em thấy video này?.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: YouTube gợi ý phim hoạt hình cho em.\n2. Nói dễ hiểu: AI học từ hoạt động xem để gợi ý.\n3. Điều cần nhớ: Em chọn nội dung phù hợp với bài học.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "YouTube gợi ý phim hoạt hình cho em. / AI học từ hoạt động xem để gợi ý. / Em chọn nội dung phù hợp với bài học.",
          "closing": "Thầy/Cô chốt: Em chọn nội dung phù hợp với bài học.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “máy đang đoán điều em thích”."
        }
      },
      "realImage": "frame_0_20.jpg",
      "number": 8,
      "originalTeachingPoints": [
        "YouTube gợi ý phim hoạt hình cho em.",
        "AI học từ hoạt động xem để gợi ý.",
        "Em chọn nội dung phù hợp với bài học."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "YouTube gợi ý phim hoạt hình cho em.",
          "tone": "key",
          "note": "Thầy/Cô: YouTube gợi ý phim hoạt hình cho em."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI học từ hoạt động xem để gợi ý.",
          "tone": "explain",
          "note": "Thầy/Cô: AI học từ hoạt động xem để gợi ý."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em chọn nội dung phù hợp với bài học.",
          "tone": "action",
          "note": "Thầy/Cô: Em chọn nội dung phù hợp với bài học."
        }
      ]
    },
    {
      "id": "01-v7-meaning",
      "type": "guide",
      "title": "Máy đang đoán điều em thích",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Máy không đọc được suy nghĩ của em.",
        "Máy tìm dấu hiệu từ những lần xem.",
        "Gợi ý có thể chưa đúng sở thích."
      ],
      "scene": "video",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Đạt khi đúng tối thiểu 4/6 và giải thích hợp lí hai loại tính năng. Các em còn nhầm được ghép lại cặp thẻ để so sánh.",
        "answers": [
          "Máy không đọc được suy nghĩ của em. / Máy tìm dấu hiệu từ những lần xem. / Gợi ý có thể chưa đúng sở thích."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Máy đang đoán điều em thích.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Máy không đọc được suy nghĩ của em.\n2. Nói dễ hiểu: Máy tìm dấu hiệu từ những lần xem.\n3. Điều cần nhớ: Gợi ý có thể chưa đúng sở thích.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Máy không đọc được suy nghĩ của em. / Máy tìm dấu hiệu từ những lần xem. / Gợi ý có thể chưa đúng sở thích.",
          "closing": "Thầy/Cô chốt: Gợi ý có thể chưa đúng sở thích.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "number": 9,
      "originalTeachingPoints": [
        "Máy không đọc được suy nghĩ của em.",
        "Máy tìm dấu hiệu từ những lần xem.",
        "Gợi ý có thể chưa đúng sở thích."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Máy không đọc được suy nghĩ của em.",
          "tone": "key",
          "note": "Thầy/Cô: Máy không đọc được suy nghĩ của em."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Máy tìm dấu hiệu từ những lần xem.",
          "tone": "explain",
          "note": "Thầy/Cô: Máy tìm dấu hiệu từ những lần xem."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Gợi ý có thể chưa đúng sở thích.",
          "tone": "action",
          "note": "Thầy/Cô: Gợi ý có thể chưa đúng sở thích."
        }
      ]
    },
    {
      "type": "concept",
      "id": "01-08",
      "title": "Ba dấu hiệu để tìm hiểu AI",
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Đạt khi đúng tối thiểu 4/6 và giải thích hợp lí hai loại tính năng. Các em còn nhầm được ghép lại cặp thẻ để so sánh.",
        "answers": [
          "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI nhận ảnh cốc và gợi tên đồ vật.\n2. Nói dễ hiểu: AI có thể học từ ví dụ để nhận dạng.\n3. Điều cần nhớ: Tìm: học từ ví dụ, nhận dạng, đưa dự đoán.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tìm dấu hiệu của một tính năng AI.",
        "Học từ ví dụ; nhận dạng; đưa dự đoán.",
        "Cần biết tính năng, không chỉ nhìn tốc độ."
      ],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 10,
      "v7": true,
      "originalTeachingPoints": [
        "Tìm dấu hiệu của một tính năng AI.",
        "Học từ ví dụ; nhận dạng; đưa dự đoán.",
        "Cần biết tính năng, không chỉ nhìn tốc độ."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI nhận ảnh cốc và gợi tên đồ vật.",
          "tone": "key",
          "note": "Thầy/Cô: AI nhận ảnh cốc và gợi tên đồ vật."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI có thể học từ ví dụ để nhận dạng.",
          "tone": "explain",
          "note": "Thầy/Cô: AI có thể học từ ví dụ để nhận dạng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Tìm: học từ ví dụ, nhận dạng, đưa dự đoán.",
          "tone": "action",
          "note": "Thầy/Cô: Tìm: học từ ví dụ, nhận dạng, đưa dự đoán."
        }
      ]
    },
    {
      "id": "01-09-mau",
      "type": "worked",
      "v6": true,
      "title": "Nhìn mẫu: chọn tính năng AI",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "video",
      "worked": {
        "title": "Nhìn mẫu: chọn tính năng AI",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Tính năng",
          "Việc giúp em",
          "Dữ liệu vào",
          "Kết quả gợi ý",
          "Cách kiểm"
        ],
        "values": [
          "Gợi ý video trên YouTube",
          "Tìm video học phù hợp",
          "Chủ đề em muốn học",
          "Một danh sách video",
          "Xem nội dung có đúng bài cần học không"
        ],
        "why": [
          "Tên tính năng giúp em nói đúng việc.",
          "Danh sách gợi ý chưa thay việc kiểm.",
          "Em chọn nội dung phục vụ bài học."
        ],
        "question": "Em sẽ kiểm ô cuối bằng cách nào?",
        "scene": "Video"
      },
      "targetId": "01-09",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Xem nội dung có đúng bài cần học không",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tính năng: Gợi ý video trên YouTube\nViệc giúp em: Tìm video học phù hợp\nDữ liệu vào: Chủ đề em muốn học\nKết quả gợi ý: Một danh sách video\nCách kiểm: Xem nội dung có đúng bài cần học không"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI gợi ý video dựa trên hoạt động xem.\n2. Nói dễ hiểu: Máy dùng hoạt động xem để đoán video em thích.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Tính năng: Gợi ý video trên YouTube\nViệc giúp em: Tìm video học phù hợp\nDữ liệu vào: Chủ đề em muốn học\nKết quả gợi ý: Một danh sách video\nCách kiểm: Xem nội dung có đúng bài cần học không",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 11,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI gợi ý video dựa trên hoạt động xem.",
          "tone": "key",
          "note": "Thầy/Cô: AI gợi ý video dựa trên hoạt động xem."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Máy dùng hoạt động xem để đoán video em thích.",
          "tone": "explain",
          "note": "Thầy/Cô: Máy dùng hoạt động xem để đoán video em thích."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em sẽ kiểm ô cuối bằng cách nào? Gợi ý: Xem nội dung có đúng bài cần học không"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P1.1 Phân loại tính năng",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "headers": [
          "STT",
          "Tính năng được mô tả",
          "Phân loại và căn cứ"
        ],
        "rows": [
          [
            "1",
            "Máy tính cơ bản tính 125 + 37.",
            "..."
          ],
          [
            "2",
            "Tính năng dùng AI dịch câu Anh sang Việt.",
            "..."
          ],
          [
            "3",
            "Ghi âm chỉ lưu tiếng để nghe lại.",
            "..."
          ],
          [
            "4",
            "Tính năng dùng AI chuyển lời nói thành chữ.",
            "..."
          ],
          [
            "5",
            "Bản đồ chỉ phóng to và thu nhỏ.",
            "..."
          ],
          [
            "6",
            "Tính năng dùng AI dự đoán giao thông.",
            "..."
          ]
        ],
        "questions": [],
        "answers": [
          "1: Không có AI trong tính năng mô tả. Thực hiện phép tính cơ bản theo quy tắc.",
          "2: Có AI. Đề xác định dùng mô hình AI xử lí ngôn ngữ.",
          "3: Không có AI trong tính năng mô tả. Chỉ lưu và phát lại âm thanh.",
          "4: Có AI. Nhận dạng nội dung lời nói thành văn bản.",
          "5: Không có AI trong tính năng mô tả. Thao tác hiển thị không chứng minh dùng AI.",
          "6: Có AI. Mô tả nêu rõ dự đoán bằng mô hình AI. Đạt tối thiểu 4/6 kèm hai giải thích hợp lí. Không suy rộng từ một tính năng sang cả ứng dụng."
        ]
      },
      "time": 5,
      "id": "01-09",
      "title": "P1.1 — Chọn và giải thích",
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1: Không có AI trong tính năng mô tả. Thực hiện phép tính cơ bản theo quy tắc.",
          "2: Có AI. Đề xác định dùng mô hình AI xử lí ngôn ngữ.",
          "3: Không có AI trong tính năng mô tả. Chỉ lưu và phát lại âm thanh.",
          "4: Có AI. Nhận dạng nội dung lời nói thành văn bản.",
          "5: Không có AI trong tính năng mô tả. Thao tác hiển thị không chứng minh dùng AI.",
          "6: Có AI. Mô tả nêu rõ dự đoán bằng mô hình AI. Đạt tối thiểu 4/6 kèm hai giải thích hợp lí. Không suy rộng từ một tính năng sang cả ứng dụng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Đọc sáu thẻ tính năng. Chọn: Có AI / Không có AI / Chưa đủ thông tin. Giải thích hai lựa chọn.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1: Không có AI trong tính năng mô tả. Thực hiện phép tính cơ bản theo quy tắc.\n2: Có AI. Đề xác định dùng mô hình AI xử lí ngôn ngữ.\n3: Không có AI trong tính năng mô tả. Chỉ lưu và phát lại âm thanh.\n4: Có AI. Nhận dạng nội dung lời nói thành văn bản.\n5: Không có AI trong tính năng mô tả. Thao tác hiển thị không chứng minh dùng AI.\n6: Có AI. Mô tả nêu rõ dự đoán bằng mô hình AI. Đạt tối thiểu 4/6 kèm hai giải thích hợp lí. Không suy rộng từ một tính năng sang cả ứng dụng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em so kết quả để rút ra điều có căn cứ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đọc sáu thẻ tính năng.",
        "Chọn: Có AI / Không có AI / Chưa đủ thông tin.",
        "Giải thích hai lựa chọn."
      ],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "01-09-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [
        "Đọc sáu thẻ tính năng.",
        "Chọn: Có AI / Không có AI / Chưa đủ thông tin.",
        "Giải thích hai lựa chọn."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P1.1 · Em tự làm"
    },
    {
      "type": "conclusion",
      "id": "01-10",
      "title": "Cùng một ứng dụng, khác tính năng",
      "note": {
        "activity": "Khám phá 2.1 Phân loại tính năng",
        "purpose": "Phân loại đúng ít nhất 4/6 trường hợp và có lí do.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
        "assessment": "Đạt khi đúng tối thiểu 4/6 và giải thích hợp lí hai loại tính năng. Các em còn nhầm được ghép lại cặp thẻ để so sánh.",
        "answers": [
          "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em so kết quả để rút ra điều có căn cứ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ghi âm khác chuyển lời nói thành chữ.\n2. Nói dễ hiểu: Phóng to bản đồ khác dự đoán giao thông.\n3. Điều cần nhớ: Thiếu thông tin thì tìm hiểu thêm.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Một ứng dụng có thể có cả tính năng dùng AI và tính năng thông thường. Thiếu thông tin thì cần tìm hiểu thêm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi âm khác chuyển lời nói thành chữ.",
        "Phóng to bản đồ khác dự đoán giao thông.",
        "Thiếu thông tin thì tìm hiểu thêm."
      ],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 30 giây, em nêu một căn cứ tại chỗ."
      ],
      "connector": "Em so kết quả để rút ra điều có căn cứ.",
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi âm khác chuyển lời nói thành chữ.",
        "Phóng to bản đồ khác dự đoán giao thông.",
        "Thiếu thông tin thì tìm hiểu thêm."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ghi âm khác chuyển lời nói thành chữ.",
          "tone": "key",
          "note": "Thầy/Cô: Ghi âm khác chuyển lời nói thành chữ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Phóng to bản đồ khác dự đoán giao thông.",
          "tone": "explain",
          "note": "Thầy/Cô: Phóng to bản đồ khác dự đoán giao thông."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Thiếu thông tin thì tìm hiểu thêm.",
          "tone": "action",
          "note": "Thầy/Cô: Thiếu thông tin thì tìm hiểu thêm."
        }
      ]
    },
    {
      "type": "divider",
      "id": "01-11",
      "title": "Thực hành: thử hai tính năng",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm dịch và nhận dạng ảnh",
        "purpose": "Tóm tắt hai tính năng qua đầu vào, kết quả, công dụng và cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra; hai lượt đúng không chứng minh công cụ luôn đúng.",
        "assessment": "Kiểm tra đủ hai dòng và cách đối chiếu. Chấp nhận kết quả đúng, sai hoặc không xác định nếu ghi trung thực.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “mở khóa bằng khuôn mặt”."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "01-v7-face",
      "type": "guide",
      "title": "Mở khóa bằng khuôn mặt",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Luyện tập / Thực hành",
      "screen": [
        "Điện thoại so khuôn mặt với mẫu đã lưu.",
        "Tối hoặc che mặt có thể khiến máy nhầm.",
        "Em kiểm lại; không coi nhận dạng là luôn đúng."
      ],
      "scene": "face",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ghi ở hai trang dịch và ảnh của P1.2",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Điện thoại so khuôn mặt với mẫu đã lưu. / Tối hoặc che mặt có thể khiến máy nhầm. / Em kiểm lại; không coi nhận dạng là luôn đúng."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Mở khóa bằng khuôn mặt.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Điện thoại so khuôn mặt với mẫu đã lưu.\n2. Nói dễ hiểu: Tối hoặc che mặt có thể khiến máy nhầm.\n3. Điều cần nhớ: Em kiểm lại; không coi nhận dạng là luôn đúng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Điện thoại so khuôn mặt với mẫu đã lưu. / Tối hoặc che mặt có thể khiến máy nhầm. / Em kiểm lại; không coi nhận dạng là luôn đúng.",
          "closing": "Thầy/Cô chốt: Em kiểm lại; không coi nhận dạng là luôn đúng.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "number": 15,
      "originalTeachingPoints": [
        "Điện thoại so khuôn mặt với mẫu đã lưu.",
        "Tối hoặc che mặt có thể khiến máy nhầm.",
        "Em kiểm lại; không coi nhận dạng là luôn đúng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Điện thoại so khuôn mặt với mẫu đã lưu.",
          "tone": "key",
          "note": "Thầy/Cô: Điện thoại so khuôn mặt với mẫu đã lưu."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Tối hoặc che mặt có thể khiến máy nhầm.",
          "tone": "explain",
          "note": "Thầy/Cô: Tối hoặc che mặt có thể khiến máy nhầm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em kiểm lại; không coi nhận dạng là luôn đúng.",
          "tone": "action",
          "note": "Thầy/Cô: Em kiểm lại; không coi nhận dạng là luôn đúng."
        }
      ]
    },
    {
      "id": "01-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu hai việc trong một bảng",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "worked": {
        "title": "Mẫu hai việc trong một bảng",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Việc 1",
          "Cách kiểm 1",
          "Việc 2",
          "Cách kiểm 2",
          "Nơi ghi"
        ],
        "values": [
          "Dịch câu This is a pen.",
          "So pen với nghĩa bút trong bảng từ",
          "Đưa ảnh cốc mẫu vào công cụ",
          "So gợi ý tên với cốc trong ảnh",
          "Ghi ở hai trang dịch và ảnh của P1.2"
        ],
        "why": [
          "Hai việc nhận hai dạng dữ liệu.",
          "Mỗi kết quả có cách kiểm phù hợp.",
          "Không cần chép lại ở slide hướng dẫn."
        ],
        "question": "Em ghi hai kết quả ở đâu?",
        "scene": "Translate"
      },
      "targetId": "01-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Ghi ở hai trang dịch và ảnh của P1.2",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Việc 1: Dịch câu This is a pen.\nCách kiểm 1: So pen với nghĩa bút trong bảng từ\nViệc 2: Đưa ảnh cốc mẫu vào công cụ\nCách kiểm 2: So gợi ý tên với cốc trong ảnh\nNơi ghi: Ghi ở hai trang dịch và ảnh của P1.2"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em ghi hai trải nghiệm: dịch câu và nhận ảnh.\n2. Nói dễ hiểu: Mỗi trải nghiệm ghi đầu vào, kết quả và cách kiểm.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Việc 1: Dịch câu This is a pen.\nCách kiểm 1: So pen với nghĩa bút trong bảng từ\nViệc 2: Đưa ảnh cốc mẫu vào công cụ\nCách kiểm 2: So gợi ý tên với cốc trong ảnh\nNơi ghi: Ghi ở hai trang dịch và ảnh của P1.2",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em ghi hai trải nghiệm: dịch câu và nhận ảnh.",
          "tone": "key",
          "note": "Thầy/Cô: Em ghi hai trải nghiệm: dịch câu và nhận ảnh."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Mỗi trải nghiệm ghi đầu vào, kết quả và cách kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: Mỗi trải nghiệm ghi đầu vào, kết quả và cách kiểm."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em ghi hai kết quả ở đâu? Gợi ý: Ghi ở hai trang dịch và ảnh của P1.2"
        }
      ]
    },
    {
      "type": "task",
      "id": "01-12",
      "title": "Hai trải nghiệm, một bảng ghi",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm dịch và nhận dạng ảnh",
        "purpose": "Tóm tắt hai tính năng qua đầu vào, kết quả, công dụng và cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra; hai lượt đúng không chứng minh công cụ luôn đúng.",
        "assessment": "Kiểm tra đủ hai dòng và cách đối chiếu. Chấp nhận kết quả đúng, sai hoặc không xác định nếu ghi trung thực.",
        "answers": [
          "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra. Hai lượt đúng không chứng minh công cụ luôn đúng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dịch hai câu tiếng Anh.\n2. Nói dễ hiểu: Thử tìm tên đồ vật từ hai ảnh.\n3. Điều cần nhớ: Ghi kết quả và cách kiểm tra ở P1.2.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra. Hai lượt đúng không chứng minh công cụ luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ bản dịch gốc trước khi đối chiếu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dịch hai câu tiếng Anh.",
        "Thử tìm tên đồ vật từ hai ảnh.",
        "Ghi kết quả và cách kiểm tra ở P1.2."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 11 phút, em thử dịch và thử ảnh trên máy."
      ],
      "sampleId": "01-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Dịch hai câu tiếng Anh.",
        "Thử tìm tên đồ vật từ hai ảnh.",
        "Ghi kết quả và cách kiểm tra ở P1.2."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dịch hai câu tiếng Anh.",
          "tone": "key",
          "note": "Thầy/Cô: Dịch hai câu tiếng Anh."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Thử tìm tên đồ vật từ hai ảnh.",
          "tone": "explain",
          "note": "Thầy/Cô: Thử tìm tên đồ vật từ hai ảnh."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi kết quả và cách kiểm tra ở P1.2.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi kết quả và cách kiểm tra ở P1.2."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 6,
      "id": "01-13",
      "title": "Dịch trước, đối chiếu sau",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm dịch và nhận dạng ảnh",
        "purpose": "Tóm tắt hai tính năng qua đầu vào, kết quả, công dụng và cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra; hai lượt đúng không chứng minh công cụ luôn đúng.",
        "assessment": "Kiểm tra đủ hai dòng và cách đối chiếu. Chấp nhận kết quả đúng, sai hoặc không xác định nếu ghi trung thực.",
        "answers": [
          "Bản dịch phù hợp: Đây là một chiếc cặp sách. Con mèo ở dưới cái bàn. Chấp nhận cách nói tương đương.",
          "Nhận dạng ảnh nhận ảnh đồ vật và trả gợi ý tên/loại kết quả. Có thể giúp tìm hiểu hoặc phân loại đồ vật. Kết quả tìm kiếm bằng ảnh có thể là nhiều gợi ý, em ghi đúng điều quan sát.",
          "Ảnh A và B cùng chụp cốc. Đối chiếu với vật thật, không buộc ảnh tối phải sai.",
          "Mỗi tính năng cần có công dụng và cách kiểm tra. Ghi rõ tự thao tác, quan sát Thầy/Cô hay dùng học liệu dự phòng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ bản dịch gốc trước khi đối chiếu.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: This is a school bag.\n2. Nói dễ hiểu: The cat is under the table.\n3. Điều cần nhớ: Ghi bản dịch gốc vào P1.2.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bản dịch phù hợp: Đây là một chiếc cặp sách. Con mèo ở dưới cái bàn. Chấp nhận cách nói tương đương.\nNhận dạng ảnh nhận ảnh đồ vật và trả gợi ý tên/loại kết quả. Có thể giúp tìm hiểu hoặc phân loại đồ vật. Kết quả tìm kiếm bằng ảnh có thể là nhiều gợi ý, em ghi đúng điều quan sát.\nẢnh A và B cùng chụp cốc. Đối chiếu với vật thật, không buộc ảnh tối phải sai.\nMỗi tính năng cần có công dụng và cách kiểm tra. Ghi rõ tự thao tác, quan sát Thầy/Cô hay dùng học liệu dự phòng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu đã dịch xong. Giờ em thử dữ liệu ảnh."
        }
      },
      "theme": "cream",
      "recordTarget": "01-17",
      "recordPage": 0,
      "publicComparison": true,
      "v6": true,
      "screen": [
        "This is a school bag.",
        "The cat is under the table.",
        "Ghi bản dịch gốc vào P1.2."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cat",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Em giữ bản dịch gốc trước khi đối chiếu.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "This is a school bag.",
        "The cat is under the table.",
        "Ghi bản dịch gốc vào P1.2."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "This is a school bag.",
          "tone": "key",
          "note": "Thầy/Cô: This is a school bag."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "The cat is under the table.",
          "tone": "explain",
          "note": "Thầy/Cô: The cat is under the table."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi bản dịch gốc vào P1.2.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi bản dịch gốc vào P1.2."
        }
      ]
    },
    {
      "type": "step",
      "step": 2,
      "time": 6,
      "id": "01-15",
      "title": "Hai ảnh cùng một chiếc cốc",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm dịch và nhận dạng ảnh",
        "purpose": "Tóm tắt hai tính năng qua đầu vào, kết quả, công dụng và cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra; hai lượt đúng không chứng minh công cụ luôn đúng.",
        "assessment": "Kiểm tra đủ hai dòng và cách đối chiếu. Chấp nhận kết quả đúng, sai hoặc không xác định nếu ghi trung thực.",
        "answers": [
          "Bản dịch phù hợp: Đây là một chiếc cặp sách. Con mèo ở dưới cái bàn. Chấp nhận cách nói tương đương.",
          "Nhận dạng ảnh nhận ảnh đồ vật và trả gợi ý tên/loại kết quả. Có thể giúp tìm hiểu hoặc phân loại đồ vật. Kết quả tìm kiếm bằng ảnh có thể là nhiều gợi ý, em ghi đúng điều quan sát.",
          "Ảnh A và B cùng chụp cốc. Đối chiếu với vật thật, không buộc ảnh tối phải sai.",
          "Mỗi tính năng cần có công dụng và cách kiểm tra. Ghi rõ tự thao tác, quan sát Thầy/Cô hay dùng học liệu dự phòng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu đã dịch xong. Giờ em thử dữ liệu ảnh.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ảnh A: đủ sáng.\n2. Nói dễ hiểu: Ảnh B: thiếu sáng.\n3. Điều cần nhớ: Công cụ gợi ý gì? Có phù hợp không?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Bản dịch phù hợp: Đây là một chiếc cặp sách. Con mèo ở dưới cái bàn. Chấp nhận cách nói tương đương.\nNhận dạng ảnh nhận ảnh đồ vật và trả gợi ý tên/loại kết quả. Có thể giúp tìm hiểu hoặc phân loại đồ vật. Kết quả tìm kiếm bằng ảnh có thể là nhiều gợi ý, em ghi đúng điều quan sát.\nẢnh A và B cùng chụp cốc. Đối chiếu với vật thật, không buộc ảnh tối phải sai.\nMỗi tính năng cần có công dụng và cách kiểm tra. Ghi rõ tự thao tác, quan sát Thầy/Cô hay dùng học liệu dự phòng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "recordTarget": "01-17",
      "recordPage": 3,
      "imageTool": true,
      "v6": true,
      "screen": [
        "Ảnh A: đủ sáng.",
        "Ảnh B: thiếu sáng.",
        "Công cụ gợi ý gì? Có phù hợp không?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Câu đã dịch xong. Giờ em thử dữ liệu ảnh.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "Ảnh A: đủ sáng.",
        "Ảnh B: thiếu sáng.",
        "Công cụ gợi ý gì? Có phù hợp không?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ảnh A: đủ sáng.",
          "tone": "key",
          "note": "Thầy/Cô: Ảnh A: đủ sáng."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ảnh B: thiếu sáng.",
          "tone": "explain",
          "note": "Thầy/Cô: Ảnh B: thiếu sáng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Công cụ gợi ý gì? Có phù hợp không?",
          "tone": "action",
          "note": "Thầy/Cô: Công cụ gợi ý gì? Có phù hợp không?"
        }
      ]
    },
    {
      "id": "01-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Ghi mẫu một lần dịch",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "worked": {
        "title": "Ghi mẫu một lần dịch",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Câu đưa vào",
          "Kết quả mẫu",
          "Nguồn kiểm",
          "Công dụng",
          "Cách kiểm"
        ],
        "values": [
          "This is a pen.",
          "Đây là một cây bút.",
          "Bảng từ: pen = bút",
          "Giúp hiểu câu tiếng Anh",
          "So nghĩa với bảng từ"
        ],
        "why": [
          "Giữ bản gốc rồi mới kiểm.",
          "Không gọi đọc mẫu là tự chạy AI.",
          "Em ghi kết quả thật khi tự thử."
        ],
        "question": "Em sẽ điền cách kiểm thế nào?",
        "scene": "Translate"
      },
      "targetId": "01-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "So nghĩa với bảng từ",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Câu đưa vào: This is a pen.\nKết quả mẫu: Đây là một cây bút.\nNguồn kiểm: Bảng từ: pen = bút\nCông dụng: Giúp hiểu câu tiếng Anh\nCách kiểm: So nghĩa với bảng từ"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ví dụ: This is a pen.\n2. Nói dễ hiểu: Pen nghĩa là bút; em so với bảng từ.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Câu đưa vào: This is a pen.\nKết quả mẫu: Đây là một cây bút.\nNguồn kiểm: Bảng từ: pen = bút\nCông dụng: Giúp hiểu câu tiếng Anh\nCách kiểm: So nghĩa với bảng từ",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ví dụ: This is a pen.",
          "tone": "key",
          "note": "Thầy/Cô: Ví dụ: This is a pen."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Pen nghĩa là bút; em so với bảng từ.",
          "tone": "explain",
          "note": "Thầy/Cô: Pen nghĩa là bút; em so với bảng từ."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em sẽ điền cách kiểm thế nào? Gợi ý: So nghĩa với bảng từ"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P1.2 bảng ghi trải nghiệm AI",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Bản dịch phù hợp: Đây là một chiếc cặp sách. Con mèo ở dưới cái bàn. Chấp nhận cách nói tương đương.",
          "Nhận dạng ảnh nhận ảnh đồ vật và trả gợi ý tên/loại kết quả. Có thể giúp tìm hiểu hoặc phân loại đồ vật. Kết quả tìm kiếm bằng ảnh có thể là nhiều gợi ý, em ghi đúng điều quan sát.",
          "Ảnh A và B cùng chụp cốc. Đối chiếu với vật thật, không buộc ảnh tối phải sai.",
          "Mỗi tính năng cần có công dụng và cách kiểm tra. Ghi rõ tự thao tác, quan sát Thầy/Cô hay dùng học liệu dự phòng."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Bảng từ để kiểm tra: school bag = cặp sách. Cat = mèo. Under = ở dưới. Table = bàn.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Ghi kết quả dịch",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Câu tiếng Anh",
              "Bản dịch",
              "Em đối chiếu"
            ],
            "rows": [
              [
                "This is a school bag.",
                {
                  "label": "Bản dịch câu 1",
                  "key": "01-17-v3-0"
                },
                {
                  "label": "Nhận xét câu 1",
                  "key": "01-17-v3-1"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi kết quả dịch",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Câu tiếng Anh",
              "Bản dịch",
              "Em đối chiếu"
            ],
            "rows": [
              [
                "The cat is under the table.",
                {
                  "label": "Bản dịch câu 2",
                  "key": "01-17-v3-2"
                },
                {
                  "label": "Nhận xét câu 2",
                  "key": "01-17-v3-3"
                }
              ]
            ],
            "originalPage": 0
          },
          {
            "title": "Ghi kết quả nhận dạng ảnh",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh được thử",
              "AI gợi gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "Ảnh A: cốc đủ sáng",
                {
                  "label": "Gợi ý công cụ trả về — ảnh A",
                  "key": "01-17-v3-4"
                },
                {
                  "label": "Nhận xét ảnh A",
                  "key": "01-17-v3-5"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Ghi kết quả nhận dạng ảnh",
            "instruction": "Em hoàn thành dòng này.",
            "headers": [
              "Ảnh được thử",
              "AI gợi gì?",
              "So vật thật"
            ],
            "rows": [
              [
                "Ảnh B: cốc thiếu sáng",
                {
                  "label": "Gợi ý công cụ trả về — ảnh B",
                  "key": "01-17-v3-6"
                },
                {
                  "label": "Nhận xét ảnh B",
                  "key": "01-17-v3-7"
                }
              ]
            ],
            "originalPage": 1
          },
          {
            "title": "Rút ra điều em học được",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tính năng dịch giúp em việc gì?",
                "key": "01-17-v3-8"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Rút ra điều em học được",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Ảnh vào, kết quả ra và công dụng",
                "key": "01-17-v4-image-purpose"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Rút ra điều em học được",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Vì sao vẫn cần kiểm tra kết quả nhận dạng ảnh?",
                "key": "01-17-v3-9"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Rút ra điều em học được",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã làm theo cách nào?",
                "key": "01-17-v3-10"
              }
            ],
            "originalPage": 2
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 3,
          "2": 5
        }
      },
      "time": 4,
      "id": "01-17",
      "title": "P1.2 — Ghi kết quả, rồi rút ý",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm dịch và nhận dạng ảnh",
        "purpose": "Hoàn thành nhật kí hai trải nghiệm theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra; hai lượt đúng không chứng minh công cụ luôn đúng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Bản dịch phù hợp: Đây là một chiếc cặp sách. Con mèo ở dưới cái bàn. Chấp nhận cách nói tương đương.",
          "Nhận dạng ảnh nhận ảnh đồ vật và trả gợi ý tên/loại kết quả. Có thể giúp tìm hiểu hoặc phân loại đồ vật. Kết quả tìm kiếm bằng ảnh có thể là nhiều gợi ý, em ghi đúng điều quan sát.",
          "Ảnh A và B cùng chụp cốc. Đối chiếu với vật thật, không buộc ảnh tối phải sai.",
          "Mỗi tính năng cần có công dụng và cách kiểm tra. Ghi rõ tự thao tác, quan sát Thầy/Cô hay dùng học liệu dự phòng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Trang 1: bản dịch và nhận xét. Trang 2: gợi ý từ ảnh và nhận xét. Trang 3: công dụng và cách kiểm tra.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Bản dịch phù hợp: Đây là một chiếc cặp sách. Con mèo ở dưới cái bàn. Chấp nhận cách nói tương đương.\nNhận dạng ảnh nhận ảnh đồ vật và trả gợi ý tên/loại kết quả. Có thể giúp tìm hiểu hoặc phân loại đồ vật. Kết quả tìm kiếm bằng ảnh có thể là nhiều gợi ý, em ghi đúng điều quan sát.\nẢnh A và B cùng chụp cốc. Đối chiếu với vật thật, không buộc ảnh tối phải sai.\nMỗi tính năng cần có công dụng và cách kiểm tra. Ghi rõ tự thao tác, quan sát Thầy/Cô hay dùng học liệu dự phòng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Trang 1: bản dịch và nhận xét.",
        "Trang 2: gợi ý từ ảnh và nhận xét.",
        "Trang 3: công dụng và cách kiểm tra."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "01-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 21,
      "v7": true,
      "originalTeachingPoints": [
        "Trang 1: bản dịch và nhận xét.",
        "Trang 2: gợi ý từ ảnh và nhận xét.",
        "Trang 3: công dụng và cách kiểm tra."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P1.2 · Ghi kết quả"
    },
    {
      "type": "report",
      "id": "01-18",
      "title": "Em đã thấy gì và kiểm bằng gì?",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm dịch và nhận dạng ảnh",
        "purpose": "Tóm tắt hai tính năng qua đầu vào, kết quả, công dụng và cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra; hai lượt đúng không chứng minh công cụ luôn đúng.",
        "assessment": "Kiểm tra đủ hai dòng và cách đối chiếu. Chấp nhận kết quả đúng, sai hoặc không xác định nếu ghi trung thực.",
        "answers": [
          "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra. Hai lượt đúng không chứng minh công cụ luôn đúng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đầu vào nào?\n2. Nói dễ hiểu: Kết quả nào?\n3. Điều cần nhớ: Kiểm tra bằng gì?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra. Hai lượt đúng không chứng minh công cụ luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Đầu vào nào?",
        "Kết quả nào?",
        "Kiểm tra bằng gì?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cups",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [
        "Đầu vào nào?",
        "Kết quả nào?",
        "Kiểm tra bằng gì?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đầu vào nào?",
          "tone": "key",
          "note": "Thầy/Cô: Đầu vào nào?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Kết quả nào?",
          "tone": "explain",
          "note": "Thầy/Cô: Kết quả nào?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Kiểm tra bằng gì?",
          "tone": "action",
          "note": "Thầy/Cô: Kiểm tra bằng gì?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "01-20",
      "title": "Luyện tập: phân biệt tính năng",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Củng cố nhận biết tính năng và giới hạn của AI.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Nhận biết AI theo tính năng; xác định đầu vào và đầu ra; kiểm tra kết quả trước khi dùng.",
        "assessment": "Thu nhanh câu 4 của các em từng nhầm mọi bản đồ số đều dùng AI. Hỗ trợ bằng hai mô tả tương phản.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "01-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu phân biệt một tính năng",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "audio",
      "worked": {
        "title": "Mẫu phân biệt một tính năng",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Tính năng",
          "Việc máy làm",
          "Có thấy AI trong mô tả?",
          "Căn cứ",
          "Điều cần hỏi thêm"
        ],
        "values": [
          "Phát tệp ghi âm",
          "Phát lại âm thanh",
          "Chưa thấy dùng AI trong việc này",
          "Chỉ phát lại, chưa nhận nội dung lời nói",
          "Tính năng nào dùng AI nếu có?"
        ],
        "why": [
          "Nói đúng tính năng đang xét.",
          "Không suy ra cả ứng dụng không có AI.",
          "Thiếu mô tả thì em hỏi thêm."
        ],
        "question": "Em sẽ hỏi thêm điều gì?",
        "scene": "Audio"
      },
      "targetId": "01-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Tính năng nào dùng AI nếu có?",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tính năng: Phát tệp ghi âm\nViệc máy làm: Phát lại âm thanh\nCó thấy AI trong mô tả?: Chưa thấy dùng AI trong việc này\nCăn cứ: Chỉ phát lại, chưa nhận nội dung lời nói\nĐiều cần hỏi thêm: Tính năng nào dùng AI nếu có?"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Tệp ghi âm được phát lại, chưa nhận lời nói.\n2. Nói dễ hiểu: Phát lại âm thanh khác với hiểu nội dung lời nói.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Tính năng: Phát tệp ghi âm\nViệc máy làm: Phát lại âm thanh\nCó thấy AI trong mô tả?: Chưa thấy dùng AI trong việc này\nCăn cứ: Chỉ phát lại, chưa nhận nội dung lời nói\nĐiều cần hỏi thêm: Tính năng nào dùng AI nếu có?",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Tệp ghi âm được phát lại, chưa nhận lời nói.",
          "tone": "key",
          "note": "Thầy/Cô: Tệp ghi âm được phát lại, chưa nhận lời nói."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Phát lại âm thanh khác với hiểu nội dung lời nói.",
          "tone": "explain",
          "note": "Thầy/Cô: Phát lại âm thanh khác với hiểu nội dung lời nói."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em sẽ hỏi thêm điều gì? Gợi ý: Tính năng nào dùng AI nếu có?"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P1.3 Luyện tập và vận dụng",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "1: C. 2: Đưa vào văn bản tiếng Anh, nhận bản dịch tiếng Việt.",
          "3: Sai. Cần xem tính năng cụ thể. 4: Sai. Hai ảnh đúng chưa cho biết mọi ảnh khác. 5: Chưa đủ căn cứ. Thao tác phóng to không cho biết mô hình AI nào đang được dùng."
        ],
        "pages": [
          {
            "title": "Nhận biết tính năng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Trường hợp nào nêu rõ có dùng AI?",
                "options": [
                  "A. Mở tệp đã lưu",
                  "B. Tính phép cộng bằng máy tính cơ bản",
                  "C. Dùng mô hình AI chuyển lời nói thành chữ",
                  "D. Phát lại bản ghi âm"
                ],
                "key": "01-21-v3-0",
                "optionLabels": [
                  "A. Mở tệp đã lưu",
                  "B. Tính phép cộng bằng máy tính cơ bản",
                  "C. Dùng mô hình AI chuyển lời nói thành chữ",
                  "D. Phát lại bản ghi âm"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Nhận biết tính năng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Khi dịch Anh–Việt, em đưa gì vào và nhận gì về?",
                "key": "01-21-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Sửa nhận định chưa đúng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“Mọi ứng dụng điện thoại đều là AI.”",
                "key": "01-21-v3-2"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Sửa nhận định chưa đúng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“AI nhận đúng hai ảnh thì sẽ nhận đúng mọi ảnh.”",
                "key": "01-21-v3-3"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Sửa nhận định chưa đúng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Phóng to bản đồ đã cho biết chắc có AI chưa?",
                "key": "01-21-v3-4"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2
        }
      },
      "time": 4,
      "id": "01-21",
      "title": "P1.3A — Em phân biệt được chưa?",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành em đã nhận biết đúng chưa? theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Nhận biết AI theo tính năng; xác định đầu vào và đầu ra; kiểm tra kết quả trước khi dùng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "1: C. 2: Đưa vào văn bản tiếng Anh, nhận bản dịch tiếng Việt.",
          "3: Sai. Cần xem tính năng cụ thể. 4: Sai. Hai ảnh đúng chưa cho biết mọi ảnh khác. 5: Chưa đủ căn cứ. Thao tác phóng to không cho biết mô hình AI nào đang được dùng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Chọn tính năng có AI. Nêu đầu vào và đầu ra. Sửa hai nhận định quá chắc chắn.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "1: C. 2: Đưa vào văn bản tiếng Anh, nhận bản dịch tiếng Việt.\n3: Sai. Cần xem tính năng cụ thể. 4: Sai. Hai ảnh đúng chưa cho biết mọi ảnh khác. 5: Chưa đủ căn cứ. Thao tác phóng to không cho biết mô hình AI nào đang được dùng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn tính năng có AI.",
        "Nêu đầu vào và đầu ra.",
        "Sửa hai nhận định quá chắc chắn."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "01-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn tính năng có AI.",
        "Nêu đầu vào và đầu ra.",
        "Sửa hai nhận định quá chắc chắn."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P1.3A · Nhận biết tính năng"
    },
    {
      "type": "recap",
      "id": "01-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm dịch và nhận dạng ảnh",
        "purpose": "Tóm tắt hai tính năng qua đầu vào, kết quả, công dụng và cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra; hai lượt đúng không chứng minh công cụ luôn đúng.",
        "assessment": "Kiểm tra đủ hai dòng và cách đối chiếu. Chấp nhận kết quả đúng, sai hoặc không xác định nếu ghi trung thực.",
        "answers": [
          "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra. Hai lượt đúng không chứng minh công cụ luôn đúng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Xét tính năng cụ thể khi nói về AI.\n2. Nói dễ hiểu: AI hỗ trợ dịch, nhận dạng ảnh hoặc lời nói.\n3. Điều cần nhớ: Đối chiếu kết quả trước khi dùng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI có thể hỗ trợ dịch và nhận biết đồ vật nhưng kết quả cần kiểm tra. Hai lượt đúng không chứng minh công cụ luôn đúng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Xét tính năng cụ thể khi nói về AI.",
        "AI hỗ trợ dịch, nhận dạng ảnh hoặc lời nói.",
        "Đối chiếu kết quả trước khi dùng."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [
        "Xét tính năng cụ thể khi nói về AI.",
        "AI hỗ trợ dịch, nhận dạng ảnh hoặc lời nói.",
        "Đối chiếu kết quả trước khi dùng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Xét tính năng cụ thể khi nói về AI.",
          "tone": "key",
          "note": "Thầy/Cô: Xét tính năng cụ thể khi nói về AI."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "AI hỗ trợ dịch, nhận dạng ảnh hoặc lời nói.",
          "tone": "explain",
          "note": "Thầy/Cô: AI hỗ trợ dịch, nhận dạng ảnh hoặc lời nói."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đối chiếu kết quả trước khi dùng.",
          "tone": "action",
          "note": "Thầy/Cô: Đối chiếu kết quả trước khi dùng."
        }
      ]
    },
    {
      "type": "divider",
      "id": "01-22",
      "title": "Vận dụng: giới thiệu một tính năng",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Chọn một tính năng AI theo nhu cầu và nêu cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chọn đúng công cụ cần đi cùng kiểm tra kết quả và trách nhiệm sử dụng.",
        "assessment": "Kết hợp thẻ cá nhân với bảng ghi để nhận xét 6.3.TC1b. Thiếu công dụng thì hỏi bổ sung đầu buổi sau.",
        "answers": [],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "01-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu thẻ giới thiệu tính năng",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "audio",
      "worked": {
        "title": "Mẫu thẻ giới thiệu tính năng",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Tên tính năng",
          "Việc giúp em",
          "Dữ liệu vào",
          "Kết quả",
          "Cách kiểm"
        ],
        "values": [
          "Chuyển lời nói thành chữ",
          "Ghi lại một câu em đọc",
          "Âm thanh câu nói",
          "Dòng chữ AI nhận ra",
          "Đọc lại, so với câu em đã nói"
        ],
        "why": [
          "Tách âm thanh và dòng chữ.",
          "Ghi việc có thể quan sát.",
          "Dòng chữ vẫn có thể sai từ."
        ],
        "question": "Em kiểm dòng chữ bằng gì?",
        "scene": "Audio"
      },
      "targetId": "01-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đọc lại, so với câu em đã nói",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Tên tính năng: Chuyển lời nói thành chữ\nViệc giúp em: Ghi lại một câu em đọc\nDữ liệu vào: Âm thanh câu nói\nKết quả: Dòng chữ AI nhận ra\nCách kiểm: Đọc lại, so với câu em đã nói"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI chuyển một câu em đọc thành chữ.\n2. Nói dễ hiểu: Em đọc lại chữ, so với câu đã nói.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Tên tính năng: Chuyển lời nói thành chữ\nViệc giúp em: Ghi lại một câu em đọc\nDữ liệu vào: Âm thanh câu nói\nKết quả: Dòng chữ AI nhận ra\nCách kiểm: Đọc lại, so với câu em đã nói",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI chuyển một câu em đọc thành chữ.",
          "tone": "key",
          "note": "Thầy/Cô: AI chuyển một câu em đọc thành chữ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Em đọc lại chữ, so với câu đã nói.",
          "tone": "explain",
          "note": "Thầy/Cô: Em đọc lại chữ, so với câu đã nói."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em kiểm dòng chữ bằng gì? Gợi ý: Đọc lại, so với câu em đã nói"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P1.3 Luyện tập và vận dụng",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Chấp nhận ví dụ dịch hoặc nhận dạng nếu nêu rõ công dụng, dữ liệu vào, kết quả và cách kiểm tra. Không yêu cầu mọi nhóm có cùng kết quả công cụ."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Cách viết: Tính năng ... Nhận ... Và trả về .... Em kiểm tra bằng ... .",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Giới thiệu một tính năng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Tên tính năng và việc nó giúp em làm",
                "key": "01-23-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Giới thiệu một tính năng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Dữ liệu đưa vào và kết quả nhận được",
                "key": "01-23-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Giới thiệu một tính năng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Một kết quả có thể cần kiểm tra",
                "key": "01-23-v3-2"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Giới thiệu một tính năng",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ kiểm tra bằng cách nào?",
                "key": "01-23-v3-3"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 3,
      "id": "01-23",
      "title": "P1.3B — Giới thiệu một tính năng",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Hoàn thành giới thiệu một tính năng ai theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chọn đúng công cụ cần đi cùng kiểm tra kết quả và trách nhiệm sử dụng.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Chấp nhận ví dụ dịch hoặc nhận dạng nếu nêu rõ công dụng, dữ liệu vào, kết quả và cách kiểm tra. Không yêu cầu mọi nhóm có cùng kết quả công cụ."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Tính năng giúp việc gì? Nhận gì và trả gì? Em kiểm tra kết quả bằng gì?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Chấp nhận ví dụ dịch hoặc nhận dạng nếu nêu rõ công dụng, dữ liệu vào, kết quả và cách kiểm tra. Không yêu cầu mọi nhóm có cùng kết quả công cụ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Tính năng giúp việc gì?",
        "Nhận gì và trả gì?",
        "Em kiểm tra kết quả bằng gì?"
      ],
      "phase": "Vận dụng",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "01-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [
        "Tính năng giúp việc gì?",
        "Nhận gì và trả gì?",
        "Em kiểm tra kết quả bằng gì?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P1.3B · Giới thiệu tính năng"
    },
    {
      "type": "home",
      "id": "01-24",
      "title": "Quan sát thêm một tính năng",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Chọn một tính năng AI theo nhu cầu và nêu cách kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Chọn đúng công cụ cần đi cùng kiểm tra kết quả và trách nhiệm sử dụng.",
        "assessment": "Kết hợp thẻ cá nhân với bảng ghi để nhận xét 6.3.TC1b. Thiếu công dụng thì hỏi bổ sung đầu buổi sau.",
        "answers": [
          "Chọn đúng công cụ cần đi cùng kiểm tra kết quả và trách nhiệm sử dụng."
        ],
        "source": "Bài 1 Giới thiệu AI, trang PDF 1–4; Bài 3 Nhận dạng hình ảnh, mục Chất lượng hình ảnh, trang in 20; Bài 8 AI dịch thuật, trang in 57; Bài 9 Máy biết nói, trang in 64. Chỉ khai thác chức năng, không thực hiện bài lập trình.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ghi tên và công dụng.\n2. Nói dễ hiểu: Nêu căn cứ hoặc điều chưa rõ.\n3. Điều cần nhớ: Không cần tạo tài khoản mới.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Chọn đúng công cụ cần đi cùng kiểm tra kết quả và trách nhiệm sử dụng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi tên và công dụng.",
        "Nêu căn cứ hoặc điều chưa rõ.",
        "Không cần tạo tài khoản mới."
      ],
      "phase": "Vận dụng",
      "scene": "translate",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 30,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi tên và công dụng.",
        "Nêu căn cứ hoặc điều chưa rõ.",
        "Không cần tạo tài khoản mới."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ghi tên và công dụng.",
          "tone": "key",
          "note": "Thầy/Cô: Ghi tên và công dụng."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nêu căn cứ hoặc điều chưa rõ.",
          "tone": "explain",
          "note": "Thầy/Cô: Nêu căn cứ hoặc điều chưa rõ."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không cần tạo tài khoản mới.",
          "tone": "action",
          "note": "Thầy/Cô: Không cần tạo tài khoản mới."
        }
      ]
    }
  ],
  "rubric": [],
  "evidence": [
    [
      "Phân loại và trải nghiệm",
      "6.3.TC1b",
      "Tóm tắt được hai tính năng về đầu vào, loại kết quả, chức năng và ứng dụng.",
      "P1.2 của nhóm và P1.3B cá nhân",
      "Đủ hai tính năng, có công dụng và kiểm tra; nếu chỉ phân loại thì chưa đủ minh chứng."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
