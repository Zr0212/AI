window.AI6_LESSON={
  "id": 5,
  "title": "Bài 5. AI hỗ trợ học tập nhưng con người quyết định",
  "mode": "Trực tiếp tại phòng Tin học",
  "count": 30,
  "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
  "materials": "Thầy/Cô chuẩn bị học liệu có sẵn trong gói. Chỉ dùng dữ liệu mẫu. Thử công cụ trước giờ học.",
  "alternatives": "Thiếu thiết bị, em quan sát Thầy/Cô. Em vẫn ghi rõ cách thực hiện.",
  "video": {
    "index": 6,
    "title": "AI: How Chatbots and Large Language Models Work",
    "start": 120,
    "end": 150,
    "poster": "frame_6_135.jpg",
    "url": "https://contentful-videos.code.org/90t6bu6vlf76/5PAq7BvRs4dvpeDtdBeciP/df29bc68f49899c2eb16c161b6e4698d/HowAIWorks_LLM_SM_CoBrand__1_.mp4",
    "question": "Hệ thống gợi ý từ/câu theo mẫu đã học. Ý nghĩa, sự thật và ngữ cảnh nào vẫn cần người kiểm tra?",
    "local": "code-6.mp4"
  },
  "outcome": "Bảng kiểm bản dịch và lí do giữ, sửa hoặc chưa dùng.",
  "slides": [
    {
      "type": "cover",
      "id": "05-01",
      "title": "Bài 5. AI hỗ trợ học tập nhưng con người quyết định",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra một câu trả lời tự tin vẫn cần kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc tên bài; nêu điều muốn biết.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI hỗ trợ đưa gợi ý; người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp.",
        "assessment": "Ghi nhận các em viện dẫn căn cứ. Nếu chỉ tin giọng văn tự tin thì hỏi lại cách kiểm tra.",
        "answers": [
          "AI hỗ trợ đưa gợi ý. Người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng một điều muốn tìm hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc tên bài; nêu điều muốn biết.",
          "answer": "AI hỗ trợ đưa gợi ý. Người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Đầu bài cho biết chủ đề. Em xem việc cần làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc đầu bài trên slide."
      ],
      "connector": "Em bắt đầu bằng một điều muốn tìm hiểu.",
      "number": 1,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc tên bài; nêu điều muốn biết."
    },
    {
      "type": "goals",
      "id": "05-02",
      "title": "Hôm nay em làm được gì?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra một câu trả lời tự tin vẫn cần kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI hỗ trợ đưa gợi ý; người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp.",
        "assessment": "Ghi nhận các em viện dẫn căn cứ. Nếu chỉ tin giọng văn tự tin thì hỏi lại cách kiểm tra.",
        "answers": [
          "AI hỗ trợ đưa gợi ý. Người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Đầu bài cho biết chủ đề. Em xem việc cần làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dùng AI hỗ trợ dịch câu mẫu.\n2. Nói dễ hiểu: Kiểm chi tiết bằng nguồn phù hợp.\n3. Điều cần nhớ: Giữ, sửa hoặc chưa dùng và nêu lí do.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ đưa gợi ý. Người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ việc quen thuộc, em thử nêu câu hỏi."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dùng AI hỗ trợ dịch câu mẫu.",
        "Kiểm chi tiết bằng nguồn phù hợp.",
        "Giữ, sửa hoặc chưa dùng và nêu lí do."
      ],
      "phase": "Khởi động",
      "scene": "translate",
      "taskLines": [
        "Trong 20 giây, em chọn một mục tiêu trên slide."
      ],
      "connector": "Đầu bài cho biết chủ đề. Em xem việc cần làm.",
      "number": 2,
      "v7": true,
      "originalTeachingPoints": [
        "Dùng AI hỗ trợ dịch câu mẫu.",
        "Kiểm chi tiết bằng nguồn phù hợp.",
        "Giữ, sửa hoặc chưa dùng và nêu lí do."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dùng AI hỗ trợ dịch câu mẫu.",
          "tone": "key",
          "note": "Thầy/Cô: Dùng AI hỗ trợ dịch câu mẫu."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Kiểm chi tiết bằng nguồn phù hợp.",
          "tone": "explain",
          "note": "Thầy/Cô: Kiểm chi tiết bằng nguồn phù hợp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Giữ, sửa hoặc chưa dùng và nêu lí do.",
          "tone": "action",
          "note": "Thầy/Cô: Giữ, sửa hoặc chưa dùng và nêu lí do."
        }
      ]
    },
    {
      "type": "divider",
      "id": "05-03",
      "title": "Khởi động",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra một câu trả lời tự tin vẫn cần kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI hỗ trợ đưa gợi ý; người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp.",
        "assessment": "Ghi nhận các em viện dẫn căn cứ. Nếu chỉ tin giọng văn tự tin thì hỏi lại cách kiểm tra.",
        "answers": [],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ việc quen thuộc, em thử nêu câu hỏi.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ mục tiêu hôm nay, em xem một tình huống."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khởi động",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Từ việc quen thuộc, em thử nêu câu hỏi.",
      "number": 3,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "scenario",
      "time": 2,
      "id": "05-04",
      "title": "Mèo ở trên hay ở dưới bàn?",
      "note": {
        "activity": "Khởi động",
        "purpose": "Nhận ra một câu trả lời tự tin vẫn cần kiểm tra.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "AI hỗ trợ đưa gợi ý; người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp.",
        "assessment": "Ghi nhận các em viện dẫn căn cứ. Nếu chỉ tin giọng văn tự tin thì hỏi lại cách kiểm tra.",
        "answers": [
          "AI hỗ trợ đưa gợi ý. Người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ mục tiêu hôm nay, em xem một tình huống.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Câu gốc: The cat is under the table.\n2. Nói dễ hiểu: Bản dịch ví dụ tạo sẵn: Con mèo ở trên bàn.\n3. Điều cần nhớ: Em có đồng ý không?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "AI hỗ trợ đưa gợi ý. Người dùng vẫn cần đối chiếu với kiến thức và nguồn phù hợp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Câu hỏi vừa nêu dẫn em tới cách AI làm việc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Câu gốc: The cat is under the table.",
        "Bản dịch ví dụ tạo sẵn: Con mèo ở trên bàn.",
        "Em có đồng ý không?"
      ],
      "phase": "Khởi động",
      "scene": "cat",
      "taskLines": [
        "Trong 30 giây, em tự chọn câu trả lời tại chỗ."
      ],
      "connector": "Từ mục tiêu hôm nay, em xem một tình huống.",
      "number": 4,
      "v7": true,
      "originalTeachingPoints": [
        "Câu gốc: The cat is under the table.",
        "Bản dịch ví dụ tạo sẵn: Con mèo ở trên bàn.",
        "Em có đồng ý không?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Câu gốc: The cat is under the table.",
          "tone": "key",
          "note": "Thầy/Cô: Câu gốc: The cat is under the table."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Bản dịch ví dụ tạo sẵn: Con mèo ở trên bàn.",
          "tone": "explain",
          "note": "Thầy/Cô: Bản dịch ví dụ tạo sẵn: Con mèo ở trên bàn."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em có đồng ý không?",
          "tone": "action",
          "note": "Thầy/Cô: Em có đồng ý không?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "05-05",
      "title": "Khám phá: chọn nguồn để kiểm",
      "note": {
        "activity": "Khám phá 2.1 Chọn nguồn và tách ý kiểm chứng",
        "purpose": "Xác định hai chi tiết có thể kiểm tra trong kết quả.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa.",
        "assessment": "Đạt khi có hai điểm cụ thể và nguồn tương ứng. Hỗ trợ các em bằng đánh dấu từ khóa.",
        "answers": [],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Trước khi xem, em đọc câu hỏi cần tìm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Câu hỏi vừa nêu dẫn em tới cách AI làm việc.",
      "number": 5,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "type": "question",
      "poster": "frame_6_135.jpg",
      "id": "05-06",
      "title": "Đọc trôi chảy, đã chắc đúng?",
      "note": {
        "activity": "Khám phá 2.1 Chọn nguồn và tách ý kiểm chứng",
        "purpose": "Xác định hai chi tiết có thể kiểm tra trong kết quả.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa.",
        "assessment": "Đạt khi có hai điểm cụ thể và nguồn tương ứng. Hỗ trợ các em bằng đánh dấu từ khóa.",
        "answers": [
          "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Trước khi xem, em đọc câu hỏi cần tìm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Câu trả lời có thể nghe hợp lí.\n2. Nói dễ hiểu: Cần kiểm chi tiết nào và bằng gì?\n3. Điều cần nhớ: Em trả lời bằng ví dụ vừa xem.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Câu trả lời có thể nghe hợp lí.",
        "Cần kiểm chi tiết nào và bằng gì?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 15 giây, em đọc câu hỏi trên slide."
      ],
      "connector": "Trước khi xem, em đọc câu hỏi cần tìm.",
      "number": 6,
      "v7": true,
      "originalTeachingPoints": [
        "Câu trả lời có thể nghe hợp lí.",
        "Cần kiểm chi tiết nào và bằng gì?",
        "Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Câu trả lời có thể nghe hợp lí.",
          "tone": "key",
          "note": "Thầy/Cô: Câu trả lời có thể nghe hợp lí."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Cần kiểm chi tiết nào và bằng gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Cần kiểm chi tiết nào và bằng gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em trả lời bằng ví dụ vừa xem.",
          "tone": "action",
          "note": "Thầy/Cô: Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa."
        }
      ]
    },
    {
      "type": "video",
      "video": {
        "index": 6,
        "title": "AI: How Chatbots and Large Language Models Work",
        "start": 120,
        "end": 150,
        "poster": "frame_6_135.jpg",
        "url": "https://contentful-videos.code.org/90t6bu6vlf76/5PAq7BvRs4dvpeDtdBeciP/df29bc68f49899c2eb16c161b6e4698d/HowAIWorks_LLM_SM_CoBrand__1_.mp4",
        "question": "Vì sao em vẫn cần kiểm câu trả lời?",
        "local": "code-6.mp4"
      },
      "id": "05-07",
      "title": "Vì sao cần kiểm câu trả lời?",
      "note": {
        "activity": "Khám phá 2.1 Chọn nguồn và tách ý kiểm chứng",
        "purpose": "Xác định hai chi tiết có thể kiểm tra trong kết quả.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em xem; tìm câu trả lời.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa.",
        "assessment": "Đạt khi có hai điểm cụ thể và nguồn tương ứng. Hỗ trợ các em bằng đánh dấu từ khóa.",
        "answers": [
          "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
          "explanation": "\nÝ cần giảng rõ: AI tạo câu trả lời thế nào? Vì sao người dùng vẫn phải kiểm?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em xem; tìm câu trả lời.",
          "answer": "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Từ ví dụ vừa có, em đặt tên cho điều đã thấy."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "AI tạo câu trả lời thế nào?",
        "Vì sao người dùng vẫn phải kiểm?"
      ],
      "phase": "Khám phá",
      "scene": "video",
      "taskLines": [
        "Trong 30 giây, em ghi một ví dụ vào vở."
      ],
      "fallback": "AI có thể tạo câu nghe hợp lí nhưng sai chi tiết. Em mở nguồn phù hợp, đối chiếu rồi quyết định.",
      "connector": "Giữ câu hỏi vừa đọc. Em tìm ví dụ trong phim.",
      "number": 7,
      "v7": true,
      "originalTeachingPoints": [
        "AI tạo câu trả lời thế nào?",
        "Vì sao người dùng vẫn phải kiểm?"
      ],
      "pupilTask": "Em xem; tìm câu trả lời."
    },
    {
      "type": "concept",
      "id": "05-08",
      "title": "Chọn chi tiết để kiểm",
      "note": {
        "activity": "Khám phá 2.1 Chọn nguồn và tách ý kiểm chứng",
        "purpose": "Xác định hai chi tiết có thể kiểm tra trong kết quả.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa.",
        "assessment": "Đạt khi có hai điểm cụ thể và nguồn tương ứng. Hỗ trợ các em bằng đánh dấu từ khóa.",
        "answers": [
          "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: AI dịch under thành ở trên trong câu mẫu.\n2. Nói dễ hiểu: Em so nghĩa với bảng từ, thấy phải là ở dưới.\n3. Điều cần nhớ: Em kiểm rồi chọn giữ, sửa hoặc chưa dùng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “ai nói vậy, đã chắc đúng chưa?”."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Xác định điều cần kiểm.",
        "Mở nguồn phù hợp.",
        "Giữ, sửa hoặc chưa dùng."
      ],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 30 giây, em chỉ một ý trên hình."
      ],
      "connector": "Từ ví dụ vừa có, em đặt tên cho điều đã thấy.",
      "number": 8,
      "v7": true,
      "originalTeachingPoints": [
        "Xác định điều cần kiểm.",
        "Mở nguồn phù hợp.",
        "Giữ, sửa hoặc chưa dùng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "AI dịch under thành ở trên trong câu mẫu.",
          "tone": "key",
          "note": "Thầy/Cô: AI dịch under thành ở trên trong câu mẫu."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Em so nghĩa với bảng từ, thấy phải là ở dưới.",
          "tone": "explain",
          "note": "Thầy/Cô: Em so nghĩa với bảng từ, thấy phải là ở dưới."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em kiểm rồi chọn giữ, sửa hoặc chưa dùng.",
          "tone": "action",
          "note": "Thầy/Cô: Em kiểm rồi chọn giữ, sửa hoặc chưa dùng."
        }
      ]
    },
    {
      "id": "05-v7-geo1",
      "type": "guide",
      "title": "AI nói vậy, đã chắc đúng chưa?",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Câu mẫu: Trái Đất đứng thứ tư từ Mặt Trời.",
        "Một chi tiết sai làm câu trả lời sai.",
        "Em cần nguồn khác để kiểm thứ tự."
      ],
      "scene": "geo",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "2³ = 8",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Câu mẫu: Trái Đất đứng thứ tư từ Mặt Trời. / Một chi tiết sai làm câu trả lời sai. / Em cần nguồn khác để kiểm thứ tự."
        ],
        "source": "Ví dụ Địa lí 6 tự biên soạn. Nguồn kiểm: NASA, About the Planets, mục Earth Facts: https://science.nasa.gov/solar-system/planets/. Không trích nguyên văn SGK Địa lí vì chưa có bản SGK đó để đối chiếu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: AI nói vậy, đã chắc đúng chưa?.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Câu mẫu: Trái Đất đứng thứ tư từ Mặt Trời.\n2. Nói dễ hiểu: Một chi tiết sai làm câu trả lời sai.\n3. Điều cần nhớ: Em cần nguồn khác để kiểm thứ tự.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Câu mẫu: Trái Đất đứng thứ tư từ Mặt Trời. / Một chi tiết sai làm câu trả lời sai. / Em cần nguồn khác để kiểm thứ tự.",
          "closing": "Thầy/Cô chốt: Em cần nguồn khác để kiểm thứ tự.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “mở nguồn để kiểm đúng chi tiết”."
        }
      },
      "number": 9,
      "originalTeachingPoints": [
        "Câu mẫu: Trái Đất đứng thứ tư từ Mặt Trời.",
        "Một chi tiết sai làm câu trả lời sai.",
        "Em cần nguồn khác để kiểm thứ tự."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Câu mẫu: Trái Đất đứng thứ tư từ Mặt Trời.",
          "tone": "error",
          "note": "Thầy/Cô: Câu mẫu: Trái Đất đứng thứ tư từ Mặt Trời."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Một chi tiết sai làm câu trả lời sai.",
          "tone": "explain",
          "note": "Thầy/Cô: Một chi tiết sai làm câu trả lời sai."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em cần nguồn khác để kiểm thứ tự.",
          "tone": "action",
          "note": "Thầy/Cô: Em cần nguồn khác để kiểm thứ tự."
        }
      ]
    },
    {
      "id": "05-v7-geo2",
      "type": "guide",
      "title": "Mở nguồn để kiểm đúng chi tiết",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Câu mẫu ghi thứ tư; NASA ghi thứ ba.",
        "Đọc mục Earth trong trang About the Planets.",
        "Sửa thứ tư thành thứ ba."
      ],
      "scene": "geo",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "2³ = 8",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Câu mẫu ghi thứ tư; NASA ghi thứ ba. / Đọc mục Earth trong trang About the Planets. / Sửa thứ tư thành thứ ba."
        ],
        "source": "Ví dụ Địa lí 6 tự biên soạn. Nguồn kiểm: NASA, About the Planets, mục Earth Facts: https://science.nasa.gov/solar-system/planets/. Không trích nguyên văn SGK Địa lí vì chưa có bản SGK đó để đối chiếu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Mở nguồn để kiểm đúng chi tiết.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Câu mẫu ghi thứ tư; NASA ghi thứ ba.\n2. Nói dễ hiểu: Đọc mục Earth trong trang About the Planets.\n3. Điều cần nhớ: Sửa thứ tư thành thứ ba.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Câu mẫu ghi thứ tư; NASA ghi thứ ba. / Đọc mục Earth trong trang About the Planets. / Sửa thứ tư thành thứ ba.",
          "closing": "Thầy/Cô chốt: Sửa thứ tư thành thứ ba.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để tiếp tục với “ghi lại cách em sửa câu sai”."
        }
      },
      "sourceURL": "https://science.nasa.gov/solar-system/planets/",
      "number": 10,
      "originalTeachingPoints": [
        "Câu mẫu ghi thứ tư; NASA ghi thứ ba.",
        "Đọc mục Earth trong trang About the Planets.",
        "Sửa thứ tư thành thứ ba."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Câu mẫu ghi thứ tư; NASA ghi thứ ba.",
          "tone": "key",
          "note": "Thầy/Cô: Câu mẫu ghi thứ tư; NASA ghi thứ ba."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Đọc mục Earth trong trang About the Planets.",
          "tone": "explain",
          "note": "Thầy/Cô: Đọc mục Earth trong trang About the Planets."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Sửa thứ tư thành thứ ba.",
          "tone": "key",
          "note": "Thầy/Cô: Sửa thứ tư thành thứ ba."
        }
      ]
    },
    {
      "id": "05-v7-geo3",
      "type": "guide",
      "title": "Ghi lại cách em sửa câu sai",
      "theme": "cream",
      "v6": true,
      "v7": true,
      "phase": "Khám phá",
      "screen": [
        "Em điền điều đã đọc, không chỉ ghi Sai.",
        "Nguồn phải cho biết đúng chi tiết cần kiểm.",
        "Chỉ dùng câu sau khi đã sửa."
      ],
      "scene": "geo",
      "taskLines": [
        "Em quan sát; trả lời trong 30 giây."
      ],
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "2³ = 8",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Em điền điều đã đọc, không chỉ ghi Sai. / Nguồn phải cho biết đúng chi tiết cần kiểm. / Chỉ dùng câu sau khi đã sửa."
        ],
        "source": "Ví dụ Địa lí 6 tự biên soạn. Nguồn kiểm: NASA, About the Planets, mục Earth Facts: https://science.nasa.gov/solar-system/planets/. Không trích nguyên văn SGK Địa lí vì chưa có bản SGK đó để đối chiếu.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Ghi lại cách em sửa câu sai.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em điền điều đã đọc, không chỉ ghi Sai.\n2. Nói dễ hiểu: Nguồn phải cho biết đúng chi tiết cần kiểm.\n3. Điều cần nhớ: Chỉ dùng câu sau khi đã sửa.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Em điền điều đã đọc, không chỉ ghi Sai. / Nguồn phải cho biết đúng chi tiết cần kiểm. / Chỉ dùng câu sau khi đã sửa.",
          "closing": "Thầy/Cô chốt: Chỉ dùng câu sau khi đã sửa.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "guideTable": {
        "headers": [
          "AI nói gì?",
          "Nguồn cho biết",
          "Em quyết định"
        ],
        "rows": [
          [
            "Thứ tư (câu mẫu sai)",
            "NASA: thứ ba",
            "Sửa thành thứ ba"
          ]
        ],
        "label": "Câu sai tạo sẵn; NASA là nguồn đối chiếu."
      },
      "guideQuestion": "Em sẽ điền ô cuối thế nào?",
      "number": 11,
      "originalTeachingPoints": [
        "Em điền điều đã đọc, không chỉ ghi Sai.",
        "Nguồn phải cho biết đúng chi tiết cần kiểm.",
        "Chỉ dùng câu sau khi đã sửa."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em điền điều đã đọc, không chỉ ghi Sai.",
          "tone": "key",
          "note": "Thầy/Cô: Em điền điều đã đọc, không chỉ ghi Sai."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nguồn phải cho biết đúng chi tiết cần kiểm.",
          "tone": "explain",
          "note": "Thầy/Cô: Nguồn phải cho biết đúng chi tiết cần kiểm."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chỉ dùng câu sau khi đã sửa.",
          "tone": "action",
          "note": "Thầy/Cô: Chỉ dùng câu sau khi đã sửa."
        }
      ]
    },
    {
      "id": "05-09-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu kiểm một câu AI nói sai",
      "theme": "cream",
      "phase": "Khám phá",
      "scene": "math-error",
      "worked": {
        "title": "Mẫu kiểm một câu AI nói sai",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Chi tiết cần kiểm",
          "Nguồn dùng kiểm",
          "Điều nguồn cho biết",
          "Quyết định",
          "Bản sẽ dùng"
        ],
        "values": [
          "Kết quả của 2³",
          "Quy tắc lũy thừa đã học",
          "2³ = 2 × 2 × 2 = 8",
          "Sửa kết quả 6",
          "2³ = 8"
        ],
        "why": [
          "Kiểm một chi tiết rõ ràng trước.",
          "Phép tính cho căn cứ độc lập.",
          "Giữ câu sai để thấy em sửa gì."
        ],
        "question": "Ô bản sẽ dùng cần viết kết quả nào?",
        "scene": "Math-error"
      },
      "targetId": "05-09",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "2³ = 8",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Chi tiết cần kiểm: Kết quả của 2³\nNguồn dùng kiểm: Quy tắc lũy thừa đã học\nĐiều nguồn cho biết: 2³ = 2 × 2 × 2 = 8\nQuyết định: Sửa kết quả 6\nBản sẽ dùng: 2³ = 8"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Câu mẫu sai: 2³ = 6.\n2. Nói dễ hiểu: 2³ là 2 nhân 2 nhân 2, bằng 8.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Chi tiết cần kiểm: Kết quả của 2³\nNguồn dùng kiểm: Quy tắc lũy thừa đã học\nĐiều nguồn cho biết: 2³ = 2 × 2 × 2 = 8\nQuyết định: Sửa kết quả 6\nBản sẽ dùng: 2³ = 8",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 12,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Câu mẫu sai: 2³ = 6.",
          "tone": "key",
          "note": "Thầy/Cô: Câu mẫu sai: 2³ = 6."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "2³ là 2 nhân 2 nhân 2, bằng 8.",
          "tone": "explain",
          "note": "Thầy/Cô: 2³ là 2 nhân 2 nhân 2, bằng 8."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Ô bản sẽ dùng cần viết kết quả nào? Gợi ý: 2³ = 8"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P5.1 Nguồn đối chiếu và bản dịch ví dụ tạo sẵn",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "School bag đối chiếu với nghĩa cặp sách. Under đối chiếu với nghĩa ở dưới.",
          "Bảng từ kiểm được những nghĩa/chi tiết có trong bảng. Không chứng minh công cụ luôn dịch đúng mọi câu. Đây là nguồn Thầy/Cô biên soạn, không gán tên/trang SGK chưa dùng."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Câu 1: This is a school bag. → Đây là cặp sách.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Câu 2: The cat is under the table. → Con mèo ở trên bàn.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Bảng từ: school bag = cặp sách; cat = mèo; under = ở dưới; table = bàn.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Chọn chi tiết và nguồn để kiểm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "School bag: em xem phần nào của bảng từ?",
                "key": "05-09-v4-source1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn chi tiết và nguồn để kiểm",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Under: em xem phần nào của bảng từ?",
                "key": "05-09-v4-source2"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 5,
      "id": "05-09",
      "title": "P5.1 — Nguồn nào kiểm được?",
      "note": {
        "activity": "Khám phá 2.1 Chọn nguồn và tách ý kiểm chứng",
        "purpose": "Hoàn thành chọn nguồn đối chiếu theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "School bag đối chiếu với nghĩa cặp sách. Under đối chiếu với nghĩa ở dưới.",
          "Bảng từ kiểm được những nghĩa/chi tiết có trong bảng. Không chứng minh công cụ luôn dịch đúng mọi câu. Đây là nguồn Thầy/Cô biên soạn, không gán tên/trang SGK chưa dùng."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: School bag chỉ đồ vật gì? Under chỉ vị trí nào?\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "School bag đối chiếu với nghĩa cặp sách. Under đối chiếu với nghĩa ở dưới.\nBảng từ kiểm được những nghĩa/chi tiết có trong bảng. Không chứng minh công cụ luôn dịch đúng mọi câu. Đây là nguồn Thầy/Cô biên soạn, không gán tên/trang SGK chưa dùng.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em so kết quả để rút ra điều có căn cứ."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "School bag chỉ đồ vật gì?",
        "Under chỉ vị trí nào?"
      ],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "05-09-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 13,
      "v7": true,
      "originalTeachingPoints": [
        "School bag chỉ đồ vật gì?",
        "Under chỉ vị trí nào?"
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P5.1 · Tìm chi tiết sai"
    },
    {
      "type": "conclusion",
      "id": "05-10",
      "title": "Kiểm bằng nguồn phù hợp",
      "note": {
        "activity": "Khám phá 2.1 Chọn nguồn và tách ý kiểm chứng",
        "purpose": "Xác định hai chi tiết có thể kiểm tra trong kết quả.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Kiểm chứng cần nguồn độc lập, phù hợp đúng điều đang kiểm tra; không phải chỉ hỏi AI lần nữa.",
        "assessment": "Đạt khi có hai điểm cụ thể và nguồn tương ứng. Hỗ trợ các em bằng đánh dấu từ khóa.",
        "answers": [
          "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em so kết quả để rút ra điều có căn cứ.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Bảng từ giúp kiểm nghĩa từ.\n2. Nói dễ hiểu: Hỏi AI lần nữa chưa đủ xác nhận.\n3. Điều cần nhớ: Chưa chắc thì hỏi Thầy/Cô.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Kiểm tra cần nguồn độc lập, phù hợp đúng điều đang kiểm tra. Không phải chỉ hỏi AI lần nữa.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã xem ví dụ. Giờ em thử theo từng bước."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Bảng từ giúp kiểm nghĩa từ.",
        "Hỏi AI lần nữa chưa đủ xác nhận.",
        "Chưa chắc thì hỏi Thầy/Cô."
      ],
      "phase": "Khám phá",
      "scene": "translate",
      "taskLines": [
        "Trong 30 giây, em nêu một căn cứ tại chỗ."
      ],
      "connector": "Em so kết quả để rút ra điều có căn cứ.",
      "number": 14,
      "v7": true,
      "originalTeachingPoints": [
        "Bảng từ giúp kiểm nghĩa từ.",
        "Hỏi AI lần nữa chưa đủ xác nhận.",
        "Chưa chắc thì hỏi Thầy/Cô."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Bảng từ giúp kiểm nghĩa từ.",
          "tone": "key",
          "note": "Thầy/Cô: Bảng từ giúp kiểm nghĩa từ."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Hỏi AI lần nữa chưa đủ xác nhận.",
          "tone": "explain",
          "note": "Thầy/Cô: Hỏi AI lần nữa chưa đủ xác nhận."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Chưa chắc thì hỏi Thầy/Cô.",
          "tone": "action",
          "note": "Thầy/Cô: Chưa chắc thì hỏi Thầy/Cô."
        }
      ]
    },
    {
      "type": "divider",
      "id": "05-11",
      "title": "Thực hành: ghi, kiểm, quyết định",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm và quyết định",
        "purpose": "Thực hiện đủ bước hỏi, ghi, đối chiếu, quyết định.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung mình dùng để học hoặc chia sẻ.",
        "assessment": "Kiểm tra bảng có kết quả, nguồn và quyết định. Không đánh giá theo việc các em có phát hiện lỗi thật hay không.",
        "answers": [],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem ví dụ. Giờ em thử theo từng bước.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em đã xem ví dụ. Giờ em thử theo từng bước.",
      "number": 15,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "05-12-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu đọc trước khi dùng bản dịch",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "cat",
      "worked": {
        "title": "Mẫu đọc trước khi dùng bản dịch",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Câu gốc",
          "Bản dịch gốc",
          "Nguồn kiểm",
          "Quyết định",
          "Bản cuối"
        ],
        "values": [
          "The cat is under the table.",
          "Con mèo ở trên bàn.",
          "Bảng từ: under = ở dưới",
          "Sửa từ ở trên",
          "Con mèo ở dưới bàn."
        ],
        "why": [
          "Giữ nguyên bản gốc để thấy lỗi.",
          "Bảng từ kiểm đúng nghĩa cần hỏi.",
          "Chỉ sửa sau khi có căn cứ."
        ],
        "question": "Bản cuối cần đổi vị trí nào?",
        "scene": "Cat"
      },
      "targetId": "05-12",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Con mèo ở dưới bàn.",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Câu gốc: The cat is under the table.\nBản dịch gốc: Con mèo ở trên bàn.\nNguồn kiểm: Bảng từ: under = ở dưới\nQuyết định: Sửa từ ở trên\nBản cuối: Con mèo ở dưới bàn."
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Under bị dịch sai thành ở trên.\n2. Nói dễ hiểu: Under chỉ vị trí ở dưới, không phải ở trên.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Câu gốc: The cat is under the table.\nBản dịch gốc: Con mèo ở trên bàn.\nNguồn kiểm: Bảng từ: under = ở dưới\nQuyết định: Sửa từ ở trên\nBản cuối: Con mèo ở dưới bàn.",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 16,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Under bị dịch sai thành ở trên.",
          "tone": "key",
          "note": "Thầy/Cô: Under bị dịch sai thành ở trên."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Under chỉ vị trí ở dưới, không phải ở trên.",
          "tone": "explain",
          "note": "Thầy/Cô: Under chỉ vị trí ở dưới, không phải ở trên."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Bản cuối cần đổi vị trí nào? Gợi ý: Con mèo ở dưới bàn."
        }
      ]
    },
    {
      "type": "task",
      "id": "05-12",
      "title": "Ghi gốc, kiểm rồi quyết định",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm và quyết định",
        "purpose": "Thực hiện đủ bước hỏi, ghi, đối chiếu, quyết định.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung mình dùng để học hoặc chia sẻ.",
        "assessment": "Kiểm tra bảng có kết quả, nguồn và quyết định. Không đánh giá theo việc các em có phát hiện lỗi thật hay không.",
        "answers": [
          "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung em dùng để học hoặc chia sẻ."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dịch hai câu mẫu.\n2. Nói dễ hiểu: Ghi nguyên kết quả ở P5.2.\n3. Điều cần nhớ: Kiểm nguồn rồi nêu quyết định.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung em dùng để học hoặc chia sẻ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em bắt đầu bằng việc giữ nguyên bản dịch gốc."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Dịch hai câu mẫu.",
        "Ghi nguyên kết quả ở P5.2.",
        "Kiểm nguồn rồi nêu quyết định."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 11 phút, em dịch và kiểm hai câu trên máy."
      ],
      "sampleId": "05-12-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 17,
      "v7": true,
      "originalTeachingPoints": [
        "Dịch hai câu mẫu.",
        "Ghi nguyên kết quả ở P5.2.",
        "Kiểm nguồn rồi nêu quyết định."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dịch hai câu mẫu.",
          "tone": "key",
          "note": "Thầy/Cô: Dịch hai câu mẫu."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi nguyên kết quả ở P5.2.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi nguyên kết quả ở P5.2."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Kiểm nguồn rồi nêu quyết định.",
          "tone": "action",
          "note": "Thầy/Cô: Kiểm nguồn rồi nêu quyết định."
        }
      ]
    },
    {
      "type": "step",
      "step": 1,
      "time": 0,
      "id": "05-13",
      "title": "Bước 1 — Giữ bản dịch gốc",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm và quyết định",
        "purpose": "Thực hiện đủ bước hỏi, ghi, đối chiếu, quyết định.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung mình dùng để học hoặc chia sẻ.",
        "assessment": "Kiểm tra bảng có kết quả, nguồn và quyết định. Không đánh giá theo việc các em có phát hiện lỗi thật hay không.",
        "answers": [
          "Ghi theo công cụ thực tế. Nếu cả hai câu đúng, giữ có căn cứ vẫn đạt. Nếu dùng mô phỏng P5.1, phải đánh dấu và sửa nghĩa under.",
          "Mỗi dòng cần kết quả, nguồn và quyết định. Đánh giá năng lực kiểm tra, không coi phát hiện lỗi là yêu cầu bắt buộc cho mọi nhóm."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em bắt đầu bằng việc giữ nguyên bản dịch gốc.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Dịch từng câu Anh → Việt.\n2. Nói dễ hiểu: Ghi nguyên kết quả.\n3. Điều cần nhớ: Đánh dấu cách nhận kết quả.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ghi theo công cụ thực tế. Nếu cả hai câu đúng, giữ có căn cứ vẫn đạt. Nếu dùng mô phỏng P5.1, phải đánh dấu và sửa nghĩa under.\nMỗi dòng cần kết quả, nguồn và quyết định. Đánh giá năng lực kiểm tra, không coi phát hiện lỗi là yêu cầu bắt buộc cho mọi nhóm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Có bản gốc rồi, em kiểm để chọn bản sẽ dùng."
        }
      },
      "theme": "cream",
      "recordTarget": "05-17",
      "recordPage": 2,
      "v6": true,
      "screen": [
        "Dịch từng câu Anh → Việt.",
        "Ghi nguyên kết quả.",
        "Đánh dấu cách nhận kết quả."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cat",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Em bắt đầu bằng việc giữ nguyên bản dịch gốc.",
      "number": 18,
      "v7": true,
      "originalTeachingPoints": [
        "Dịch từng câu Anh → Việt.",
        "Ghi nguyên kết quả.",
        "Đánh dấu cách nhận kết quả."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Dịch từng câu Anh → Việt.",
          "tone": "key",
          "note": "Thầy/Cô: Dịch từng câu Anh → Việt."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Ghi nguyên kết quả.",
          "tone": "explain",
          "note": "Thầy/Cô: Ghi nguyên kết quả."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Đánh dấu cách nhận kết quả.",
          "tone": "action",
          "note": "Thầy/Cô: Đánh dấu cách nhận kết quả."
        }
      ]
    },
    {
      "type": "step",
      "step": 2,
      "time": 0,
      "id": "05-15",
      "title": "Bước 2 — Kiểm và chọn cách xử lí",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm và quyết định",
        "purpose": "Thực hiện đủ bước hỏi, ghi, đối chiếu, quyết định.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung mình dùng để học hoặc chia sẻ.",
        "assessment": "Kiểm tra bảng có kết quả, nguồn và quyết định. Không đánh giá theo việc các em có phát hiện lỗi thật hay không.",
        "answers": [
          "Ghi theo công cụ thực tế. Nếu cả hai câu đúng, giữ có căn cứ vẫn đạt. Nếu dùng mô phỏng P5.1, phải đánh dấu và sửa nghĩa under.",
          "Mỗi dòng cần kết quả, nguồn và quyết định. Đánh giá năng lực kiểm tra, không coi phát hiện lỗi là yêu cầu bắt buộc cho mọi nhóm."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Có bản gốc rồi, em kiểm để chọn bản sẽ dùng.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Đối chiếu school bag và under.\n2. Nói dễ hiểu: Giữ / sửa / chưa dùng.\n3. Điều cần nhớ: Ghi bản cuối hoặc lí do chưa dùng.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Ghi theo công cụ thực tế. Nếu cả hai câu đúng, giữ có căn cứ vẫn đạt. Nếu dùng mô phỏng P5.1, phải đánh dấu và sửa nghĩa under.\nMỗi dòng cần kết quả, nguồn và quyết định. Đánh giá năng lực kiểm tra, không coi phát hiện lỗi là yêu cầu bắt buộc cho mọi nhóm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "cream",
      "recordTarget": "05-17",
      "recordPage": 2,
      "publicComparison": true,
      "v6": true,
      "screen": [
        "Đối chiếu school bag và under.",
        "Giữ / sửa / chưa dùng.",
        "Ghi bản cuối hoặc lí do chưa dùng."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "cat",
      "taskLines": [
        "Trong 1 phút, em làm bước này trên máy."
      ],
      "connector": "Có bản gốc rồi, em kiểm để chọn bản sẽ dùng.",
      "number": 19,
      "v7": true,
      "originalTeachingPoints": [
        "Đối chiếu school bag và under.",
        "Giữ / sửa / chưa dùng.",
        "Ghi bản cuối hoặc lí do chưa dùng."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Đối chiếu school bag và under.",
          "tone": "key",
          "note": "Thầy/Cô: Đối chiếu school bag và under."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Giữ / sửa / chưa dùng.",
          "tone": "explain",
          "note": "Thầy/Cô: Giữ / sửa / chưa dùng."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Ghi bản cuối hoặc lí do chưa dùng.",
          "tone": "action",
          "note": "Thầy/Cô: Ghi bản cuối hoặc lí do chưa dùng."
        }
      ]
    },
    {
      "id": "05-17-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu ghi quyết định trong bảng",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "worked": {
        "title": "Mẫu ghi quyết định trong bảng",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Cách nhận kết quả",
          "Kết quả gốc",
          "Nguồn kiểm",
          "Quyết định",
          "Lí do"
        ],
        "values": [
          "Đọc bản dịch mẫu tạo sẵn",
          "School bag → cặp sách",
          "Bảng từ: school bag = cặp sách",
          "Giữ nguyên",
          "Bản dịch khớp nghĩa trong bảng từ"
        ],
        "why": [
          "Không gọi đọc mẫu là đã chạy công cụ.",
          "Bản đúng cũng cần căn cứ kiểm.",
          "Không bắt buộc phải tìm ra lỗi."
        ],
        "question": "Vì sao em có thể giữ nguyên bản này?",
        "scene": "Translate"
      },
      "targetId": "05-17",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Bản dịch khớp nghĩa trong bảng từ",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Cách nhận kết quả: Đọc bản dịch mẫu tạo sẵn\nKết quả gốc: School bag → cặp sách\nNguồn kiểm: Bảng từ: school bag = cặp sách\nQuyết định: Giữ nguyên\nLí do: Bản dịch khớp nghĩa trong bảng từ"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: School bag được dịch thành cặp sách.\n2. Nói dễ hiểu: Nghĩa trong bảng từ khớp với bản dịch mẫu.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Cách nhận kết quả: Đọc bản dịch mẫu tạo sẵn\nKết quả gốc: School bag → cặp sách\nNguồn kiểm: Bảng từ: school bag = cặp sách\nQuyết định: Giữ nguyên\nLí do: Bản dịch khớp nghĩa trong bảng từ",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 20,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "School bag được dịch thành cặp sách.",
          "tone": "key",
          "note": "Thầy/Cô: School bag được dịch thành cặp sách."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nghĩa trong bảng từ khớp với bản dịch mẫu.",
          "tone": "explain",
          "note": "Thầy/Cô: Nghĩa trong bảng từ khớp với bản dịch mẫu."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Vì sao em có thể giữ nguyên bản này? Gợi ý: Bản dịch khớp nghĩa trong bảng từ"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P5.2 bảng ghi kiểm tra",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "Ghi theo công cụ thực tế. Nếu cả hai câu đúng, giữ có căn cứ vẫn đạt. Nếu dùng mô phỏng P5.1, phải đánh dấu và sửa nghĩa under.",
          "Mỗi dòng cần kết quả, nguồn và quyết định. Đánh giá năng lực kiểm tra, không coi phát hiện lỗi là yêu cầu bắt buộc cho mọi nhóm."
        ],
        "pages": [
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "Dùng lại hai câu tiết 1. Ghi nguồn kiểm và quyết định giữ, sửa hoặc chưa dùng.",
            "originalPage": 0,
            "referenceOnly": true
          },
          {
            "title": "Xác nhận hình thức thực hiện",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đã nhận kết quả bằng cách nào?",
                "key": "05-17-v4-mode",
                "options": [
                  "Tự thao tác công cụ",
                  "Quan sát GV thực hiện",
                  "Dùng bản dịch giả định P5.1"
                ],
                "optionLabels": [
                  "Tự thao tác công cụ",
                  "Quan sát Thầy/Cô thực hiện",
                  "Dùng bản dịch ví dụ tạo sẵn P5.1"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "This is a school bag.",
            "originalPage": 1,
            "referenceOnly": true
          },
          {
            "title": "Kiểm tra câu 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Công cụ đã dịch thành câu nào?",
                "key": "05-17-v3-0"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Kiểm tra câu 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đối chiếu từ nào và bằng nguồn nào?",
                "key": "05-17-v3-1"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Kiểm tra câu 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn cách xử lí nào?",
                "options": [
                  "Giữ kết quả",
                  "Sửa kết quả",
                  "Chưa sử dụng"
                ],
                "key": "05-17-v3-2",
                "optionLabels": [
                  "Giữ kết quả",
                  "Sửa kết quả",
                  "Chưa sử dụng"
                ]
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Kiểm tra câu 1",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Bản em sẽ dùng sau kiểm tra, hoặc lí do chưa dùng",
                "key": "05-17-v3-3"
              }
            ],
            "originalPage": 1
          },
          {
            "title": "Đọc thông tin trước khi làm",
            "instruction": "Em đọc; nhấn Tiếp để làm.",
            "reference": "The cat is under the table.",
            "originalPage": 2,
            "referenceOnly": true
          },
          {
            "title": "Kiểm tra câu 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Công cụ đã dịch thành câu nào?",
                "key": "05-17-v3-4"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Kiểm tra câu 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em đối chiếu từ nào và bằng nguồn nào?",
                "key": "05-17-v3-5"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Kiểm tra câu 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em chọn cách xử lí nào?",
                "options": [
                  "Giữ kết quả",
                  "Sửa kết quả",
                  "Chưa sử dụng"
                ],
                "key": "05-17-v3-6",
                "optionLabels": [
                  "Giữ kết quả",
                  "Sửa kết quả",
                  "Chưa sử dụng"
                ]
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Kiểm tra câu 2",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Bản em sẽ dùng sau kiểm tra, hoặc lí do chưa dùng",
                "key": "05-17-v3-7"
              }
            ],
            "originalPage": 2
          },
          {
            "title": "Quyết định của riêng em",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ dùng hoặc chưa dùng kết quả nào? Vì sao?",
                "key": "05-17-v3-8"
              }
            ],
            "originalPage": 3
          },
          {
            "title": "Quyết định của riêng em",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Khi chưa chắc, em sẽ hỏi ai hoặc xem nguồn nào?",
                "key": "05-17-v3-9"
              }
            ],
            "originalPage": 3
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2,
          "2": 7,
          "3": 12
        }
      },
      "time": 16,
      "id": "05-17",
      "title": "P5.2 — bảng ghi kiểm tra bản dịch",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm và quyết định",
        "purpose": "Hoàn thành nhật kí kiểm chứng theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung mình dùng để học hoặc chia sẻ.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "Ghi theo công cụ thực tế. Nếu cả hai câu đúng, giữ có căn cứ vẫn đạt. Nếu dùng mô phỏng P5.1, phải đánh dấu và sửa nghĩa under.",
          "Mỗi dòng cần kết quả, nguồn và quyết định. Đánh giá năng lực kiểm tra, không coi phát hiện lỗi là yêu cầu bắt buộc cho mọi nhóm."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "Giữ bản gốc ở ô riêng để nhìn thấy đã sửa gì. Bản cuối có thể là giữ nguyên, bản sửa hoặc lí do chưa dùng. Không bắt mọi nhóm phải tìm được lỗi.\nÝ cần giảng rõ: Ghi cách nhận kết quả. Giữ bản gốc, nguồn và quyết định. Viết bản cuối ở ô riêng.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "Ghi theo công cụ thực tế. Nếu cả hai câu đúng, giữ có căn cứ vẫn đạt. Nếu dùng mô phỏng P5.1, phải đánh dấu và sửa nghĩa under.\nMỗi dòng cần kết quả, nguồn và quyết định. Đánh giá năng lực kiểm tra, không coi phát hiện lỗi là yêu cầu bắt buộc cho mọi nhóm.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi cách nhận kết quả.",
        "Giữ bản gốc, nguồn và quyết định.",
        "Viết bản cuối ở ô riêng."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "05-17-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 21,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi cách nhận kết quả.",
        "Giữ bản gốc, nguồn và quyết định.",
        "Viết bản cuối ở ô riêng."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P5.2 · Kiểm bản dịch"
    },
    {
      "type": "report",
      "id": "05-18",
      "title": "Em quyết định dựa vào đâu?",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm và quyết định",
        "purpose": "Thực hiện đủ bước hỏi, ghi, đối chiếu, quyết định.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung mình dùng để học hoặc chia sẻ.",
        "assessment": "Kiểm tra bảng có kết quả, nguồn và quyết định. Không đánh giá theo việc các em có phát hiện lỗi thật hay không.",
        "answers": [
          "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung em dùng để học hoặc chia sẻ."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Kết quả gốc là gì?\n2. Nói dễ hiểu: Nguồn cho biết điều gì?\n3. Điều cần nhớ: Em chọn cách xử lí nào?",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung em dùng để học hoặc chia sẻ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng kết quả vừa có để tự kiểm cách hiểu."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Kết quả gốc là gì?",
        "Nguồn cho biết điều gì?",
        "Em chọn cách xử lí nào?"
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 30 giây, em kể một kết quả tại chỗ."
      ],
      "connector": "Em đã có bảng ghi. Em dùng bảng để giải thích kết quả.",
      "number": 22,
      "v7": true,
      "originalTeachingPoints": [
        "Kết quả gốc là gì?",
        "Nguồn cho biết điều gì?",
        "Em chọn cách xử lí nào?"
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Kết quả gốc là gì?",
          "tone": "key",
          "note": "Thầy/Cô: Kết quả gốc là gì?"
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nguồn cho biết điều gì?",
          "tone": "explain",
          "note": "Thầy/Cô: Nguồn cho biết điều gì?"
        },
        {
          "label": "Điều cần nhớ",
          "text": "Em chọn cách xử lí nào?",
          "tone": "action",
          "note": "Thầy/Cô: Em chọn cách xử lí nào?"
        }
      ]
    },
    {
      "type": "divider",
      "id": "05-20",
      "title": "Luyện tập: kiểm có căn cứ",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Nhận ra cách kiểm chứng có và không có căn cứ.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đồng thuận giữa các câu trả lời AI không thay thế bằng chứng từ nguồn phù hợp.",
        "assessment": "Đạt khi chọn đúng nguồn và không sao chép kết quả chưa kiểm tra.",
        "answers": [],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng kết quả vừa có để tự kiểm cách hiểu.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng kết quả vừa có để tự kiểm cách hiểu.",
      "number": 23,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "05-21-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu chọn nguồn để kiểm",
      "theme": "cream",
      "phase": "Luyện tập / Thực hành",
      "scene": "math-error",
      "worked": {
        "title": "Mẫu chọn nguồn để kiểm",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Điều cần kiểm",
          "Hai lời giống nhau",
          "Nguồn phù hợp",
          "Căn cứ",
          "Quyết định"
        ],
        "values": [
          "Giá trị của 2³",
          "Chưa chứng minh đúng",
          "Quy tắc lũy thừa đã học",
          "2 × 2 × 2 = 8",
          "Sửa thành 8, ghi cách kiểm"
        ],
        "why": [
          "Số lần được nhắc không thay căn cứ.",
          "Nguồn phải đúng phần cần hỏi.",
          "Em chỉ ra được phép tính."
        ],
        "question": "Em sẽ giữ hay sửa câu trả lời?",
        "scene": "Math-error"
      },
      "targetId": "05-21",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Sửa thành 8, ghi cách kiểm",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Điều cần kiểm: Giá trị của 2³\nHai lời giống nhau: Chưa chứng minh đúng\nNguồn phù hợp: Quy tắc lũy thừa đã học\nCăn cứ: 2 × 2 × 2 = 8\nQuyết định: Sửa thành 8, ghi cách kiểm"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Hai AI cùng nói 2³ = 6 (câu mẫu sai).\n2. Nói dễ hiểu: Hai lời giống nhau vẫn có thể cùng sai.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Điều cần kiểm: Giá trị của 2³\nHai lời giống nhau: Chưa chứng minh đúng\nNguồn phù hợp: Quy tắc lũy thừa đã học\nCăn cứ: 2 × 2 × 2 = 8\nQuyết định: Sửa thành 8, ghi cách kiểm",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 24,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Hai AI cùng nói 2³ = 6 (câu mẫu sai).",
          "tone": "key",
          "note": "Thầy/Cô: Hai AI cùng nói 2³ = 6 (câu mẫu sai)."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Hai lời giống nhau vẫn có thể cùng sai.",
          "tone": "explain",
          "note": "Thầy/Cô: Hai lời giống nhau vẫn có thể cùng sai."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em sẽ giữ hay sửa câu trả lời? Gợi ý: Sửa thành 8, ghi cách kiểm"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P5.3 Dùng AI để học",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "A1 C. A2 Cần kiểm tra nội dung dù diễn đạt tự tin. A3 Chưa đủ. Hai công cụ có thể cùng sai, cần nguồn phù hợp."
        ],
        "pages": [
          {
            "title": "Chọn cách kiểm tra",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Kiểm tra bản dịch bằng cách nào?",
                "options": [
                  "A. Tin vì câu trả lời dài",
                  "B. Hỏi lại hai lần",
                  "C. Đối chiếu với bảng từ phù hợp",
                  "D. Sao chép ngay"
                ],
                "key": "05-21-v3-0",
                "optionLabels": [
                  "A. Tin vì câu trả lời dài",
                  "B. Hỏi lại hai lần",
                  "C. Đối chiếu với bảng từ phù hợp",
                  "D. Sao chép ngay"
                ]
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Chọn cách kiểm tra",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "“AI trả lời rất chắc chắn nên không cần kiểm tra.” Em sửa thế nào?",
                "key": "05-21-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Hai câu trả lời giống nhau",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Hai công cụ trả lời giống nhau có đủ chứng minh là đúng không? Em kiểm tra tiếp bằng gì?",
                "key": "05-21-v3-2"
              }
            ],
            "originalPage": 1
          }
        ],
        "v7PageMap": {
          "0": 0,
          "1": 2
        }
      },
      "time": 4,
      "id": "05-21",
      "title": "P5.3A — Chọn cách kiểm tốt hơn",
      "note": {
        "activity": "Luyện tập cá nhân",
        "purpose": "Hoàn thành kiểm tra có căn cứ theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Đồng thuận giữa các câu trả lời AI không thay thế bằng chứng từ nguồn phù hợp.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "A1 C. A2 Cần kiểm tra nội dung dù diễn đạt tự tin. A3 Chưa đủ. Hai công cụ có thể cùng sai, cần nguồn phù hợp."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Chọn nguồn khớp nội dung. Hai câu giống nhau chưa chứng minh đúng. Nêu lí do cho lựa chọn.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "A1 C. A2 Cần kiểm tra nội dung dù diễn đạt tự tin. A3 Chưa đủ. Hai công cụ có thể cùng sai, cần nguồn phù hợp.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Những việc vừa làm giúp em rút ra ba ý."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn nguồn khớp nội dung.",
        "Hai câu giống nhau chưa chứng minh đúng.",
        "Nêu lí do cho lựa chọn."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "05-21-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 25,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn nguồn khớp nội dung.",
        "Hai câu giống nhau chưa chứng minh đúng.",
        "Nêu lí do cho lựa chọn."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P5.3A · Em tự làm"
    },
    {
      "type": "recap",
      "id": "05-19",
      "title": "Kiến thức cần nhớ",
      "note": {
        "activity": "Khám phá 2.2 Trải nghiệm và quyết định",
        "purpose": "Thực hiện đủ bước hỏi, ghi, đối chiếu, quyết định.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung mình dùng để học hoặc chia sẻ.",
        "assessment": "Kiểm tra bảng có kết quả, nguồn và quyết định. Không đánh giá theo việc các em có phát hiện lỗi thật hay không.",
        "answers": [
          "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung em dùng để học hoặc chia sẻ."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Những việc vừa làm giúp em rút ra ba ý.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ghi nguyên kết quả trước khi sửa.\n2. Nói dễ hiểu: Kiểm chi tiết bằng nguồn phù hợp.\n3. Điều cần nhớ: Quyết định và nêu lí do.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Giữ kết quả đúng cũng cần lí do. Con người chịu trách nhiệm về nội dung em dùng để học hoặc chia sẻ.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng cách làm vừa học trong một việc mới."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi nguyên kết quả trước khi sửa.",
        "Kiểm chi tiết bằng nguồn phù hợp.",
        "Quyết định và nêu lí do."
      ],
      "phase": "Luyện tập / Thực hành",
      "scene": "translate",
      "taskLines": [
        "Trong 30 giây, em giải thích một ý tại chỗ."
      ],
      "connector": "Những việc vừa làm giúp em rút ra ba ý.",
      "number": 26,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi nguyên kết quả trước khi sửa.",
        "Kiểm chi tiết bằng nguồn phù hợp.",
        "Quyết định và nêu lí do."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ghi nguyên kết quả trước khi sửa.",
          "tone": "key",
          "note": "Thầy/Cô: Ghi nguyên kết quả trước khi sửa."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Kiểm chi tiết bằng nguồn phù hợp.",
          "tone": "explain",
          "note": "Thầy/Cô: Kiểm chi tiết bằng nguồn phù hợp."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Quyết định và nêu lí do.",
          "tone": "action",
          "note": "Thầy/Cô: Quyết định và nêu lí do."
        }
      ]
    },
    {
      "type": "divider",
      "id": "05-22",
      "title": "Vận dụng: kiểm một câu mới",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Đề xuất cách dùng AI trong một việc học cụ thể.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Có thể ghi chưa đủ căn cứ và hỏi GV thay vì buộc phải có đáp án ngay.",
        "assessment": "Dùng thẻ để nhận xét 6.2.TC1a và khả năng kiểm tra. Thiếu nguồn thì yêu cầu bổ sung.",
        "answers": [],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em dùng cách làm vừa học trong một việc mới.",
          "explanation": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em đọc mục mới; chuẩn bị nhiệm vụ.",
          "answer": "Thầy/Cô chốt bằng một ví dụ cụ thể trong bài.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em xem cách điền trước khi tự làm."
        }
      },
      "theme": "blue",
      "v6": true,
      "screen": [],
      "phase": "Vận dụng",
      "scene": "translate",
      "taskLines": [
        "Trong 10 giây, em đọc tên hoạt động trên slide."
      ],
      "connector": "Em dùng cách làm vừa học trong một việc mới.",
      "number": 27,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em đọc mục mới; chuẩn bị nhiệm vụ."
    },
    {
      "id": "05-23-mau",
      "type": "worked",
      "v6": true,
      "title": "Mẫu lập cách kiểm câu mới",
      "theme": "cream",
      "phase": "Vận dụng",
      "scene": "translate",
      "worked": {
        "title": "Mẫu lập cách kiểm câu mới",
        "context": "Mẫu tạo sẵn; không phải kết quả lớp.",
        "labels": [
          "Câu chọn",
          "Nghĩa theo bài học",
          "AI có thể giúp",
          "Chi tiết cần kiểm",
          "Nguồn kiểm"
        ],
        "values": [
          "Open your book.",
          "Mở sách của em.",
          "Gợi nghĩa và cách dùng",
          "Open và book trong câu",
          "Bảng từ hoặc sách tiếng Anh em đang học"
        ],
        "why": [
          "Đây là kế hoạch, chưa là kết quả AI.",
          "Chỉ chọn một câu quen.",
          "Nguồn cần mở lại được."
        ],
        "question": "Em dùng nguồn nào để kiểm nghĩa?",
        "scene": "Translate"
      },
      "targetId": "05-23",
      "screen": [],
      "taskLines": [
        "Trong 30 giây, em nghĩ cách điền ô cuối tại chỗ."
      ],
      "connector": "Em xem cách điền trước khi tự làm.",
      "note": {
        "activity": "Thầy/Cô làm mẫu",
        "purpose": "Nhìn cách làm trước khi tự thực hiện.",
        "teacher": "Thầy/Cô giải thích bốn ô đã điền.",
        "students": "Em xem; đề xuất ô cuối.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Bảng từ hoặc sách tiếng Anh em đang học",
        "assessment": "Em điền ô cuối và nói được vì sao.",
        "answers": [
          "Câu chọn: Open your book.\nNghĩa theo bài học: Mở sách của em.\nAI có thể giúp: Gợi nghĩa và cách dùng\nChi tiết cần kiểm: Open và book trong câu\nNguồn kiểm: Bảng từ hoặc sách tiếng Anh em đang học"
        ],
        "source": "Mẫu học tập tự biên soạn. Không phải kết quả chạy AI thật.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em xem cách điền trước khi tự làm.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Em muốn hiểu câu Open your book.\n2. Nói dễ hiểu: Em cần nguồn giải thích nghĩa trong đúng câu.\n3. Điền mẫu: Em đọc mẫu; đề xuất phần còn thiếu.",
          "delivery": "Thầy/Cô mở tình huống, hỏi cách hiểu rồi chỉ bốn mục đã điền. Dừng 30 giây ở ô cuối; nghe 1–2 em trước khi mở đáp án. Đây là mẫu chung, chưa ghi vào bài cá nhân.",
          "students": "Em xem; đề xuất ô cuối.",
          "answer": "Câu chọn: Open your book.\nNghĩa theo bài học: Mở sách của em.\nAI có thể giúp: Gợi nghĩa và cách dùng\nChi tiết cần kiểm: Open và book trong câu\nNguồn kiểm: Bảng từ hoặc sách tiếng Anh em đang học",
          "closing": "Thầy/Cô nhắc: học cách điền, không chép kết quả mẫu.",
          "transition": "Thầy/Cô nối: Em đã xem mẫu. Giờ em tự làm theo cách đó."
        }
      },
      "number": 28,
      "v7": true,
      "originalTeachingPoints": [],
      "pupilTask": "Em xem; đề xuất ô cuối.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Em muốn hiểu câu Open your book.",
          "tone": "key",
          "note": "Thầy/Cô: Em muốn hiểu câu Open your book."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Em cần nguồn giải thích nghĩa trong đúng câu.",
          "tone": "explain",
          "note": "Thầy/Cô: Em cần nguồn giải thích nghĩa trong đúng câu."
        },
        {
          "label": "Điền mẫu",
          "text": "Em đọc mẫu; đề xuất phần còn thiếu.",
          "tone": "action",
          "note": "Thầy/Cô hỏi: Em dùng nguồn nào để kiểm nghĩa? Gợi ý: Bảng từ hoặc sách tiếng Anh em đang học"
        }
      ]
    },
    {
      "type": "worksheet",
      "worksheet": {
        "title": "P5.3 Dùng AI để học",
        "intro": "Trong 3 phút, em tự điền trên phiếu. Trong 2 phút, em so kết quả với em ngồi cạnh.",
        "answers": [
          "B Có nhiệm vụ cụ thể, nguồn kiểm độc lập và lựa chọn hỏi Thầy/Cô/tạm chưa dùng nếu chưa chắc."
        ],
        "pages": [
          {
            "title": "Lập cách dùng AI để học",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em muốn AI giúp việc gì với câu đó?",
                "key": "05-23-v3-0"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Lập cách dùng AI để học",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Em sẽ đối chiếu kết quả bằng nguồn nào?",
                "key": "05-23-v3-1"
              }
            ],
            "originalPage": 0
          },
          {
            "title": "Lập cách dùng AI để học",
            "instruction": "Em ghi kết quả vào ô dưới.",
            "fields": [
              {
                "label": "Nếu vẫn chưa hiểu, em sẽ làm gì?",
                "key": "05-23-v3-2"
              }
            ],
            "originalPage": 0
          }
        ],
        "v7PageMap": {
          "0": 0
        }
      },
      "time": 3,
      "id": "05-23",
      "title": "P5.3B — Kiểm một câu mới",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Hoàn thành dùng ai để hỗ trợ học theo các bước trên phiếu.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Có thể ghi chưa đủ căn cứ và hỏi GV thay vì buộc phải có đáp án ngay.",
        "assessment": "Thầy/Cô xem từng mục đã điền. Em nêu căn cứ khi được hỏi. Chấp nhận cách diễn đạt đúng khác lời mẫu.",
        "answers": [
          "B Có nhiệm vụ cụ thể, nguồn kiểm độc lập và lựa chọn hỏi Thầy/Cô/tạm chưa dùng nếu chưa chắc."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em đã xem mẫu. Giờ em tự làm theo cách đó.",
          "explanation": "\nÝ cần giảng rõ: Chọn câu trong bài tiếng Anh. Nêu chi tiết và nguồn cần kiểm. Dự kiến cách quyết định.\nPhiếu mở lần lượt: đọc thông tin trước, làm một mục mỗi trang. Em dùng Trước/Tiếp để xem lại. Mọi ô vẫn lưu theo khóa cũ, không theo số trang.",
          "delivery": "Thầy/Cô giao một lượt yên lặng 3 phút, sau đó đổi kiểm với em cùng bàn 2 phút. Các trang là các phần của cùng nhiệm vụ, không tính thêm 3+2 phút cho từng trang. Gọi 1–2 em trả lời tại chỗ.",
          "students": "Em làm yên lặng 3′; đổi kiểm 2′.",
          "answer": "B Có nhiệm vụ cụ thể, nguồn kiểm độc lập và lựa chọn hỏi Thầy/Cô/tạm chưa dùng nếu chưa chắc.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em giữ kết quả hôm nay để chuẩn bị bước tiếp."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Chọn câu trong bài tiếng Anh.",
        "Nêu chi tiết và nguồn cần kiểm.",
        "Dự kiến cách quyết định."
      ],
      "phase": "Vận dụng",
      "scene": "translate",
      "taskLines": [
        "Trong 3 phút, em tự điền trên phiếu.",
        "Trong 2 phút, em so kết quả với em ngồi cạnh."
      ],
      "sampleId": "05-23-mau",
      "connector": "Em đã xem mẫu. Giờ em tự làm theo cách đó.",
      "number": 29,
      "v7": true,
      "originalTeachingPoints": [
        "Chọn câu trong bài tiếng Anh.",
        "Nêu chi tiết và nguồn cần kiểm.",
        "Dự kiến cách quyết định."
      ],
      "pupilTask": "Em làm yên lặng 3′; đổi kiểm 2′.",
      "pupilTitle": "P5.3B · Em tự làm"
    },
    {
      "type": "home",
      "id": "05-24",
      "title": "Chuẩn bị câu hỏi cho lần sau",
      "note": {
        "activity": "Vận dụng",
        "purpose": "Đề xuất cách dùng AI trong một việc học cụ thể.",
        "teacher": "Thầy/Cô làm mẫu trước. Gọi 1–2 em trả lời ô cuối. Chưa giao trao đổi khi các em chưa hiểu cách làm.",
        "students": "Em quan sát; nêu một ý.",
        "report": "Thầy/Cô mời một em trả lời tại chỗ; em khác bổ sung căn cứ.",
        "conclusion": "Có thể ghi chưa đủ căn cứ và hỏi GV thay vì buộc phải có đáp án ngay.",
        "assessment": "Dùng thẻ để nhận xét 6.2.TC1a và khả năng kiểm tra. Thiếu nguồn thì yêu cầu bổ sung.",
        "answers": [
          "Có thể ghi chưa đủ căn cứ và hỏi Thầy/Cô thay vì buộc phải có đáp án ngay."
        ],
        "source": "Bài 8 AI dịch thuật, trang in 57; Bài 10 Xây dựng trợ lí ảo, mục Các chức năng cơ bản của trợ lí ảo, trang in 71; Bài 11 AI quanh ta và tác động thực tế. Không triển khai phần lập trình hoặc dùng câu trả lời mẫu làm chứng cứ thực nghiệm.",
        "time": "Các bước mở lần lượt nằm trong mốc hoạt động; không cộng thời gian mỗi trang.",
        "script": {
          "opening": "Thầy/Cô dẫn: Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
          "explanation": "Thầy/Cô mở lần lượt ba bước.\n1. Tình huống: Ghi một câu đã học và nghĩa theo sách.\n2. Nói dễ hiểu: Nêu AI có thể giúp phần nào.\n3. Điều cần nhớ: Không cần dùng công cụ ở nhà.",
          "delivery": "Thầy/Cô mở từng bước, hỏi một câu ngắn; mời một em nêu ý và một em bổ sung. Chỉ chuyển tiếp sau khi các em hiểu ý chính.",
          "students": "Em quan sát; nêu một ý.",
          "answer": "Có thể ghi chưa đủ căn cứ và hỏi Thầy/Cô thay vì buộc phải có đáp án ngay.",
          "closing": "Thầy/Cô chốt một ý bằng kết quả các em vừa nêu.",
          "transition": "Thầy/Cô nối: Em dùng ý vừa tìm được để chuẩn bị phần học tiếp theo."
        }
      },
      "theme": "cream",
      "v6": true,
      "screen": [
        "Ghi một câu đã học và nghĩa theo sách.",
        "Nêu AI có thể giúp phần nào.",
        "Không cần dùng công cụ ở nhà."
      ],
      "phase": "Vận dụng",
      "scene": "translate",
      "taskLines": [
        "Sau giờ học, em ghi một quan sát vào vở."
      ],
      "connector": "Em giữ kết quả hôm nay để chuẩn bị bước tiếp.",
      "number": 30,
      "v7": true,
      "originalTeachingPoints": [
        "Ghi một câu đã học và nghĩa theo sách.",
        "Nêu AI có thể giúp phần nào.",
        "Không cần dùng công cụ ở nhà."
      ],
      "pupilTask": "Em quan sát; nêu một ý.",
      "progressive": [
        {
          "label": "Tình huống",
          "text": "Ghi một câu đã học và nghĩa theo sách.",
          "tone": "key",
          "note": "Thầy/Cô: Ghi một câu đã học và nghĩa theo sách."
        },
        {
          "label": "Nói dễ hiểu",
          "text": "Nêu AI có thể giúp phần nào.",
          "tone": "explain",
          "note": "Thầy/Cô: Nêu AI có thể giúp phần nào."
        },
        {
          "label": "Điều cần nhớ",
          "text": "Không cần dùng công cụ ở nhà.",
          "tone": "action",
          "note": "Thầy/Cô: Không cần dùng công cụ ở nhà."
        }
      ]
    }
  ],
  "rubric": [],
  "evidence": [
    [
      "Đối chiếu kết quả",
      "1.2.TC1a",
      "So sánh kết quả với nguồn đã xác định.",
      "P5.2 và P5.3A",
      "Hai chi tiết có nguồn, nhận xét dựa vào đối chiếu."
    ],
    [
      "Chọn kết quả sử dụng",
      "6.2.TC1a",
      "Dùng AI hỗ trợ và tự quyết định.",
      "Thao tác/đề xuất, P5.3B",
      "Nêu rõ việc AI làm và trách nhiệm kiểm tra; mô phỏng chưa chứng minh thao tác trực tiếp."
    ]
  ],
  "revision": "V7 — 19/11/2026"
};
